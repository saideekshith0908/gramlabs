export type Language = 'en' | 'hi';

export type UserRole = 'candidate' | 'employer' | 'admin';

export type CertificationStatus = 'not_submitted' | 'pending' | 'verified' | 'rejected';

export type JobApprovalStatus = 'approved' | 'pending' | 'rejected';

export type ApplicationStatus =
  | 'Applied'
  | 'Under Review'
  | 'Shortlisted'
  | 'Interview Call'
  | 'Rejected'
  | 'Selected';

export type TradeCategoryId =
  | 'solar'
  | 'electrical'
  | 'mechanical'
  | 'agriculture'
  | 'electronics'
  | 'healthcare'
  | 'welding'
  | 'retail';

export interface SkillDefinition {
  id: string;
  nameEn: string;
  nameHi: string;
  category: TradeCategoryId;
}

export interface TradeCategory {
  id: TradeCategoryId;
  nameEn: string;
  nameHi: string;
  summaryEn: string;
  summaryHi: string;
  accentClass: string;
}

export const TRADE_CATEGORIES: TradeCategory[] = [
  {
    id: 'solar',
    nameEn: 'Solar & Renewable',
    nameHi: 'सौर ऊर्जा और नवीकरणीय',
    summaryEn: 'Rooftop PV installation, inverter wiring & panel cleaning',
    summaryHi: 'रूफटॉप सोलर लगाना, इन्वर्टर वायरिंग और पैनल रखरखाव',
    accentClass: 'text-emerald-800 bg-emerald-50 border-emerald-200',
  },
  {
    id: 'electrical',
    nameEn: 'Electrical',
    nameHi: 'इलेक्ट्रिकल (बिजली कार्य)',
    summaryEn: 'House & industrial wiring, starter panels & fault repair',
    summaryHi: 'घरेलू और औद्योगिक वायरिंग, स्टार्टर पैनल और मरम्मत',
    accentClass: 'text-blue-900 bg-blue-50 border-blue-200',
  },
  {
    id: 'mechanical',
    nameEn: 'Mechanical & EV',
    nameHi: 'मैकेनिकल और ई-वाहन',
    summaryEn: 'Tractor service, E-rickshaw motor & farm machinery',
    summaryHi: 'ट्रैक्टर सर्विस, ई-रिक्शा मोटर और कृषि मशीनरी मरम्मत',
    accentClass: 'text-slate-800 bg-slate-100 border-slate-200',
  },
  {
    id: 'agriculture',
    nameEn: 'Agriculture & Dairy',
    nameHi: 'कृषि, सिंचाई और डेयरी',
    summaryEn: 'Organic farming, dairy supervision, drip irrigation & agri-tech',
    summaryHi: 'जैविक खेती, डेयरी प्रबंधन, ड्रिप सिंचाई और एग्री-टेक',
    accentClass: 'text-emerald-900 bg-emerald-50 border-emerald-200',
  },
  {
    id: 'electronics',
    nameEn: 'Electronics Repair',
    nameHi: 'इलेक्ट्रॉनिक्स मरम्मत',
    summaryEn: 'Smartphone hardware, PCB diagnostics & soldering',
    summaryHi: 'मोबाइल हार्डवेयर रिपेयर, पीसीबी जांच और सोल्डरिंग',
    accentClass: 'text-blue-900 bg-blue-50 border-blue-200',
  },
  {
    id: 'healthcare',
    nameEn: 'Rural Healthcare',
    nameHi: 'ग्रामीण स्वास्थ्य सेवा',
    summaryEn: 'Primary clinic support, vitals check & patient care aid',
    summaryHi: 'प्राथमिक क्लिनिक सहायता, जांच और रोगी देखभाल',
    accentClass: 'text-emerald-800 bg-emerald-50 border-emerald-200',
  },
  {
    id: 'welding',
    nameEn: 'Welding & Fabrication',
    nameHi: 'वेल्डिंग और फैब्रिकेशन',
    summaryEn: 'Arc/MIG welding, solar mounting frames & steel fabrication',
    summaryHi: 'आर्क/मिग वेल्डिंग, सोलर स्ट्रक्चर और लोहे का निर्माण कार्य',
    accentClass: 'text-slate-800 bg-slate-100 border-slate-200',
  },
  {
    id: 'retail',
    nameEn: 'Rural Sales & Banking',
    nameHi: 'ग्रामीण बिक्री और बैंकिंग',
    summaryEn: 'Rural Bank Mitra, agri-input distribution & customer service',
    summaryHi: 'बैंक मित्र सेवाएं, कृषि उत्पाद वितरण और ग्राहक सहायता',
    accentClass: 'text-blue-900 bg-blue-50 border-blue-200',
  },
];

export const VOCATIONAL_SKILLS: SkillDefinition[] = [
  { id: 'Solar PV Installation', nameEn: 'Solar PV Installation', nameHi: 'सोलर पीवी इंस्टॉलेशन', category: 'solar' },
  { id: 'Solar Panel Maintenance', nameEn: 'Solar Panel Maintenance', nameHi: 'सोलर पैनल रखरखाव', category: 'solar' },
  { id: 'Electrical Wiring', nameEn: 'Electrical Wiring', nameHi: 'इलेक्ट्रिकल वायरिंग', category: 'electrical' },
  { id: 'Electrical Repair', nameEn: 'Electrical Repair', nameHi: 'इलेक्ट्रिकल मरम्मत', category: 'electrical' },
  { id: 'Tractor Maintenance', nameEn: 'Tractor Maintenance', nameHi: 'ट्रैक्टर रखरखाव और मरम्मत', category: 'mechanical' },
  { id: 'E-Rickshaw Repair', nameEn: 'E-Rickshaw Repair', nameHi: 'ई-रिक्शा मरम्मत', category: 'mechanical' },
  { id: 'Agricultural Equipment Operation', nameEn: 'Agricultural Equipment Operation', nameHi: 'कृषि यंत्र संचालन', category: 'mechanical' },
  { id: 'Farm Machinery Maintenance', nameEn: 'Farm Machinery Maintenance', nameHi: 'कृषि मशीनरी रखरखाव', category: 'mechanical' },
  { id: 'Organic Farming', nameEn: 'Organic Farming', nameHi: 'जैविक खेती', category: 'agriculture' },
  { id: 'Dairy Management', nameEn: 'Dairy Management', nameHi: 'डेयरी प्रबंधन', category: 'agriculture' },
  { id: 'Agri-tech', nameEn: 'Agri-tech', nameHi: 'एग्री-टेक और आधुनिक खेती', category: 'agriculture' },
  { id: 'Irrigation Systems', nameEn: 'Irrigation Systems', nameHi: 'सिंचाई प्रणाली (ड्रिप/स्प्रिंकलर)', category: 'agriculture' },
  { id: 'Mobile Hardware Repair', nameEn: 'Mobile Hardware Repair', nameHi: 'मोबाइल हार्डवेयर रिपेयर', category: 'electronics' },
  { id: 'Nursing Aid', nameEn: 'Nursing Aid', nameHi: 'नर्सिंग सहायता', category: 'healthcare' },
  { id: 'Welding and Fabrication', nameEn: 'Welding and Fabrication', nameHi: 'वेल्डिंग और फैब्रिकेशन', category: 'welding' },
  { id: 'Sales and Distribution', nameEn: 'Sales and Distribution', nameHi: 'बिक्री और वितरण', category: 'retail' },
  { id: 'Rural Banking Operations', nameEn: 'Rural Banking Operations', nameHi: 'ग्रामीण बैंकिंग संचालन', category: 'retail' },
];

export const INDIAN_STATES = [
  'Rajasthan',
  'Uttar Pradesh',
  'Madhya Pradesh',
  'Haryana',
  'Gujarat',
  'Maharashtra',
  'Bihar',
  'Punjab',
  'Odisha',
  'Chhattisgarh',
];

export interface CandidateProfile {
  userId: number;
  fullName: string;
  mobile: string;
  mobileStatus: 'registered' | 'verified_demo';
  homeDistrict: string;
  state: string;
  skills: string[];
  experienceYears: number;
  itiQualified: boolean;
  itiTrade: string;
  itiCertificateCode: string;
  itiStatus: CertificationStatus;
  pmkvyCertified: boolean;
  pmkvyTrade: string;
  pmkvyCertificateCode: string;
  pmkvyStatus: CertificationStatus;
  availabilityDate: string;
  updatedAt: string;
}

export interface JobPosting {
  id: number;
  employerId: number;
  titleEn: string;
  titleHi: string;
  companyName: string;
  companyNameHi: string;
  category: TradeCategoryId;
  descriptionEn: string;
  descriptionHi: string;
  responsibilitiesEn: string[];
  responsibilitiesHi: string[];
  requiredSkills: string[];
  salaryMonthly: number;
  locationDistrict: string;
  locationState: string;
  proximityKm: number;
  accommodationFree: boolean;
  foodProvided: boolean;
  experienceMinYears: number;
  employmentType: 'Full-Time' | 'Contract' | 'Apprenticeship';
  contactPhone: string;
  whatsappPhone: string;
  postedDate: string;
  approvalStatus: JobApprovalStatus;
  isSample: boolean;
  featuredImage: string;
}

export interface JobApplicationRecord {
  id: number;
  jobId: number;
  candidateUserId: number;
  availabilityDate: string;
  status: ApplicationStatus;
  employerNotes: string;
  appliedAt: string;
  updatedAt: string;
  job?: JobPosting;
  candidate?: CandidateProfile;
}

export interface EmployerProfile {
  id: number;
  userId: number;
  companyName: string;
  companyNameHi: string;
  sector: string;
  district: string;
  state: string;
  contactPhone: string;
  whatsappPhone: string;
  description: string;
  descriptionHi: string;
  verified: boolean;
  createdAt: string;
}

export interface AuthUser {
  id: number;
  name: string;
  phone: string;
  role: UserRole;
}
