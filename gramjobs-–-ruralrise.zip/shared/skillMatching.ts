import { VOCATIONAL_SKILLS, type TradeCategoryId } from './vocational.ts';

export interface SkillMatchBreakdown {
  score: number;
  exactMatches: string[];
  transferableMatches: Array<{ required: string; matchedFrom: string }>;
  missingSkills: string[];
}

const SKILL_CATEGORY_MAP = new Map<string, TradeCategoryId>(
  VOCATIONAL_SKILLS.map((skill) => [skill.id, skill.category])
);

const ADJACENT_TRADES: Record<TradeCategoryId, TradeCategoryId[]> = {
  solar: ['electrical', 'welding'],
  electrical: ['solar', 'electronics', 'mechanical'],
  mechanical: ['electrical', 'welding', 'agriculture'],
  agriculture: ['mechanical', 'retail'],
  electronics: ['electrical'],
  healthcare: [],
  welding: ['solar', 'mechanical'],
  retail: ['agriculture'],
};

/**
 * Vocational skill taxonomy overlap scoring engine.
 * - Direct skill match: 1.00 weight
 * - Same-trade skill transfer (e.g., Solar PV Installation -> Solar Panel Maintenance): 0.85 weight
 * - Adjacent cross-trade foundation (e.g., Electrical Wiring -> Solar / E-Rickshaw): 0.45 weight
 *
 * Example: Candidate [Solar PV Installation, Electrical Wiring] vs
 * Job [Solar PV Installation, Electrical Wiring, Solar Panel Maintenance]
 * => (1.0 + 1.0 + 0.85) / 3 = 0.95 => 95% Match.
 */
export function calculateSkillMatch(
  candidateSkills: string[],
  requiredSkills: string[]
): SkillMatchBreakdown {
  if (!requiredSkills || requiredSkills.length === 0) {
    return {
      score: candidateSkills.length > 0 ? 75 : 50,
      exactMatches: [],
      transferableMatches: [],
      missingSkills: [],
    };
  }

  if (!candidateSkills || candidateSkills.length === 0) {
    return {
      score: 0,
      exactMatches: [],
      transferableMatches: [],
      missingSkills: [...requiredSkills],
    };
  }

  const candidateSet = new Set(candidateSkills);
  const candidateCategories = new Map<TradeCategoryId, string>();
  for (const skill of candidateSkills) {
    const cat = SKILL_CATEGORY_MAP.get(skill);
    if (cat && !candidateCategories.has(cat)) {
      candidateCategories.set(cat, skill);
    }
  }

  let totalWeight = 0;
  const exactMatches: string[] = [];
  const transferableMatches: Array<{ required: string; matchedFrom: string }> = [];
  const missingSkills: string[] = [];

  for (const req of requiredSkills) {
    if (candidateSet.has(req)) {
      totalWeight += 1.0;
      exactMatches.push(req);
      continue;
    }

    const reqCategory = SKILL_CATEGORY_MAP.get(req);
    if (reqCategory && candidateCategories.has(reqCategory)) {
      totalWeight += 0.85;
      transferableMatches.push({
        required: req,
        matchedFrom: candidateCategories.get(reqCategory)!,
      });
      continue;
    }

    let adjacentMatch: string | null = null;
    if (reqCategory) {
      for (const adjCat of ADJACENT_TRADES[reqCategory] || []) {
        if (candidateCategories.has(adjCat)) {
          adjacentMatch = candidateCategories.get(adjCat)!;
          break;
        }
      }
    }

    if (adjacentMatch) {
      totalWeight += 0.45;
      transferableMatches.push({
        required: req,
        matchedFrom: adjacentMatch,
      });
    } else {
      missingSkills.push(req);
    }
  }

  const rawPercentage = Math.round((totalWeight / requiredSkills.length) * 100);
  const clampedScore = Math.max(0, Math.min(100, rawPercentage));

  return {
    score: clampedScore,
    exactMatches,
    transferableMatches,
    missingSkills,
  };
}
