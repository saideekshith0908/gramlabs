import { db, hashPassword } from './db.ts';

const IMG_SOLAR = '/src/assets/images/hero_solar_technician_1795114646236.jpg';
const IMG_AGRI = '/src/assets/images/trade_agri_supervisor_1795114646469.jpg';
const IMG_MECH = '/src/assets/images/trade_iti_mechanic_1795114647967.jpg';
const IMG_RETAIL = '/src/assets/images/rural_enterprise_lead_1795114646855.jpg';

export function seedDatabase(): void {
  const existingJobsCount = (db.prepare('SELECT COUNT(*) as cnt FROM jobs').get() as { cnt: number }).cnt;
  if (existingJobsCount > 0) {
    return;
  }

  const insertUser = db.prepare(
    'INSERT INTO users (name, phone, password_hash, role) VALUES (?, ?, ?, ?)'
  );

  // 1. Demo Candidate (Solar + Electrical skills -> 95% match on Solar Rooftop Technician - Jaipur)
  const cand1 = insertUser.run('Ramesh Kumar Verma', '9876543210', hashPassword('1234'), 'candidate');
  const cand1Id = Number(cand1.lastInsertRowid);

  // 2. Second Demo Candidate (Agriculture + Mechanical with pending PMKVY verification)
  const cand2 = insertUser.run('Sunita Devi Meena', '9876501122', hashPassword('1234'), 'candidate');
  const cand2Id = Number(cand2.lastInsertRowid);

  // 3. Demo Employer
  const empUser = insertUser.run('Suresh Sharma', '9829011223', hashPassword('1234'), 'employer');
  const empUserId = Number(empUser.lastInsertRowid);

  // 4. Secondary Regional Employer
  const empUser2 = insertUser.run('Mahendra Patel', '9825044556', hashPassword('1234'), 'employer');
  const empUser2Id = Number(empUser2.lastInsertRowid);

  // 5. Platform Admin
  insertUser.run('Platform Administrator', '9999000011', hashPassword('1234'), 'admin');

  const insertCandidateProfile = db.prepare(`
    INSERT INTO candidate_profiles (
      user_id, full_name, mobile, mobile_status, home_district, state,
      skills_json, experience_years, iti_qualified, iti_trade, iti_certificate_code, iti_status,
      pmkvy_certified, pmkvy_trade, pmkvy_certificate_code, pmkvy_status, availability_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertCandidateProfile.run(
    cand1Id,
    'Ramesh Kumar Verma',
    '9876543210',
    'registered',
    'Jaipur',
    'Rajasthan',
    JSON.stringify(['Solar PV Installation', 'Electrical Wiring']),
    2,
    1,
    'ITI Electrician (NCVT)',
    'ITI-RJ-2023-4481',
    'pending',
    0,
    '',
    '',
    'not_submitted',
    '2026-12-01'
  );

  insertCandidateProfile.run(
    cand2Id,
    'Sunita Devi Meena',
    '9876501122',
    'registered',
    'Ajmer',
    'Rajasthan',
    JSON.stringify(['Organic Farming', 'Irrigation Systems', 'Dairy Management']),
    3,
    0,
    '',
    '',
    'not_submitted',
    1,
    'PMKVY Micro-Irrigation Technician',
    'PMKVY-RJ-2024-8820',
    'pending',
    '2026-11-25'
  );

  const insertEmployer = db.prepare(`
    INSERT INTO employers (
      user_id, company_name, company_name_hi, sector, district, state,
      contact_phone, whatsapp_phone, description, description_hi, verified
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const emp1 = insertEmployer.run(
    empUserId,
    'SuryaShakti Rural Solar EPC',
    'सूर्यशक्ति ग्रामीण सोलर ईपीसी',
    'Solar & Renewable Energy',
    'Jaipur',
    'Rajasthan',
    '9829011223',
    '919829011223',
    'Regional rooftop and PM Surya Ghar solar installation contractor serving Jaipur, Sikar, and Alwar districts.',
    'जयपुर, सीकर और अलवर जिलों में रूफटॉप और पीएम सूर्य घर सोलर पैनल लगाने वाली क्षेत्रीय कंपनी।',
    1
  );
  const emp1Id = Number(emp1.lastInsertRowid);

  const emp2 = insertEmployer.run(
    empUser2Id,
    'Gramin Krishi & Pashudhan Enterprises',
    'ग्रामीण कृषि एवं पशुधन एंटरप्राइजेज',
    'Agri-Tech, Dairy & Machinery',
    'Indore',
    'Madhya Pradesh',
    '9825044556',
    '919825044556',
    'Agri-processing, dairy cooperatives, and rural farm machinery support network across central and western India.',
    'मध्य और पश्चिम भारत में कृषि प्रसंस्करण, डेयरी और कृषि मशीनरी सेवा नेटवर्क।',
    1
  );
  const emp2Id = Number(emp2.lastInsertRowid);

  const insertJob = db.prepare(`
    INSERT INTO jobs (
      employer_id, title_en, title_hi, company_name, company_name_hi, category,
      description_en, description_hi, responsibilities_json_en, responsibilities_json_hi,
      required_skills_json, salary_monthly, location_district, location_state,
      proximity_km, accommodation_free, food_provided, experience_min_years,
      employment_type, contact_phone, whatsapp_phone, posted_date, approval_status,
      is_sample, featured_image
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const sampleJobs = [
    {
      employerId: emp1Id,
      titleEn: 'PM Surya Ghar Solar Installer',
      titleHi: 'पीएम सूर्य घर सोलर इंस्टॉलर',
      companyName: 'SuryaShakti Rural Solar EPC',
      companyNameHi: 'सूर्यशक्ति ग्रामीण सोलर ईपीसी',
      category: 'solar',
      descriptionEn:
        'Install residential 3kW to 5kW rooftop solar systems under the PM Surya Ghar scheme across Sikar villages and nearby tehsils. Travel allowance and safety gear provided.',
      descriptionHi:
        'सीकर और आसपास की तहसीलों में पीएम सूर्य घर योजना के तहत 3kW से 5kW घरेलू रूफटॉप सोलर सिस्टम लगाएं। यात्रा भत्ता और सुरक्षा किट कंपनी द्वारा दी जाएगी।',
      respEn: [
        'Mount aluminum solar panel structures on village rooftops',
        'Complete DC/AC wiring and earthing connections safely',
        'Assist with net-meter commissioning and handover to families',
      ],
      respHi: [
        'छतों पर सोलर पैनल का एल्युमिनियम स्ट्रक्चर फिट करना',
        'डीसी/एसी वायरिंग और अर्थिंग कनेक्शन सुरक्षित रूप से करना',
        'नेट-मीटर चालू करने और ग्राहक को समझाने में सहायता करना',
      ],
      skills: ['Solar PV Installation', 'Electrical Wiring'],
      salary: 18500,
      district: 'Sikar',
      state: 'Rajasthan',
      proximityKm: 42,
      accom: 1,
      food: 0,
      exp: 1,
      type: 'Full-Time',
      phone: '9829011223',
      wa: '919829011223',
      date: '2026-11-16',
      img: IMG_SOLAR,
    },
    {
      employerId: emp1Id,
      titleEn: 'Solar Rooftop Technician',
      titleHi: 'सोलर रूफटॉप तकनीशियन',
      companyName: 'SuryaShakti Rural Solar EPC',
      companyNameHi: 'सूर्यशक्ति ग्रामीण सोलर ईपीसी',
      category: 'solar',
      descriptionEn:
        'Join our Jaipur regional installation and service team for residential and Panchayat bhavan solar rooftop units. Free shared accommodation and nutritious meals provided near site.',
      descriptionHi:
        'जयपुर क्षेत्र में घरों और पंचायत भवनों पर सोलर रूफटॉप सिस्टम लगाने और जांचने के लिए जुड़ें। कार्यस्थल के पास निःशुल्क रहने और भोजन की व्यवस्था उपलब्ध है।',
      respEn: [
        'Install rooftop PV modules, inverters, and junction boxes',
        'Perform AC/DC wiring tests using clamp meter and multimeter',
        'Conduct routine solar panel cleaning and preventive maintenance',
      ],
      respHi: [
        'छत पर सोलर पैनल, इन्वर्टर और जंक्शन बॉक्स स्थापित करना',
        'क्लैंप मीटर और मल्टीमीटर से एसी/डीसी वायरिंग की जांच करना',
        'सोलर पैनल की नियमित सफाई और रखरखाव करना',
      ],
      skills: ['Solar PV Installation', 'Electrical Wiring', 'Solar Panel Maintenance'],
      salary: 20000,
      district: 'Jaipur',
      state: 'Rajasthan',
      proximityKm: 14,
      accom: 1,
      food: 1,
      exp: 1,
      type: 'Full-Time',
      phone: '9829011223',
      wa: '919829011223',
      date: '2026-11-18',
      img: IMG_SOLAR,
    },
    {
      employerId: emp1Id,
      titleEn: 'Solar Panel Maintenance Technician',
      titleHi: 'सोलर पैनल रखरखाव तकनीशियन',
      companyName: 'Marudhara Clean Energy Services',
      companyNameHi: 'मरुधरा क्लीन एनर्जी सर्विसेज',
      category: 'solar',
      descriptionEn:
        'Maintain solar water pumps and village mini-grid panels in Jodhpur district. Ideal for candidates comfortable with outdoor field visits and basic electrical checks.',
      descriptionHi:
        'जोधपुर जिले में सोलर वाटर पंप और ग्रामीण मिनी-ग्रिड पैनलों की देखभाल और सर्विसिंग का कार्य।',
      respEn: [
        'Inspect solar arrays for dust, loose MC4 connectors, and shading',
        'Check inverter error codes and battery voltage levels',
        'Record daily generation logs via simple mobile checklist',
      ],
      respHi: [
        'सोलर पैनल, एमसी4 कनेक्टर और वायरिंग की नियमित जांच करना',
        'इन्वर्टर के एरर कोड और बैटरी वोल्टेज की जांच करना',
        'सरल मोबाइल चेकलिस्ट में दैनिक बिजली उत्पादन दर्ज करना',
      ],
      skills: ['Solar Panel Maintenance', 'Electrical Repair'],
      salary: 16500,
      district: 'Jodhpur',
      state: 'Rajasthan',
      proximityKm: 65,
      accom: 1,
      food: 0,
      exp: 0,
      type: 'Full-Time',
      phone: '9829011223',
      wa: '919829011223',
      date: '2026-11-14',
      img: IMG_SOLAR,
    },
    {
      employerId: emp2Id,
      titleEn: 'Rural Bank Mitra',
      titleHi: 'ग्रामीण बैंक मित्र',
      companyName: 'JanSeva Gramin Financial Kendra',
      companyNameHi: 'जनसेवा ग्रामीण वित्तीय केंद्र',
      category: 'retail',
      descriptionEn:
        'Operate a village banking point helping farmers and families with Aadhaar-enabled cash deposits, withdrawals, crop insurance enrollment, and savings accounts.',
      descriptionHi:
        'गांव स्तर पर बैंक मित्र केंद्र चलाएं और किसानों व परिवारों को आधार आधारित जमा-निकासी, फसल बीमा और बचत खाते में मदद करें।',
      respEn: [
        'Process AePS micro-ATM deposits and withdrawals accurately',
        'Assist villagers with KYC updates and government pension forms',
        'Maintain daily cash register and customer receipt records',
      ],
      respHi: [
        'माइक्रो-एटीएम से नकद जमा और निकासी सेवाएं देना',
        'ग्रामीणों को केवाईसी और पेंशन फॉर्म भरने में सहायता करना',
        'दैनिक नकद रजिस्टर और रसीद का हिसाब रखना',
      ],
      skills: ['Rural Banking Operations', 'Sales and Distribution'],
      salary: 15000,
      district: 'Alwar',
      state: 'Rajasthan',
      proximityKm: 28,
      accom: 0,
      food: 0,
      exp: 0,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-15',
      img: IMG_RETAIL,
    },
    {
      employerId: emp2Id,
      titleEn: 'Tractor Mechanic',
      titleHi: 'ट्रैक्टर मैकेनिक',
      companyName: 'Hadoti Krishi Yantra Workshop',
      companyNameHi: 'हाड़ौती कृषि यंत्र वर्कशॉप',
      category: 'mechanical',
      descriptionEn:
        'Service and repair 35HP–55HP farm tractors, hydraulic lifts, and clutch assemblies at our Kota rural service hub. Free lodging available above the workshop.',
      descriptionHi:
        'कोटा ग्रामीण सेवा केंद्र में 35HP–55HP ट्रैक्टर, हाइड्रोलिक लिफ्ट और क्लच की मरम्मत एवं सर्विसिंग कार्य। वर्कशॉप के ऊपर निःशुल्क आवास उपलब्ध है।',
      respEn: [
        'Perform engine oil, filter, brake, and clutch servicing',
        'Diagnose hydraulic pump and PTO shaft issues',
        'Support emergency on-farm tractor breakdown calls nearby',
      ],
      respHi: [
        'इंजन ऑयल, फिल्टर, ब्रेक और क्लच की सर्विसिंग करना',
        'हाइड्रोलिक पंप और पीटीओ शाफ्ट की खराबी ठीक करना',
        'नजदीकी खेतों में आपातकालीन ट्रैक्टर मरम्मत सहायता देना',
      ],
      skills: ['Tractor Maintenance', 'Farm Machinery Maintenance'],
      salary: 19000,
      district: 'Kota',
      state: 'Rajasthan',
      proximityKm: 35,
      accom: 1,
      food: 0,
      exp: 2,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-12',
      img: IMG_MECH,
    },
    {
      employerId: emp2Id,
      titleEn: 'Dairy Supervisor',
      titleHi: 'डेयरी सुपरवाइजर',
      companyName: 'Banas Gramin Milk Cooperative',
      companyNameHi: 'बनास ग्रामीण दुग्ध सहकारी संघ',
      category: 'agriculture',
      descriptionEn:
        'Supervise milk collection, fat/SNF testing, cold-chain chilling tanks, and clean cattle feed practices across 6 village collection booths.',
      descriptionHi:
        '6 ग्रामीण दुग्ध संग्रह केंद्रों पर दूध की गुणवत्ता, फैट जांच, चिलिंग टैंक और स्वच्छ पशुपालन की देखरेख करें।',
      respEn: [
        'Verify daily milk fat/SNF testing and farmer payment slips',
        'Monitor bulk milk cooler temperature and hygiene standards',
        'Guide dairy farmers on cattle nutrition and clean milking',
      ],
      respHi: [
        'दैनिक दूध फैट जांच और किसान भुगतान पर्ची सत्यापित करना',
        'मिल्क चिलर तापमान और स्वच्छता मानकों की निगरानी करना',
        'पशुपालकों को संतुलित आहार और स्वच्छ दूध उत्पादन की सलाह देना',
      ],
      skills: ['Dairy Management', 'Agri-tech'],
      salary: 21000,
      district: 'Anand',
      state: 'Gujarat',
      proximityKm: 85,
      accom: 1,
      food: 1,
      exp: 2,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-17',
      img: IMG_AGRI,
    },
    {
      employerId: emp2Id,
      titleEn: 'E-Rickshaw Mechanic',
      titleHi: 'ई-रिक्शा मैकेनिक',
      companyName: 'Awadh Green Mobility Hub',
      companyNameHi: 'अवध ग्रीन मोबिलिटी हब',
      category: 'mechanical',
      descriptionEn:
        'Repair electric three-wheeler BLDC motors, controllers, lithium/lead-acid battery packs, and wiring harnesses at our semi-urban service bay.',
      descriptionHi:
        'ई-रिक्शा के बीएलडीसी मोटर, कंट्रोलर, बैटरी पैक और वायरिंग की मरम्मत एवं चार्जिंग जांच का कार्य।',
      respEn: [
        'Troubleshoot controller, throttle, and DC converter faults',
        'Test battery cell health and replace worn brake shoes',
        'Maintain spare parts log for daily E-rickshaw repairs',
      ],
      respHi: [
        'कंट्रोलर, थ्रॉटल और डीसी कन्वर्टर की खराबी ठीक करना',
        'बैटरी की क्षमता जांचना और ब्रेक शू बदलना',
        'दैनिक मरम्मत के स्पेयर पार्ट्स का रिकॉर्ड रखना',
      ],
      skills: ['E-Rickshaw Repair', 'Electrical Repair'],
      salary: 17500,
      district: 'Lucknow',
      state: 'Uttar Pradesh',
      proximityKm: 55,
      accom: 1,
      food: 0,
      exp: 1,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-11',
      img: IMG_MECH,
    },
    {
      employerId: emp2Id,
      titleEn: 'Agro-Processing Plant Operator',
      titleHi: 'कृषि प्रसंस्करण प्लांट ऑपरेटर',
      companyName: 'Malwa Dal & Flour Mills',
      companyNameHi: 'मालवा दाल एवं आटा मिल्स',
      category: 'mechanical',
      descriptionEn:
        'Operate automated grain cleaning, pulse grading, and cold-pressed oil extraction machinery in our rural agro-park near Indore. Meals and dormitory provided.',
      descriptionHi:
        'इंदौर के पास ग्रामीण एग्रो-पार्क में अनाज सफाई, दाल ग्रेडिंग और तेल मिल मशीनों का संचालन। भोजन और रहने की सुविधा उपलब्ध है।',
      respEn: [
        'Run grain grading and packaging machines safely in shift',
        'Perform daily lubrication and belt tension checks',
        'Pack and weigh finished 25kg/50kg agricultural bags',
      ],
      respHi: [
        'अनाज ग्रेडिंग और पैकेजिंग मशीनों को सुरक्षित रूप से चलाना',
        'दैनिक ग्रीसिंग और बेल्ट की जांच करना',
        'तैयार कृषि उत्पादों के 25 किग्रा/50 किग्रा बैग पैक करना',
      ],
      skills: ['Agricultural Equipment Operation', 'Farm Machinery Maintenance'],
      salary: 18000,
      district: 'Indore',
      state: 'Madhya Pradesh',
      proximityKm: 48,
      accom: 1,
      food: 1,
      exp: 1,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-10',
      img: IMG_MECH,
    },
    {
      employerId: emp2Id,
      titleEn: 'Organic Farm Supervisor',
      titleHi: 'जैविक खेती सुपरवाइजर',
      companyName: 'Aravalli Prakritik Farms',
      companyNameHi: 'अरावली प्राकृतिक फार्म्स',
      category: 'agriculture',
      descriptionEn:
        'Lead vermicompost preparation, bio-fertilizer spraying, and seasonal vegetable cultivation across a 40-acre certified organic farm in Ajmer.',
      descriptionHi:
        'अजमेर में 40 एकड़ प्रमाणित जैविक फार्म पर केंचुआ खाद, जीवामृत तैयारी और मौसमी सब्जियों की खेती की देखरेख करें।',
      respEn: [
        'Prepare organic compost, Jeevamrit, and neem pest sprays',
        'Coordinate daily field team of 12 local farm workers',
        'Monitor soil moisture and drip irrigation scheduling',
      ],
      respHi: [
        'जैविक खाद, जीवामृत और नीम आधारित कीटनाशक तैयार करना',
        '12 स्थानीय कृषि श्रमिकों के दैनिक कार्य का समन्वय करना',
        'मिट्टी की नमी और ड्रिप सिंचाई समय की निगरानी करना',
      ],
      skills: ['Organic Farming', 'Irrigation Systems'],
      salary: 16000,
      district: 'Ajmer',
      state: 'Rajasthan',
      proximityKm: 22,
      accom: 1,
      food: 1,
      exp: 1,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-13',
      img: IMG_AGRI,
    },
    {
      employerId: emp1Id,
      titleEn: 'Electrical Wiring Technician',
      titleHi: 'इलेक्ट्रिकल वायरिंग तकनीशियन',
      companyName: 'Mewar Power & Pump Solutions',
      companyNameHi: 'मेवाड़ पावर एंड पंप सॉल्यूशंस',
      category: 'electrical',
      descriptionEn:
        'Handle three-phase agricultural motor starter panels, rural warehouse lighting, and residential MCB distribution wiring in Udaipur block.',
      descriptionHi:
        'उदयपुर क्षेत्र में थ्री-फेज कृषि मोटर स्टार्टर पैनल, गोदाम लाइटिंग और घरेलू एमसीबी वायरिंग का कार्य।',
      respEn: [
        'Install single-phase and three-phase MCB distribution boards',
        'Wire submersible water pump starters and auto-cut relays',
        'Follow lockout/tagout and earthing safety standards',
      ],
      respHi: [
        'सिंगल-फेज और थ्री-फेज एमसीबी वितरण बोर्ड लगाना',
        'सबमर्सिबल पंप स्टार्टर और ऑटो-कट रिले की वायरिंग करना',
        'सुरक्षा और अर्थिंग मानकों का पालन करना',
      ],
      skills: ['Electrical Wiring', 'Electrical Repair'],
      salary: 19500,
      district: 'Udaipur',
      state: 'Rajasthan',
      proximityKm: 38,
      accom: 1,
      food: 0,
      exp: 1,
      type: 'Full-Time',
      phone: '9829011223',
      wa: '919829011223',
      date: '2026-11-16',
      img: IMG_MECH,
    },
    {
      employerId: emp1Id,
      titleEn: 'Mobile Hardware Repair Technician',
      titleHi: 'मोबाइल हार्डवेयर रिपेयर तकनीशियन',
      companyName: 'Digital Tehsil Repair Center',
      companyNameHi: 'डिजिटल तहसील रिपेयर सेंटर',
      category: 'electronics',
      descriptionEn:
        'Diagnose and repair Android smartphones—charging ports, display glass, battery replacements, and speaker modules—at our busy tehsil market shop.',
      descriptionHi:
        'तहसील बाजार में एंड्रॉइड स्मार्टफोन की स्क्रीन, चार्जिंग जैक, बैटरी और स्पीकर बदलने व मरम्मत का कार्य।',
      respEn: [
        'Replace damaged smartphone displays, batteries, and USB-C ports',
        'Perform SMD soldering and water-damage board cleaning',
        'Provide transparent repair cost estimates to customers',
      ],
      respHi: [
        'मोबाइल स्क्रीन, बैटरी और चार्जिंग पिन बदलना',
        'एसएमडी सोल्डरिंग और मदरबोर्ड की सफाई करना',
        'ग्राहकों को स्पष्ट मरम्मत खर्च और समय की जानकारी देना',
      ],
      skills: ['Mobile Hardware Repair', 'Electrical Repair'],
      salary: 15500,
      district: 'Bikaner',
      state: 'Rajasthan',
      proximityKm: 60,
      accom: 0,
      food: 0,
      exp: 1,
      type: 'Full-Time',
      phone: '9829011223',
      wa: '919829011223',
      date: '2026-11-09',
      img: IMG_MECH,
    },
    {
      employerId: emp1Id,
      titleEn: 'Welding Technician',
      titleHi: 'वेल्डिंग तकनीशियन',
      companyName: 'Shakti Steel & Solar Structures',
      companyNameHi: 'शक्ति स्टील एंड सोलर स्ट्रक्चर्स',
      category: 'welding',
      descriptionEn:
        'Fabricate galvanized solar mounting frames, agricultural trolley bodies, and polyhouse trusses using Arc and MIG welding at Bhiwadi unit.',
      descriptionHi:
        'भिवाड़ी वर्कशॉप में आर्क और मिग वेल्डिंग द्वारा सोलर माउंटिंग फ्रेम, कृषि ट्रॉली और पॉलीहाउस स्ट्रक्चर निर्माण कार्य।',
      respEn: [
        'Read simple fabrication measurements and cut MS angle/channels',
        'Execute clean Arc and MIG welds with protective gear',
        'Apply anti-rust primer and verify frame squareness',
      ],
      respHi: [
        'माप के अनुसार एमएस एंगल और चैनल की कटाई करना',
        'सुरक्षा उपकरणों के साथ साफ आर्क और मिग वेल्डिंग करना',
        'प्राइमर पेंट लगाना और फ्रेम की मजबूती जांचना',
      ],
      skills: ['Welding and Fabrication'],
      salary: 22000,
      district: 'Bhiwadi',
      state: 'Rajasthan',
      proximityKm: 52,
      accom: 1,
      food: 1,
      exp: 2,
      type: 'Full-Time',
      phone: '9829011223',
      wa: '919829011223',
      date: '2026-11-17',
      img: IMG_MECH,
    },
    {
      employerId: emp2Id,
      titleEn: 'Agricultural Equipment Operator',
      titleHi: 'कृषि यंत्र ऑपरेटर',
      companyName: 'Harit Krishi Custom Hiring Center',
      companyNameHi: 'हरित कृषि कस्टम हायरिंग सेंटर',
      category: 'mechanical',
      descriptionEn:
        'Operate laser land levelers, rotavators, seed drills, and harvester attachments across farmer fields in Karnal cluster.',
      descriptionHi:
        'करनाल क्षेत्र में किसानों के खेतों पर लेजर लैंड लेवलर, रोटावेटर, सीड ड्रिल और हार्वेस्टर चलाने का कार्य।',
      respEn: [
        'Operate tractor-mounted seeders, sprayers, and rotavators',
        'Record acre coverage and diesel usage per field booking',
        'Clean and grease implements after daily field work',
      ],
      respHi: [
        'ट्रैक्टर से जुड़े सीडर, स्प्रेयर और रोटावेटर चलाना',
        'प्रत्येक खेत की बुकिंग का एकड़ और डीजल रिकॉर्ड रखना',
        'काम के बाद कृषि यंत्रों की सफाई और ग्रीसिंग करना',
      ],
      skills: ['Agricultural Equipment Operation', 'Tractor Maintenance'],
      salary: 17000,
      district: 'Karnal',
      state: 'Haryana',
      proximityKm: 70,
      accom: 1,
      food: 1,
      exp: 1,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-08',
      img: IMG_AGRI,
    },
    {
      employerId: emp2Id,
      titleEn: 'Irrigation System Technician',
      titleHi: 'सिंचाई प्रणाली तकनीशियन',
      companyName: 'JalDhara Drip & AgriTech',
      companyNameHi: 'जलधारा ड्रिप एंड एग्रीटेक',
      category: 'agriculture',
      descriptionEn:
        'Install HDPE drip lateral lines, venturi fertilizer injectors, and solar water pump controllers for horticulture farms in Nashik.',
      descriptionHi:
        'नासिक में बागवानी खेतों के लिए एचडीपीई ड्रिप सिंचाई पाइपलाइन, वेंचुरी और सोलर पंप कंट्रोलर लगाने का कार्य।',
      respEn: [
        'Lay mainlines, sub-mains, and drip emitters per field map',
        'Test water pressure, sand filters, and flush valves',
        'Train farmers on drip cleaning and seasonal maintenance',
      ],
      respHi: [
        'खेत के नक्शे के अनुसार ड्रिप पाइप और एमिटर बिछाना',
        'पानी का दबाव, सैंड फिल्टर और फ्लश वाल्व जांचना',
        'किसानों को ड्रिप सफाई और रखरखाव का तरीका सिखाना',
      ],
      skills: ['Irrigation Systems', 'Agri-tech'],
      salary: 18500,
      district: 'Nashik',
      state: 'Maharashtra',
      proximityKm: 90,
      accom: 1,
      food: 0,
      exp: 1,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-15',
      img: IMG_AGRI,
    },
    {
      employerId: emp2Id,
      titleEn: 'Farm Machinery Maintenance Worker',
      titleHi: 'कृषि मशीनरी रखरखाव कर्मी',
      companyName: 'Kisan Seva Yantra Kendra',
      companyNameHi: 'किसान सेवा यंत्र केंद्र',
      category: 'mechanical',
      descriptionEn:
        'Assist senior mechanics with chaff cutter, thresher, power tiller, and water pump servicing at our Hisar agricultural cooperative.',
      descriptionHi:
        'हिसार कृषि केंद्र में चारा काटने की मशीन, थ्रेशर, पावर टिलर और वाटर पंप की मरम्मत एवं रखरखाव में सहायता।',
      respEn: [
        'Sharpen blades, replace V-belts, and align pulley bearings',
        'Maintain workshop tool inventory and spare kits',
        'Support seasonal pre-harvest machinery readiness checks',
      ],
      respHi: [
        'ब्लेड तेज करना, वी-बेल्ट बदलना और पुली बेयरिंग ठीक करना',
        'वर्कशॉप के औजारों और स्पेयर पार्ट्स की देखभाल करना',
        'कटाई के मौसम से पहले मशीनों की जांच करना',
      ],
      skills: ['Farm Machinery Maintenance', 'Tractor Maintenance'],
      salary: 16500,
      district: 'Hisar',
      state: 'Haryana',
      proximityKm: 64,
      accom: 1,
      food: 0,
      exp: 0,
      type: 'Apprenticeship',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-07',
      img: IMG_MECH,
    },
    {
      employerId: emp2Id,
      titleEn: 'Rural Healthcare Assistant',
      titleHi: 'ग्रामीण स्वास्थ्य सहायक',
      companyName: 'Swasthya Gramin Clinic Network',
      companyNameHi: 'स्वास्थ्य ग्रामीण क्लिनिक नेटवर्क',
      category: 'healthcare',
      descriptionEn:
        'Support village primary health clinics with digital BP/glucose checks, patient registration, medicine dispensing support, and tele-doctor coordination.',
      descriptionHi:
        'ग्रामीण प्राथमिक स्वास्थ्य केंद्र में बीपी/शुगर जांच, रोगी पंजीकरण, दवा वितरण सहायता और टेली-डॉक्टर कॉल में सहयोग।',
      respEn: [
        'Measure blood pressure, temperature, SpO2, and blood sugar',
        'Assist visiting doctors during rural health camps',
        'Maintain clean dressing room and immunization registers',
      ],
      respHi: [
        'ब्लड प्रेशर, तापमान, ऑक्सीजन और शुगर की जांच करना',
        'ग्रामीण स्वास्थ्य शिविरों में डॉक्टरों की सहायता करना',
        'ड्रेसिंग रूम की स्वच्छता और टीकाकरण रजिस्टर संभालना',
      ],
      skills: ['Nursing Aid'],
      salary: 15000,
      district: 'Bharatpur',
      state: 'Rajasthan',
      proximityKm: 32,
      accom: 0,
      food: 1,
      exp: 0,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-16',
      img: IMG_RETAIL,
    },
    {
      employerId: emp2Id,
      titleEn: 'Agricultural Product Distributor',
      titleHi: 'कृषि उत्पाद वितरक',
      companyName: 'Vidarbha Krishi Kendra Supplies',
      companyNameHi: 'विदर्भ कृषि केंद्र सप्लाईज',
      category: 'retail',
      descriptionEn:
        'Coordinate delivery and retail distribution of certified seeds, bio-pesticides, and soil micronutrients to village dealer shops.',
      descriptionHi:
        'ग्रामीण दुकानों तक प्रमाणित बीज, जैविक कीटनाशक और सूक्ष्म पोषक तत्वों की डिलीवरी और बिक्री का समन्वय करें।',
      respEn: [
        'Manage daily dispatch orders to 15–20 gram panchayat dealers',
        'Collect digital/cash payments and issue GST bills',
        'Explain product usage schedules to local agri retailers',
      ],
      respHi: [
        '15–20 ग्राम पंचायत दुकानदारों को दैनिक सप्लाई पहुंचाना',
        'डिजिटल/नकद भुगतान एकत्र करना और बिल जारी करना',
        'स्थानीय दुकानदारों को उत्पाद उपयोग की सही जानकारी देना',
      ],
      skills: ['Sales and Distribution', 'Agri-tech'],
      salary: 16000,
      district: 'Nagpur',
      state: 'Maharashtra',
      proximityKm: 78,
      accom: 0,
      food: 0,
      exp: 1,
      type: 'Full-Time',
      phone: '9825044556',
      wa: '919825044556',
      date: '2026-11-14',
      img: IMG_RETAIL,
    },
    {
      employerId: emp1Id,
      titleEn: 'Solar Equipment Service Technician',
      titleHi: 'सोलर उपकरण सर्विस तकनीशियन',
      companyName: 'SuryaShakti Rural Solar EPC',
      companyNameHi: 'सूर्यशक्ति ग्रामीण सोलर ईपीसी',
      category: 'solar',
      descriptionEn:
        'Service hybrid solar inverters, lithium battery banks, and agricultural solar pump VFDs across Jaipur and nearby blocks. Company two-wheeler allowance included.',
      descriptionHi:
        'जयपुर और आसपास के ब्लॉकों में हाइब्रिड सोलर इन्वर्टर, लिथियम बैटरी और सोलर पंप वीएफडी की सर्विसिंग। वाहन भत्ता शामिल है।',
      respEn: [
        'Diagnose inverter PCB faults, fuse blowouts, and surge protectors',
        'Calibrate solar pump VFD controllers on farm sites',
        'Update service completion tickets with photos',
      ],
      respHi: [
        'इन्वर्टर पीसीबी, फ्यूज और सर्ज प्रोटेक्टर की खराबी ठीक करना',
        'खेतों पर सोलर पंप वीएफडी कंट्रोलर सेट करना',
        'सेवा पूर्ण होने का विवरण दर्ज करना',
      ],
      skills: ['Solar Panel Maintenance', 'Electrical Repair', 'Solar PV Installation'],
      salary: 21500,
      district: 'Jaipur',
      state: 'Rajasthan',
      proximityKm: 18,
      accom: 1,
      food: 1,
      exp: 2,
      type: 'Full-Time',
      phone: '9829011223',
      wa: '919829011223',
      date: '2026-11-18',
      img: IMG_SOLAR,
    },
  ];

  for (const job of sampleJobs) {
    insertJob.run(
      job.employerId,
      job.titleEn,
      job.titleHi,
      job.companyName,
      job.companyNameHi,
      job.category,
      job.descriptionEn,
      job.descriptionHi,
      JSON.stringify(job.respEn),
      JSON.stringify(job.respHi),
      JSON.stringify(job.skills),
      job.salary,
      job.district,
      job.state,
      job.proximityKm,
      job.accom,
      job.food,
      job.exp,
      job.type,
      job.phone,
      job.wa,
      job.date,
      'approved',
      1, // is_sample = 1 (exactly 18 realistic sample vacancies!)
      job.img
    );
  }

  // Add 1 non-sample pending employer submission so Admin Dashboard immediately has a real approval queue item
  insertJob.run(
    emp1Id,
    'Solar Water Pump Technician (Pending Review)',
    'सोलर वाटर पंप तकनीशियन (समीक्षाधीन)',
    'SuryaShakti Rural Solar EPC',
    'सूर्यशक्ति ग्रामीण सोलर ईपीसी',
    'solar',
    'Install and commission 5HP DC submersible solar water pumps for KUSUM scheme farmers in Alwar block.',
    'अलवर ब्लॉक में कुसुम योजना के किसानों के लिए 5HP डीसी सोलर वाटर पंप लगाना और चालू करना।',
    JSON.stringify([
      'Assemble solar pump mounting pole and controller box',
      'Lower submersible pump safely and test discharge flow',
    ]),
    JSON.stringify([
      'सोलर पंप पोल और कंट्रोलर बॉक्स लगाना',
      'सबमर्सिबल पंप फिट करके पानी का बहाव जांचना',
    ]),
    JSON.stringify(['Solar PV Installation', 'Irrigation Systems']),
    19000,
    'Alwar',
    'Rajasthan',
    30,
    1,
    0,
    1,
    'Full-Time',
    '9829011223',
    '919829011223',
    '2026-11-19',
    'pending',
    0, // live employer submission awaiting admin approval
    IMG_SOLAR
  );

  // Seed one initial application for Sunita Devi so Employer & Admin dashboards already have live tracking rows
  db.prepare(
    `INSERT INTO applications (job_id, candidate_user_id, availability_date, status, employer_notes)
     VALUES (?, ?, ?, ?, ?)`
  ).run(9, cand2Id, '2026-11-25', 'Shortlisted', 'Strong organic farming & drip background');
}
