import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import path from 'node:path';

const dbPath = path.resolve(process.cwd(), 'gramjobs.db');
export const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('candidate', 'employer', 'admin')),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS candidate_profiles (
      user_id INTEGER PRIMARY KEY,
      full_name TEXT NOT NULL,
      mobile TEXT NOT NULL,
      mobile_status TEXT NOT NULL DEFAULT 'registered',
      home_district TEXT NOT NULL,
      state TEXT NOT NULL,
      skills_json TEXT NOT NULL DEFAULT '[]',
      experience_years INTEGER NOT NULL DEFAULT 0,
      iti_qualified INTEGER NOT NULL DEFAULT 0,
      iti_trade TEXT NOT NULL DEFAULT '',
      iti_certificate_code TEXT NOT NULL DEFAULT '',
      iti_status TEXT NOT NULL DEFAULT 'not_submitted',
      pmkvy_certified INTEGER NOT NULL DEFAULT 0,
      pmkvy_trade TEXT NOT NULL DEFAULT '',
      pmkvy_certificate_code TEXT NOT NULL DEFAULT '',
      pmkvy_status TEXT NOT NULL DEFAULT 'not_submitted',
      availability_date TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE,
      company_name TEXT NOT NULL,
      company_name_hi TEXT NOT NULL DEFAULT '',
      sector TEXT NOT NULL,
      district TEXT NOT NULL,
      state TEXT NOT NULL,
      contact_phone TEXT NOT NULL,
      whatsapp_phone TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      description_hi TEXT NOT NULL DEFAULT '',
      verified INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employer_id INTEGER NOT NULL,
      title_en TEXT NOT NULL,
      title_hi TEXT NOT NULL,
      company_name TEXT NOT NULL,
      company_name_hi TEXT NOT NULL,
      category TEXT NOT NULL,
      description_en TEXT NOT NULL,
      description_hi TEXT NOT NULL,
      responsibilities_json_en TEXT NOT NULL DEFAULT '[]',
      responsibilities_json_hi TEXT NOT NULL DEFAULT '[]',
      required_skills_json TEXT NOT NULL DEFAULT '[]',
      salary_monthly INTEGER NOT NULL,
      location_district TEXT NOT NULL,
      location_state TEXT NOT NULL,
      proximity_km INTEGER NOT NULL DEFAULT 25,
      accommodation_free INTEGER NOT NULL DEFAULT 0,
      food_provided INTEGER NOT NULL DEFAULT 0,
      experience_min_years INTEGER NOT NULL DEFAULT 0,
      employment_type TEXT NOT NULL DEFAULT 'Full-Time',
      contact_phone TEXT NOT NULL,
      whatsapp_phone TEXT NOT NULL,
      posted_date TEXT NOT NULL,
      approval_status TEXT NOT NULL DEFAULT 'pending' CHECK(approval_status IN ('approved', 'pending', 'rejected')),
      is_sample INTEGER NOT NULL DEFAULT 0,
      featured_image TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (employer_id) REFERENCES employers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id INTEGER NOT NULL,
      candidate_user_id INTEGER NOT NULL,
      availability_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Applied' CHECK(status IN ('Applied', 'Under Review', 'Shortlisted', 'Interview Call', 'Rejected', 'Selected')),
      employer_notes TEXT NOT NULL DEFAULT '',
      applied_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(job_id, candidate_user_id),
      FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
      FOREIGN KEY (candidate_user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, originalHash] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const originalBuffer = Buffer.from(originalHash, 'hex');
  if (derived.length !== originalBuffer.length) return false;
  return crypto.timingSafeEqual(derived, originalBuffer);
}

export function createSessionToken(userId: number): string {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
  db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)').run(
    token,
    userId,
    expiresAt
  );
  return token;
}
