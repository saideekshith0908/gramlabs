import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';
import { createSessionToken, db, hashPassword, initDatabase, verifyPassword } from './server/db.ts';
import { seedDatabase } from './server/seed.ts';
import { calculateSkillMatch } from './shared/skillMatching.ts';
import type {
  ApplicationStatus,
  AuthUser,
  CandidateProfile,
  CertificationStatus,
  EmployerProfile,
  JobPosting,
  TradeCategoryId,
  UserRole,
} from './shared/vocational.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

initDatabase();
seedDatabase();

interface AuthedRequest extends Request {
  user?: AuthUser;
}

function parseJsonArray(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}

function mapJobRow(row: Record<string, unknown>): JobPosting {
  return {
    id: Number(row.id),
    employerId: Number(row.employer_id),
    titleEn: String(row.title_en),
    titleHi: String(row.title_hi),
    companyName: String(row.company_name),
    companyNameHi: String(row.company_name_hi),
    category: String(row.category) as TradeCategoryId,
    descriptionEn: String(row.description_en),
    descriptionHi: String(row.description_hi),
    responsibilitiesEn: parseJsonArray(row.responsibilities_json_en as string),
    responsibilitiesHi: parseJsonArray(row.responsibilities_json_hi as string),
    requiredSkills: parseJsonArray(row.required_skills_json as string),
    salaryMonthly: Number(row.salary_monthly),
    locationDistrict: String(row.location_district),
    locationState: String(row.location_state),
    proximityKm: Number(row.proximity_km),
    accommodationFree: Boolean(row.accommodation_free),
    foodProvided: Boolean(row.food_provided),
    experienceMinYears: Number(row.experience_min_years),
    employmentType: String(row.employment_type) as JobPosting['employmentType'],
    contactPhone: String(row.contact_phone),
    whatsappPhone: String(row.whatsapp_phone),
    postedDate: String(row.posted_date),
    approvalStatus: String(row.approval_status) as JobPosting['approvalStatus'],
    isSample: Boolean(row.is_sample),
    featuredImage: String(row.featured_image || ''),
  };
}

function mapCandidateRow(row: Record<string, unknown>): CandidateProfile {
  return {
    userId: Number(row.user_id),
    fullName: String(row.full_name),
    mobile: String(row.mobile),
    mobileStatus: String(row.mobile_status || 'registered') as CandidateProfile['mobileStatus'],
    homeDistrict: String(row.home_district),
    state: String(row.state),
    skills: parseJsonArray(row.skills_json as string),
    experienceYears: Number(row.experience_years),
    itiQualified: Boolean(row.iti_qualified),
    itiTrade: String(row.iti_trade || ''),
    itiCertificateCode: String(row.iti_certificate_code || ''),
    itiStatus: String(row.iti_status || 'not_submitted') as CertificationStatus,
    pmkvyCertified: Boolean(row.pmkvy_certified),
    pmkvyTrade: String(row.pmkvy_trade || ''),
    pmkvyCertificateCode: String(row.pmkvy_certificate_code || ''),
    pmkvyStatus: String(row.pmkvy_status || 'not_submitted') as CertificationStatus,
    availabilityDate: String(row.availability_date || ''),
    updatedAt: String(row.updated_at || ''),
  };
}

function mapEmployerRow(row: Record<string, unknown>): EmployerProfile {
  return {
    id: Number(row.id),
    userId: Number(row.user_id),
    companyName: String(row.company_name),
    companyNameHi: String(row.company_name_hi || row.company_name),
    sector: String(row.sector),
    district: String(row.district),
    state: String(row.state),
    contactPhone: String(row.contact_phone),
    whatsappPhone: String(row.whatsapp_phone),
    description: String(row.description || ''),
    descriptionHi: String(row.description_hi || ''),
    verified: Boolean(row.verified),
    createdAt: String(row.created_at || ''),
  };
}

function attachAuthUser(req: AuthedRequest, _res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    next();
    return;
  }
  const token = authHeader.slice(7).trim();
  if (!token) {
    next();
    return;
  }

  const sessionRow = db
    .prepare(
      `SELECT u.id, u.name, u.phone, u.role, s.expires_at
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token = ?`
    )
    .get(token) as
    | { id: number; name: string; phone: string; role: UserRole; expires_at: string }
    | undefined;

  if (sessionRow && new Date(sessionRow.expires_at).getTime() > Date.now()) {
    req.user = {
      id: sessionRow.id,
      name: sessionRow.name,
      phone: sessionRow.phone,
      role: sessionRow.role,
    };
  }
  next();
}

function requireAuth(roles?: UserRole[]) {
  return (req: AuthedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required. Please sign in.' });
      return;
    }
    if (roles && !roles.includes(req.user.role)) {
      res.status(403).json({ error: 'Access denied for your account role.' });
      return;
    }
    next();
  };
}

function normalizePhone(input: string): string {
  return input.replace(/\D/g, '').slice(-10);
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));
  app.use(attachAuthUser);

  // Health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  // Register Candidate or Employer
  app.post('/api/auth/register', (req, res) => {
    const {
      name,
      phone,
      password,
      role,
      district,
      state,
      companyName,
      sector,
    } = req.body as Record<string, string>;

    const cleanPhone = normalizePhone(String(phone || ''));
    if (!name || String(name).trim().length < 2) {
      res.status(400).json({ error: 'Please enter a valid full name.' });
      return;
    }
    if (cleanPhone.length !== 10) {
      res.status(400).json({ error: 'Please enter a valid 10-digit mobile number.' });
      return;
    }
    if (!password || String(password).length < 4) {
      res.status(400).json({ error: 'PIN/Password must be at least 4 characters.' });
      return;
    }
    const targetRole: UserRole = role === 'employer' ? 'employer' : 'candidate';

    const existing = db.prepare('SELECT id FROM users WHERE phone = ?').get(cleanPhone);
    if (existing) {
      res.status(409).json({ error: 'This mobile number is already registered. Please sign in.' });
      return;
    }

    const tx = db.transaction(() => {
      const result = db
        .prepare('INSERT INTO users (name, phone, password_hash, role) VALUES (?, ?, ?, ?)')
        .run(String(name).trim(), cleanPhone, hashPassword(String(password)), targetRole);
      const userId = Number(result.lastInsertRowid);

      if (targetRole === 'candidate') {
        db.prepare(
          `INSERT INTO candidate_profiles (
            user_id, full_name, mobile, mobile_status, home_district, state, skills_json, availability_date
          ) VALUES (?, ?, ?, 'registered', ?, ?, '[]', ?)`
        ).run(
          userId,
          String(name).trim(),
          cleanPhone,
          String(district || 'Jaipur').trim(),
          String(state || 'Rajasthan').trim(),
          new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10)
        );
      } else {
        const comp = String(companyName || `${String(name).trim()} Enterprises`).trim();
        db.prepare(
          `INSERT INTO employers (
            user_id, company_name, company_name_hi, sector, district, state, contact_phone, whatsapp_phone, verified
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`
        ).run(
          userId,
          comp,
          comp,
          String(sector || 'Rural Enterprise').trim(),
          String(district || 'Jaipur').trim(),
          String(state || 'Rajasthan').trim(),
          cleanPhone,
          `91${cleanPhone}`
        );
      }

      const token = createSessionToken(userId);
      return { userId, token };
    });

    const { userId, token } = tx();
    const user: AuthUser = { id: userId, name: String(name).trim(), phone: cleanPhone, role: targetRole };
    res.status(201).json({ token, user });
  });

  // Sign In
  app.post('/api/auth/login', (req, res) => {
    const { phone, password } = req.body as { phone?: string; password?: string };
    const cleanPhone = normalizePhone(String(phone || ''));
    if (cleanPhone.length !== 10 || !password) {
      res.status(400).json({ error: 'Enter a 10-digit mobile number and PIN/password.' });
      return;
    }

    const row = db
      .prepare('SELECT id, name, phone, password_hash, role FROM users WHERE phone = ?')
      .get(cleanPhone) as
      | { id: number; name: string; phone: string; password_hash: string; role: UserRole }
      | undefined;

    if (!row || !verifyPassword(String(password), row.password_hash)) {
      res.status(401).json({ error: 'Invalid mobile number or PIN/password.' });
      return;
    }

    const token = createSessionToken(row.id);
    const user: AuthUser = { id: row.id, name: row.name, phone: row.phone, role: row.role };
    res.json({ token, user });
  });

  // Sign Out
  app.post('/api/auth/logout', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.slice(7).trim();
      db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    }
    res.json({ ok: true });
  });

  // Current user + role profile
  app.get('/api/auth/me', (req: AuthedRequest, res) => {
    if (!req.user) {
      res.json({ user: null, candidateProfile: null, employerProfile: null });
      return;
    }

    let candidateProfile: CandidateProfile | null = null;
    let employerProfile: EmployerProfile | null = null;

    if (req.user.role === 'candidate') {
      const row = db
        .prepare('SELECT * FROM candidate_profiles WHERE user_id = ?')
        .get(req.user.id) as Record<string, unknown> | undefined;
      if (row) candidateProfile = mapCandidateRow(row);
    } else if (req.user.role === 'employer') {
      const row = db
        .prepare('SELECT * FROM employers WHERE user_id = ?')
        .get(req.user.id) as Record<string, unknown> | undefined;
      if (row) employerProfile = mapEmployerRow(row);
    }

    res.json({ user: req.user, candidateProfile, employerProfile });
  });

  // Public Job Directory (only approved jobs; never leaks candidate info)
  app.get('/api/jobs', (req: AuthedRequest, res) => {
    const search = String(req.query.search || '').trim().toLowerCase();
    const category = String(req.query.category || '').trim();
    const location = String(req.query.location || '').trim().toLowerCase();
    const minSalary = Number(req.query.minSalary || 0);
    const maxExp = req.query.maxExp !== undefined && req.query.maxExp !== '' ? Number(req.query.maxExp) : null;
    const accommodationOnly = req.query.accommodationOnly === 'true';

    // Determine candidate skills for matching (from query param or logged-in candidate)
    let candidateSkills: string[] = [];
    if (typeof req.query.skills === 'string' && req.query.skills.trim()) {
      candidateSkills = req.query.skills
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
    } else if (req.user?.role === 'candidate') {
      const profileRow = db
        .prepare('SELECT skills_json FROM candidate_profiles WHERE user_id = ?')
        .get(req.user.id) as { skills_json: string } | undefined;
      if (profileRow) {
        candidateSkills = parseJsonArray(profileRow.skills_json);
      }
    }

    const rows = db
      .prepare("SELECT * FROM jobs WHERE approval_status = 'approved' ORDER BY id ASC")
      .all() as Record<string, unknown>[];

    let jobs = rows.map(mapJobRow);

    if (search) {
      jobs = jobs.filter(
        (j) =>
          j.titleEn.toLowerCase().includes(search) ||
          j.titleHi.toLowerCase().includes(search) ||
          j.companyName.toLowerCase().includes(search) ||
          j.requiredSkills.some((s) => s.toLowerCase().includes(search)) ||
          j.locationDistrict.toLowerCase().includes(search)
      );
    }
    if (category && category !== 'all') {
      jobs = jobs.filter((j) => j.category === category);
    }
    if (location && location !== 'all') {
      jobs = jobs.filter(
        (j) =>
          j.locationDistrict.toLowerCase().includes(location) ||
          j.locationState.toLowerCase().includes(location)
      );
    }
    if (minSalary > 0) {
      jobs = jobs.filter((j) => j.salaryMonthly >= minSalary);
    }
    if (maxExp !== null && !Number.isNaN(maxExp)) {
      jobs = jobs.filter((j) => j.experienceMinYears <= maxExp);
    }
    if (accommodationOnly) {
      jobs = jobs.filter((j) => j.accommodationFree);
    }

    const enriched = jobs.map((job) => ({
      ...job,
      match: calculateSkillMatch(candidateSkills, job.requiredSkills),
    }));

    if (candidateSkills.length > 0) {
      enriched.sort((a, b) => b.match.score - a.match.score || b.salaryMonthly - a.salaryMonthly);
    }

    res.json({ jobs: enriched, total: enriched.length });
  });

  // Single job detail
  app.get('/api/jobs/:id', (req: AuthedRequest, res) => {
    const jobId = Number(req.params.id);
    if (!Number.isInteger(jobId)) {
      res.status(400).json({ error: 'Invalid job ID.' });
      return;
    }
    const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Job vacancy not found.' });
      return;
    }
    const job = mapJobRow(row);
    if (job.approvalStatus !== 'approved' && req.user?.role !== 'admin') {
      res.status(404).json({ error: 'Job vacancy not found.' });
      return;
    }
    res.json({ job });
  });

  // Candidate Profile GET & PUT
  app.get('/api/candidate/profile', requireAuth(['candidate']), (req: AuthedRequest, res) => {
    const row = db
      .prepare('SELECT * FROM candidate_profiles WHERE user_id = ?')
      .get(req.user!.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Candidate profile not found.' });
      return;
    }
    res.json({ profile: mapCandidateRow(row) });
  });

  app.put('/api/candidate/profile', requireAuth(['candidate']), (req: AuthedRequest, res) => {
    const userId = req.user!.id;
    const existingRow = db
      .prepare('SELECT * FROM candidate_profiles WHERE user_id = ?')
      .get(userId) as Record<string, unknown> | undefined;
    const existing = existingRow ? mapCandidateRow(existingRow) : null;

    const {
      fullName,
      mobile,
      homeDistrict,
      state,
      skills,
      experienceYears,
      itiQualified,
      itiTrade,
      itiCertificateCode,
      pmkvyCertified,
      pmkvyTrade,
      pmkvyCertificateCode,
      availabilityDate,
    } = req.body as Partial<CandidateProfile>;

    const cleanName = String(fullName || existing?.fullName || req.user!.name).trim();
    const cleanMobile = normalizePhone(String(mobile || existing?.mobile || req.user!.phone));
    if (cleanName.length < 2) {
      res.status(400).json({ error: 'Full name is required.' });
      return;
    }
    if (cleanMobile.length !== 10) {
      res.status(400).json({ error: 'A valid 10-digit mobile number is required.' });
      return;
    }

    const cleanSkills = Array.isArray(skills) ? skills.map(String).filter(Boolean) : existing?.skills || [];
    const expYears = Math.max(0, Math.min(40, Number(experienceYears ?? existing?.experienceYears ?? 0)));

    // Certificate status integrity: NEVER auto-verify!
    // If candidate enters/changes certificate code or checks qualification, set status to 'pending' (unless already verified & unchanged)
    const nextItiQualified = Boolean(itiQualified);
    const nextItiCode = String(itiCertificateCode || '').trim();
    const nextItiTrade = String(itiTrade || '').trim();
    let nextItiStatus: CertificationStatus = 'not_submitted';
    if (nextItiQualified && nextItiCode) {
      if (
        existing &&
        existing.itiStatus === 'verified' &&
        existing.itiCertificateCode === nextItiCode &&
        existing.itiTrade === nextItiTrade
      ) {
        nextItiStatus = 'verified';
      } else {
        nextItiStatus = 'pending';
      }
    }

    const nextPmkvyCertified = Boolean(pmkvyCertified);
    const nextPmkvyCode = String(pmkvyCertificateCode || '').trim();
    const nextPmkvyTrade = String(pmkvyTrade || '').trim();
    let nextPmkvyStatus: CertificationStatus = 'not_submitted';
    if (nextPmkvyCertified && nextPmkvyCode) {
      if (
        existing &&
        existing.pmkvyStatus === 'verified' &&
        existing.pmkvyCertificateCode === nextPmkvyCode &&
        existing.pmkvyTrade === nextPmkvyTrade
      ) {
        nextPmkvyStatus = 'verified';
      } else {
        nextPmkvyStatus = 'pending';
      }
    }

    db.prepare(
      `INSERT INTO candidate_profiles (
        user_id, full_name, mobile, mobile_status, home_district, state, skills_json,
        experience_years, iti_qualified, iti_trade, iti_certificate_code, iti_status,
        pmkvy_certified, pmkvy_trade, pmkvy_certificate_code, pmkvy_status, availability_date, updated_at
      ) VALUES (?, ?, ?, 'registered', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(user_id) DO UPDATE SET
        full_name = excluded.full_name,
        mobile = excluded.mobile,
        home_district = excluded.home_district,
        state = excluded.state,
        skills_json = excluded.skills_json,
        experience_years = excluded.experience_years,
        iti_qualified = excluded.iti_qualified,
        iti_trade = excluded.iti_trade,
        iti_certificate_code = excluded.iti_certificate_code,
        iti_status = excluded.iti_status,
        pmkvy_certified = excluded.pmkvy_certified,
        pmkvy_trade = excluded.pmkvy_trade,
        pmkvy_certificate_code = excluded.pmkvy_certificate_code,
        pmkvy_status = excluded.pmkvy_status,
        availability_date = excluded.availability_date,
        updated_at = datetime('now')`
    ).run(
      userId,
      cleanName,
      cleanMobile,
      String(homeDistrict || existing?.homeDistrict || 'Jaipur').trim(),
      String(state || existing?.state || 'Rajasthan').trim(),
      JSON.stringify(cleanSkills),
      expYears,
      nextItiQualified ? 1 : 0,
      nextItiTrade,
      nextItiCode,
      nextItiStatus,
      nextPmkvyCertified ? 1 : 0,
      nextPmkvyTrade,
      nextPmkvyCode,
      nextPmkvyStatus,
      String(availabilityDate || existing?.availabilityDate || '').trim()
    );

    db.prepare('UPDATE users SET name = ? WHERE id = ?').run(cleanName, userId);

    const updated = db
      .prepare('SELECT * FROM candidate_profiles WHERE user_id = ?')
      .get(userId) as Record<string, unknown>;
    res.json({ profile: mapCandidateRow(updated) });
  });

  // One-Tap Quick Apply
  app.post('/api/applications', requireAuth(['candidate']), (req: AuthedRequest, res) => {
    const candidateUserId = req.user!.id;
    const { jobId, availabilityDate } = req.body as { jobId?: number; availabilityDate?: string };

    const numericJobId = Number(jobId);
    if (!Number.isInteger(numericJobId)) {
      res.status(400).json({ error: 'Valid job ID is required.' });
      return;
    }

    const jobRow = db
      .prepare("SELECT id FROM jobs WHERE id = ? AND approval_status = 'approved'")
      .get(numericJobId);
    if (!jobRow) {
      res.status(404).json({ error: 'Job vacancy not available.' });
      return;
    }

    const profileRow = db
      .prepare('SELECT availability_date, skills_json FROM candidate_profiles WHERE user_id = ?')
      .get(candidateUserId) as { availability_date: string; skills_json: string } | undefined;

    const finalAvailability = String(availabilityDate || profileRow?.availability_date || '').trim();
    if (!finalAvailability) {
      res.status(400).json({ error: 'Please specify your availability date to apply.' });
      return;
    }

    const duplicate = db
      .prepare('SELECT id FROM applications WHERE job_id = ? AND candidate_user_id = ?')
      .get(numericJobId, candidateUserId);
    if (duplicate) {
      res.status(409).json({ error: 'You have already applied for this job vacancy.' });
      return;
    }

    // Save availability date to profile if missing
    if (profileRow && !profileRow.availability_date) {
      db.prepare('UPDATE candidate_profiles SET availability_date = ? WHERE user_id = ?').run(
        finalAvailability,
        candidateUserId
      );
    }

    const result = db
      .prepare(
        `INSERT INTO applications (job_id, candidate_user_id, availability_date, status)
         VALUES (?, ?, ?, 'Applied')`
      )
      .run(numericJobId, candidateUserId, finalAvailability);

    const created = db
      .prepare('SELECT * FROM applications WHERE id = ?')
      .get(Number(result.lastInsertRowid)) as Record<string, unknown>;

    res.status(201).json({
      application: {
        id: Number(created.id),
        jobId: Number(created.job_id),
        candidateUserId: Number(created.candidate_user_id),
        availabilityDate: String(created.availability_date),
        status: String(created.status) as ApplicationStatus,
        employerNotes: String(created.employer_notes || ''),
        appliedAt: String(created.applied_at),
        updatedAt: String(created.updated_at),
      },
    });
  });

  // Candidate's own applications
  app.get('/api/candidate/applications', requireAuth(['candidate']), (req: AuthedRequest, res) => {
    const rows = db
      .prepare(
        `SELECT a.*, j.id as j_id, j.employer_id, j.title_en, j.title_hi, j.company_name, j.company_name_hi,
                j.category, j.description_en, j.description_hi, j.responsibilities_json_en, j.responsibilities_json_hi,
                j.required_skills_json, j.salary_monthly, j.location_district, j.location_state, j.proximity_km,
                j.accommodation_free, j.food_provided, j.experience_min_years, j.employment_type,
                j.contact_phone, j.whatsapp_phone, j.posted_date, j.approval_status, j.is_sample, j.featured_image
         FROM applications a
         JOIN jobs j ON j.id = a.job_id
         WHERE a.candidate_user_id = ?
         ORDER BY a.applied_at DESC`
      )
      .all(req.user!.id) as Record<string, unknown>[];

    const applications = rows.map((row) => ({
      id: Number(row.id),
      jobId: Number(row.job_id),
      candidateUserId: Number(row.candidate_user_id),
      availabilityDate: String(row.availability_date),
      status: String(row.status) as ApplicationStatus,
      employerNotes: String(row.employer_notes || ''),
      appliedAt: String(row.applied_at),
      updatedAt: String(row.updated_at),
      job: mapJobRow({ ...row, id: row.j_id }),
    }));

    res.json({ applications });
  });

  // Employer Overview
  app.get('/api/employer/overview', requireAuth(['employer']), (req: AuthedRequest, res) => {
    const empRow = db
      .prepare('SELECT * FROM employers WHERE user_id = ?')
      .get(req.user!.id) as Record<string, unknown> | undefined;

    if (!empRow) {
      res.status(404).json({ error: 'Employer profile not found.' });
      return;
    }

    const employer = mapEmployerRow(empRow);
    const jobRows = db
      .prepare('SELECT * FROM jobs WHERE employer_id = ? ORDER BY id DESC')
      .all(employer.id) as Record<string, unknown>[];
    const jobs = jobRows.map(mapJobRow);

    const appRows = db
      .prepare(
        `SELECT a.*, j.title_en, j.title_hi, j.location_district, j.salary_monthly, j.required_skills_json,
                c.full_name, c.mobile, c.mobile_status, c.home_district, c.state, c.skills_json,
                c.experience_years, c.iti_qualified, c.iti_trade, c.iti_certificate_code, c.iti_status,
                c.pmkvy_certified, c.pmkvy_trade, c.pmkvy_certificate_code, c.pmkvy_status,
                c.availability_date as c_avail, c.updated_at as c_updated
         FROM applications a
         JOIN jobs j ON j.id = a.job_id
         JOIN candidate_profiles c ON c.user_id = a.candidate_user_id
         WHERE j.employer_id = ?
         ORDER BY a.applied_at DESC`
      )
      .all(employer.id) as Record<string, unknown>[];

    const applications = appRows.map((row) => {
      const candidateSkills = parseJsonArray(row.skills_json as string);
      const requiredSkills = parseJsonArray(row.required_skills_json as string);
      return {
        id: Number(row.id),
        jobId: Number(row.job_id),
        jobTitleEn: String(row.title_en),
        jobTitleHi: String(row.title_hi),
        candidateUserId: Number(row.candidate_user_id),
        availabilityDate: String(row.availability_date),
        status: String(row.status) as ApplicationStatus,
        employerNotes: String(row.employer_notes || ''),
        appliedAt: String(row.applied_at),
        updatedAt: String(row.updated_at),
        matchScore: calculateSkillMatch(candidateSkills, requiredSkills).score,
        candidate: mapCandidateRow({
          user_id: row.candidate_user_id,
          full_name: row.full_name,
          mobile: row.mobile,
          mobile_status: row.mobile_status,
          home_district: row.home_district,
          state: row.state,
          skills_json: row.skills_json,
          experience_years: row.experience_years,
          iti_qualified: row.iti_qualified,
          iti_trade: row.iti_trade,
          iti_certificate_code: row.iti_certificate_code,
          iti_status: row.iti_status,
          pmkvy_certified: row.pmkvy_certified,
          pmkvy_trade: row.pmkvy_trade,
          pmkvy_certificate_code: row.pmkvy_certificate_code,
          pmkvy_status: row.pmkvy_status,
          availability_date: row.c_avail,
          updated_at: row.c_updated,
        }),
      };
    });

    res.json({ employer, jobs, applications });
  });

  // Employer Update Profile
  app.put('/api/employer/profile', requireAuth(['employer']), (req: AuthedRequest, res) => {
    const { companyName, companyNameHi, sector, district, state, contactPhone, whatsappPhone, description, descriptionHi } =
      req.body as Partial<EmployerProfile>;
    if (!companyName || String(companyName).trim().length < 2) {
      res.status(400).json({ error: 'Company name is required.' });
      return;
    }
    const cleanPhone = normalizePhone(String(contactPhone || req.user!.phone));
    const cleanWa = String(whatsappPhone || `91${cleanPhone}`).replace(/\D/g, '');

    db.prepare(
      `UPDATE employers SET
        company_name = ?, company_name_hi = ?, sector = ?, district = ?, state = ?,
        contact_phone = ?, whatsapp_phone = ?, description = ?, description_hi = ?
       WHERE user_id = ?`
    ).run(
      String(companyName).trim(),
      String(companyNameHi || companyName).trim(),
      String(sector || 'Rural Enterprise').trim(),
      String(district || 'Jaipur').trim(),
      String(state || 'Rajasthan').trim(),
      cleanPhone,
      cleanWa,
      String(description || '').trim(),
      String(descriptionHi || '').trim(),
      req.user!.id
    );

    const updated = db.prepare('SELECT * FROM employers WHERE user_id = ?').get(req.user!.id) as Record<
      string,
      unknown
    >;
    res.json({ employer: mapEmployerRow(updated) });
  });

  // Employer Post New Job (validated, starts as 'pending' awaiting Admin approval)
  app.post('/api/employer/jobs', requireAuth(['employer']), (req: AuthedRequest, res) => {
    const empRow = db
      .prepare('SELECT * FROM employers WHERE user_id = ?')
      .get(req.user!.id) as Record<string, unknown> | undefined;
    if (!empRow) {
      res.status(404).json({ error: 'Employer profile not found.' });
      return;
    }
    const employer = mapEmployerRow(empRow);

    const {
      titleEn,
      titleHi,
      category,
      descriptionEn,
      descriptionHi,
      requiredSkills,
      salaryMonthly,
      locationDistrict,
      locationState,
      accommodationFree,
      foodProvided,
      experienceMinYears,
      employmentType,
    } = req.body as Partial<JobPosting>;

    if (!titleEn || String(titleEn).trim().length < 3) {
      res.status(400).json({ error: 'Job title is required.' });
      return;
    }
    if (!descriptionEn || String(descriptionEn).trim().length < 15) {
      res.status(400).json({ error: 'Please provide a clear job description (min 15 characters).' });
      return;
    }
    if (!Array.isArray(requiredSkills) || requiredSkills.length === 0) {
      res.status(400).json({ error: 'Select at least one required vocational skill.' });
      return;
    }
    const salary = Number(salaryMonthly);
    if (!Number.isFinite(salary) || salary < 5000 || salary > 200000) {
      res.status(400).json({ error: 'Monthly salary must be between ₹5,000 and ₹2,00,000.' });
      return;
    }

    const cat = String(category || 'solar') as TradeCategoryId;
    const categoryImageMap: Record<string, string> = {
      solar: '/src/assets/images/hero_solar_technician_1795114646236.jpg',
      agriculture: '/src/assets/images/trade_agri_supervisor_1795114646469.jpg',
      mechanical: '/src/assets/images/trade_iti_mechanic_1795114647967.jpg',
      electrical: '/src/assets/images/trade_iti_mechanic_1795114647967.jpg',
      welding: '/src/assets/images/trade_iti_mechanic_1795114647967.jpg',
      electronics: '/src/assets/images/trade_iti_mechanic_1795114647967.jpg',
      healthcare: '/src/assets/images/rural_enterprise_lead_1795114646855.jpg',
      retail: '/src/assets/images/rural_enterprise_lead_1795114646855.jpg',
    };

    const today = new Date().toISOString().slice(0, 10);
    const result = db
      .prepare(
        `INSERT INTO jobs (
          employer_id, title_en, title_hi, company_name, company_name_hi, category,
          description_en, description_hi, responsibilities_json_en, responsibilities_json_hi,
          required_skills_json, salary_monthly, location_district, location_state,
          proximity_km, accommodation_free, food_provided, experience_min_years,
          employment_type, contact_phone, whatsapp_phone, posted_date, approval_status,
          is_sample, featured_image
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0, ?)`
      )
      .run(
        employer.id,
        String(titleEn).trim(),
        String(titleHi || titleEn).trim(),
        employer.companyName,
        employer.companyNameHi || employer.companyName,
        cat,
        String(descriptionEn).trim(),
        String(descriptionHi || descriptionEn).trim(),
        JSON.stringify(['Perform core technical trade duties safely on site', 'Coordinate with regional supervisor']),
        JSON.stringify(['कार्यस्थल पर सुरक्षित रूप से तकनीकी कार्य करना', 'क्षेत्रीय सुपरवाइजर के साथ समन्वय करना']),
        JSON.stringify(requiredSkills.map(String)),
        salary,
        String(locationDistrict || employer.district).trim(),
        String(locationState || employer.state).trim(),
        25,
        accommodationFree ? 1 : 0,
        foodProvided ? 1 : 0,
        Math.max(0, Number(experienceMinYears || 0)),
        String(employmentType || 'Full-Time'),
        employer.contactPhone,
        employer.whatsappPhone,
        today,
        categoryImageMap[cat] || categoryImageMap.solar
      );

    const created = db
      .prepare('SELECT * FROM jobs WHERE id = ?')
      .get(Number(result.lastInsertRowid)) as Record<string, unknown>;
    res.status(201).json({ job: mapJobRow(created) });
  });

  // Employer Update Application Status / Interview Call
  app.patch('/api/employer/applications/:id', requireAuth(['employer', 'admin']), (req: AuthedRequest, res) => {
    const appId = Number(req.params.id);
    const { status, employerNotes } = req.body as { status?: ApplicationStatus; employerNotes?: string };
    const allowed: ApplicationStatus[] = [
      'Applied',
      'Under Review',
      'Shortlisted',
      'Interview Call',
      'Rejected',
      'Selected',
    ];
    if (!status || !allowed.includes(status)) {
      res.status(400).json({ error: 'Invalid application status.' });
      return;
    }

    if (req.user!.role === 'employer') {
      const owns = db
        .prepare(
          `SELECT a.id FROM applications a
           JOIN jobs j ON j.id = a.job_id
           JOIN employers e ON e.id = j.employer_id
           WHERE a.id = ? AND e.user_id = ?`
        )
        .get(appId, req.user!.id);
      if (!owns) {
        res.status(403).json({ error: 'You cannot update applications for other employers.' });
        return;
      }
    }

    db.prepare(
      `UPDATE applications SET status = ?, employer_notes = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(status, String(employerNotes || '').trim(), appId);

    res.json({ ok: true });
  });

  // Admin Dashboard Overview
  app.get('/api/admin/overview', requireAuth(['admin']), (_req, res) => {
    const candidateRows = db
      .prepare('SELECT * FROM candidate_profiles ORDER BY updated_at DESC')
      .all() as Record<string, unknown>[];
    const employerRows = db
      .prepare('SELECT * FROM employers ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];
    const jobRows = db
      .prepare('SELECT * FROM jobs ORDER BY CASE WHEN approval_status = "pending" THEN 0 ELSE 1 END, id DESC')
      .all() as Record<string, unknown>[];
    const appRows = db
      .prepare(
        `SELECT a.*, j.title_en, j.title_hi, j.company_name, c.full_name, c.home_district
         FROM applications a
         JOIN jobs j ON j.id = a.job_id
         JOIN candidate_profiles c ON c.user_id = a.candidate_user_id
         ORDER BY a.applied_at DESC`
      )
      .all() as Record<string, unknown>[];

    const candidates = candidateRows.map(mapCandidateRow);
    const employers = employerRows.map(mapEmployerRow);
    const jobs = jobRows.map(mapJobRow);
    const applications = appRows.map((r) => ({
      id: Number(r.id),
      jobId: Number(r.job_id),
      jobTitleEn: String(r.title_en),
      jobTitleHi: String(r.title_hi),
      companyName: String(r.company_name),
      candidateName: String(r.full_name),
      candidateDistrict: String(r.home_district),
      availabilityDate: String(r.availability_date),
      status: String(r.status) as ApplicationStatus,
      appliedAt: String(r.applied_at),
    }));

    const pendingJobs = jobs.filter((j) => j.approvalStatus === 'pending');
    const pendingCerts = candidates.filter(
      (c) => c.itiStatus === 'pending' || c.pmkvyStatus === 'pending'
    );

    res.json({
      stats: {
        totalCandidates: candidates.length,
        totalEmployers: employers.length,
        totalJobs: jobs.length,
        totalApplications: applications.length,
        pendingApprovals: pendingJobs.length,
        pendingCertificates: pendingCerts.length,
      },
      candidates,
      employers,
      jobs,
      pendingJobs,
      pendingCerts,
      applications,
    });
  });

  // Admin Job Approval / Rejection
  app.patch('/api/admin/jobs/:id/approval', requireAuth(['admin']), (req, res) => {
    const jobId = Number(req.params.id);
    const { approvalStatus } = req.body as { approvalStatus?: 'approved' | 'rejected' | 'pending' };
    if (!approvalStatus || !['approved', 'rejected', 'pending'].includes(approvalStatus)) {
      res.status(400).json({ error: 'Invalid approval status.' });
      return;
    }
    db.prepare('UPDATE jobs SET approval_status = ? WHERE id = ?').run(approvalStatus, jobId);
    res.json({ ok: true });
  });

  // Admin Certificate Verification (ITI / PMKVY)
  app.patch('/api/admin/certificates/:userId', requireAuth(['admin']), (req, res) => {
    const userId = Number(req.params.userId);
    const { type, status } = req.body as { type?: 'iti' | 'pmkvy'; status?: 'verified' | 'rejected' };
    if (!type || !['iti', 'pmkvy'].includes(type) || !status || !['verified', 'rejected'].includes(status)) {
      res.status(400).json({ error: 'Invalid certificate verification parameters.' });
      return;
    }
    if (type === 'iti') {
      db.prepare("UPDATE candidate_profiles SET iti_status = ?, updated_at = datetime('now') WHERE user_id = ?").run(
        status,
        userId
      );
    } else {
      db.prepare("UPDATE candidate_profiles SET pmkvy_status = ?, updated_at = datetime('now') WHERE user_id = ?").run(
        status,
        userId
      );
    }
    res.json({ ok: true });
  });

  // Admin Employer Verification Toggle
  app.patch('/api/admin/employers/:id/verify', requireAuth(['admin']), (req, res) => {
    const empId = Number(req.params.id);
    const { verified } = req.body as { verified?: boolean };
    db.prepare('UPDATE employers SET verified = ? WHERE id = ?').run(verified ? 1 : 0, empId);
    res.json({ ok: true });
  });

  // Vite dev middleware or static production build
  const distPath = path.resolve(__dirname, 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distPath);

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GramJobs – RuralRise server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
