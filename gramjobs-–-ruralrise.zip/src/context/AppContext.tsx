import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type {
  AuthUser,
  CandidateProfile,
  EmployerProfile,
  JobApplicationRecord,
  JobPosting,
  Language,
} from '../../shared/vocational';
import type { SkillMatchBreakdown } from '../../shared/skillMatching';
import { TRANSLATIONS, type TranslationBundle } from '../i18n/translations';

export type AppView = 'directory' | 'profile' | 'applications' | 'employer' | 'admin';

export interface EnrichedJob extends JobPosting {
  match: SkillMatchBreakdown;
}

interface AppContextValue {
  lang: Language;
  setLang: (lang: Language) => void;
  t: TranslationBundle;
  view: AppView;
  setView: (view: AppView) => void;
  token: string | null;
  user: AuthUser | null;
  candidateProfile: CandidateProfile | null;
  employerProfile: EmployerProfile | null;
  activeSkills: string[];
  setGuestSkills: (skills: string[]) => void;
  appliedJobIds: Set<number>;
  candidateApplications: JobApplicationRecord[];
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  selectedJob: EnrichedJob | null;
  setSelectedJob: (job: EnrichedJob | null) => void;
  quickApplyJob: EnrichedJob | null;
  setQuickApplyJob: (job: EnrichedJob | null) => void;
  login: (phone: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  register: (payload: {
    name: string;
    phone: string;
    password: string;
    role: 'candidate' | 'employer';
    district: string;
    state: string;
    companyName?: string;
    sector?: string;
  }) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshSession: () => Promise<void>;
  refreshCandidateApplications: () => Promise<void>;
  apiFetch: (url: string, options?: RequestInit) => Promise<Response>;
}

const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_TOKEN_KEY = 'gramjobs_token';
const STORAGE_LANG_KEY = 'gramjobs_lang';
const STORAGE_GUEST_SKILLS_KEY = 'gramjobs_guest_skills';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_LANG_KEY);
    return saved === 'hi' ? 'hi' : 'en';
  });

  const [view, setView] = useState<AppView>('directory');
  const [token, setToken] = useState<string | null>(() => localStorage.getItem(STORAGE_TOKEN_KEY));
  const [user, setUser] = useState<AuthUser | null>(null);
  const [candidateProfile, setCandidateProfile] = useState<CandidateProfile | null>(null);
  const [employerProfile, setEmployerProfile] = useState<EmployerProfile | null>(null);
  const [guestSkills, setGuestSkillsState] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_GUEST_SKILLS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed.map(String);
      }
    } catch {
      // ignore storage errors
    }
    return ['Solar PV Installation', 'Electrical Wiring'];
  });

  const [candidateApplications, setCandidateApplications] = useState<JobApplicationRecord[]>([]);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState<EnrichedJob | null>(null);
  const [quickApplyJob, setQuickApplyJob] = useState<EnrichedJob | null>(null);

  const setLang = useCallback((nextLang: Language) => {
    setLangState(nextLang);
    localStorage.setItem(STORAGE_LANG_KEY, nextLang);
    document.documentElement.lang = nextLang === 'hi' ? 'hi' : 'en';
  }, []);

  const setGuestSkills = useCallback((skills: string[]) => {
    setGuestSkillsState(skills);
    localStorage.setItem(STORAGE_GUEST_SKILLS_KEY, JSON.stringify(skills));
  }, []);

  const apiFetch = useCallback(
    async (url: string, options: RequestInit = {}) => {
      const headers = new Headers(options.headers || {});
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      if (options.body && !headers.has('Content-Type')) {
        headers.set('Content-Type', 'application/json');
      }
      return fetch(url, { ...options, headers });
    },
    [token]
  );

  const refreshCandidateApplications = useCallback(async () => {
    if (!token) {
      setCandidateApplications([]);
      return;
    }
    try {
      const res = await fetch('/api/candidate/applications', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setCandidateApplications(data.applications || []);
      }
    } catch {
      // ignore
    }
  }, [token]);

  const refreshSession = useCallback(async () => {
    if (!token) {
      setUser(null);
      setCandidateProfile(null);
      setEmployerProfile(null);
      setCandidateApplications([]);
      return;
    }
    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        setToken(null);
        localStorage.removeItem(STORAGE_TOKEN_KEY);
        return;
      }
      const data = await res.json();
      setUser(data.user || null);
      setCandidateProfile(data.candidateProfile || null);
      setEmployerProfile(data.employerProfile || null);
      if (!data.user) {
        setToken(null);
        localStorage.removeItem(STORAGE_TOKEN_KEY);
      } else if (data.user.role === 'candidate') {
        await refreshCandidateApplications();
      }
    } catch {
      // ignore network error
    }
  }, [token, refreshCandidateApplications]);

  useEffect(() => {
    void refreshSession();
  }, [refreshSession]);

  const login = useCallback(async (phone: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      return { ok: false, error: data.error || 'Login failed' };
    }
    localStorage.setItem(STORAGE_TOKEN_KEY, data.token);
    setToken(data.token);
    setUser(data.user);
    setAuthModalOpen(false);
    if (data.user.role === 'employer') setView('employer');
    else if (data.user.role === 'admin') setView('admin');
    return { ok: true };
  }, []);

  const register = useCallback(
    async (payload: {
      name: string;
      phone: string;
      password: string;
      role: 'candidate' | 'employer';
      district: string;
      state: string;
      companyName?: string;
      sector?: string;
    }) => {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        return { ok: false, error: data.error || 'Registration failed' };
      }
      localStorage.setItem(STORAGE_TOKEN_KEY, data.token);
      setToken(data.token);
      setUser(data.user);
      setAuthModalOpen(false);
      if (data.user.role === 'candidate') setView('profile');
      else if (data.user.role === 'employer') setView('employer');
      return { ok: true };
    },
    []
  );

  const logout = useCallback(async () => {
    if (token) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {});
    }
    localStorage.removeItem(STORAGE_TOKEN_KEY);
    setToken(null);
    setUser(null);
    setCandidateProfile(null);
    setEmployerProfile(null);
    setCandidateApplications([]);
    setView('directory');
  }, [token]);

  const activeSkills =
    user?.role === 'candidate' && candidateProfile ? candidateProfile.skills : guestSkills;

  const appliedJobIds = new Set(candidateApplications.map((a) => a.jobId));

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        t: TRANSLATIONS[lang],
        view,
        setView,
        token,
        user,
        candidateProfile,
        employerProfile,
        activeSkills,
        setGuestSkills,
        appliedJobIds,
        candidateApplications,
        authModalOpen,
        setAuthModalOpen,
        selectedJob,
        setSelectedJob,
        quickApplyJob,
        setQuickApplyJob,
        login,
        register,
        logout,
        refreshSession,
        refreshCandidateApplications,
        apiFetch,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
