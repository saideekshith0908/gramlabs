import type { Language } from '../../shared/vocational';

export interface TranslationBundle {
  brandName: string;
  navFindJobs: string;
  navSkillProfile: string;
  navMyApplications: string;
  navEmployerHub: string;
  navAdmin: string;
  signIn: string;
  signOut: string;
  langEnglish: string;
  langHindi: string;
  languageLabel: string;
  heroEyebrow: string;
  heroTitle: string;
  heroSubtitle: string;
  heroPrimaryCta: string;
  heroSecondaryCta: string;
  heroStatJobs: string;
  heroStatTrades: string;
  heroStatNoResume: string;
  heroStatFree: string;
  fraudWarningTitle: string;
  fraudWarningBody: string;
  sampleListingLabel: string;
  verifiedListingLabel: string;
  pendingApprovalLabel: string;
  rejectedListingLabel: string;
  searchPlaceholder: string;
  filterAllTrades: string;
  filterAllLocations: string;
  filterSalaryAny: string;
  filterSalary15k: string;
  filterSalary18k: string;
  filterSalary20k: string;
  filterExpAny: string;
  filterExp0: string;
  filterExp1: string;
  filterExp2: string;
  filterAccomOnly: string;
  resetFilters: string;
  jobsFoundCount: string;
  matchLabel: string;
  perMonth: string;
  freeAccommodation: string;
  foodProvided: string;
  regionalEmployment: string;
  kmAway: string;
  viewDetails: string;
  quickApply: string;
  alreadyApplied: string;
  listenToJob: string;
  listenHint: string;
  audioPlay: string;
  audioPause: string;
  audioResume: string;
  audioStop: string;
  audioUnsupported: string;
  whatsappEmployer: string;
  whatsappPrefillPrefix: string;
  requiredSkillsHeading: string;
  responsibilitiesHeading: string;
  matchBreakdownHeading: string;
  exactMatchNote: string;
  transferableMatchNote: string;
  missingSkillNote: string;
  experienceRequired: string;
  yearsExp: string;
  fresherWelcome: string;
  postedOn: string;
  // Profile Builder
  profileTitle: string;
  profileSubtitle: string;
  fullNameLabel: string;
  mobileNumberLabel: string;
  mobileStatusRegistered: string;
  homeDistrictLabel: string;
  stateLabel: string;
  experienceYearsLabel: string;
  availabilityDateLabel: string;
  selectSkillsHeading: string;
  selectSkillsHint: string;
  selectedCount: string;
  certificationsHeading: string;
  itiLabel: string;
  itiTradePlaceholder: string;
  itiCodePlaceholder: string;
  pmkvyLabel: string;
  pmkvyTradePlaceholder: string;
  pmkvyCodePlaceholder: string;
  certStatusNotSubmitted: string;
  certStatusPending: string;
  certStatusVerified: string;
  certStatusRejected: string;
  saveProfileBtn: string;
  profileSavedMsg: string;
  guestSkillNotice: string;
  // Quick Apply Modal
  quickApplyTitle: string;
  confirmDetailsNote: string;
  yourSkillsLabel: string;
  confirmApplyBtn: string;
  applySuccessTitle: string;
  applySuccessBody: string;
  goToTrackingBtn: string;
  closeBtn: string;
  // Applicant Tracking
  trackingTitle: string;
  trackingSubtitle: string;
  myProfileSummary: string;
  appliedJobsHeading: string;
  noApplicationsYet: string;
  browseJobsCta: string;
  recommendedJobsHeading: string;
  appliedOn: string;
  availableFrom: string;
  employerNotesLabel: string;
  // Employer Dashboard
  employerTitle: string;
  employerSubtitle: string;
  companyProfileTab: string;
  postJobTab: string;
  myJobsTab: string;
  applicantsTab: string;
  companyNameLabel: string;
  sectorLabel: string;
  postNewJobHeading: string;
  jobTitleEnLabel: string;
  jobTitleHiLabel: string;
  tradeCategoryLabel: string;
  salaryMonthlyLabel: string;
  districtLabel: string;
  jobDescEnLabel: string;
  jobDescHiLabel: string;
  submitJobBtn: string;
  jobSubmittedPendingMsg: string;
  noApplicantsYet: string;
  updateStatusBtn: string;
  interviewNotePlaceholder: string;
  // Admin Dashboard
  adminTitle: string;
  adminSubtitle: string;
  statCandidates: string;
  statEmployers: string;
  statJobs: string;
  statApplications: string;
  statPendingJobs: string;
  statPendingCerts: string;
  pendingJobsHeading: string;
  certVerificationHeading: string;
  allJobsHeading: string;
  employersHeading: string;
  applicationsMonitorHeading: string;
  approveBtn: string;
  rejectBtn: string;
  verifyCertBtn: string;
  // Auth
  authModalTitleSignIn: string;
  authModalTitleRegister: string;
  authTabSignIn: string;
  authTabRegister: string;
  roleCandidate: string;
  roleEmployer: string;
  pinPasswordLabel: string;
  demoAccessHeading: string;
  demoCandidateBtn: string;
  demoEmployerBtn: string;
  demoAdminBtn: string;
  cancelBtn: string;
}

export const TRANSLATIONS: Record<Language, TranslationBundle> = {
  en: {
    brandName: 'GramJobs – RuralRise',
    navFindJobs: 'Find Jobs',
    navSkillProfile: 'Skill Profile',
    navMyApplications: 'My Applications',
    navEmployerHub: 'Employer Hub',
    navAdmin: 'Admin',
    signIn: 'Sign In',
    signOut: 'Sign Out',
    langEnglish: 'English',
    langHindi: 'हिंदी',
    languageLabel: 'Language',
    heroEyebrow: 'No Resume Needed · Verified Vocational Hiring',
    heroTitle: 'Practical Trade Skills to Nearby Rural Employment',
    heroSubtitle:
      'Built for ITI graduates, PMKVY trainees, and skilled village youth. Pick your trade skills, see exact salary and free accommodation upfront, and apply in one tap.',
    heroPrimaryCta: 'Build My Skill Profile',
    heroSecondaryCta: 'Browse 18 Sample Jobs',
    heroStatJobs: '18 Sample Jobs',
    heroStatTrades: '8 Trade Sectors',
    heroStatNoResume: '0 PDFs Required',
    heroStatFree: '100% Free for Youth',
    fraudWarningTitle: '100% FREE JOB – NEVER PAY MONEY TO RECRUITERS.',
    fraudWarningBody:
      'GramJobs – RuralRise never charges candidates for job applications, interviews, or joining. Report anyone demanding cash or UPI fees.',
    sampleListingLabel: 'Sample Listing',
    verifiedListingLabel: 'Employer Verified',
    pendingApprovalLabel: 'Pending Admin Approval',
    rejectedListingLabel: 'Rejected',
    searchPlaceholder: 'Search by job title, skill, or district (e.g., Jaipur, Solar)...',
    filterAllTrades: 'All Trades',
    filterAllLocations: 'All Districts / States',
    filterSalaryAny: 'Any Salary',
    filterSalary15k: '₹15,000+ / mo',
    filterSalary18k: '₹18,000+ / mo',
    filterSalary20k: '₹20,000+ / mo',
    filterExpAny: 'Any Experience',
    filterExp0: 'Fresher (0 yrs)',
    filterExp1: 'Up to 1 yr',
    filterExp2: 'Up to 2 yrs',
    filterAccomOnly: 'Free Accommodation Only',
    resetFilters: 'Reset Filters',
    jobsFoundCount: 'vacancies shown',
    matchLabel: 'Match',
    perMonth: '/month',
    freeAccommodation: 'Free accommodation',
    foodProvided: 'Food provided',
    regionalEmployment: 'Regional employment',
    kmAway: 'km from district center',
    viewDetails: 'View Details',
    quickApply: 'Quick Apply',
    alreadyApplied: 'Applied',
    listenToJob: 'Listen to Job in Hindi',
    listenHint: 'Reads job role, salary, location, and accommodation aloud in spoken Hindi.',
    audioPlay: 'Play Audio',
    audioPause: 'Pause',
    audioResume: 'Resume',
    audioStop: 'Stop',
    audioUnsupported: 'Speech audio is not supported on this browser.',
    whatsappEmployer: 'WhatsApp Employer',
    whatsappPrefillPrefix: 'Hello, I am interested in the',
    requiredSkillsHeading: 'Required Vocational Skills',
    responsibilitiesHeading: 'Key Responsibilities',
    matchBreakdownHeading: 'Skill Match Breakdown',
    exactMatchNote: 'Exact skill match',
    transferableMatchNote: 'Transferable trade skill from',
    missingSkillNote: 'Skill to learn on job',
    experienceRequired: 'Experience',
    yearsExp: 'yrs min',
    fresherWelcome: 'Freshers welcome',
    postedOn: 'Posted',
    profileTitle: 'Vocational Trade Skills Profile Builder',
    profileSubtitle:
      'Select your practical abilities using the trade cards below. No PDF resume upload is required—your skill match percentage updates live across all regional jobs.',
    fullNameLabel: 'Full Name',
    mobileNumberLabel: 'Mobile Number (10 digits)',
    mobileStatusRegistered: 'Registered number (privacy protected)',
    homeDistrictLabel: 'Home District',
    stateLabel: 'State',
    experienceYearsLabel: 'Years of Practical Experience',
    availabilityDateLabel: 'Earliest Joining / Availability Date',
    selectSkillsHeading: 'Select Your Practical Vocational Skills',
    selectSkillsHint: 'Tap any trade skill you can perform on the job. Select multiple skills.',
    selectedCount: 'skills selected',
    certificationsHeading: 'Vocational Certificates (Admin Reviewed)',
    itiLabel: 'I hold an ITI Certificate',
    itiTradePlaceholder: 'ITI Trade (e.g., Electrician, Fitter)',
    itiCodePlaceholder: 'ITI Certificate / Roll Number',
    pmkvyLabel: 'I hold a PMKVY Certificate',
    pmkvyTradePlaceholder: 'PMKVY Job Role',
    pmkvyCodePlaceholder: 'PMKVY Certificate ID',
    certStatusNotSubmitted: 'Not Verified / Not Submitted',
    certStatusPending: 'Pending Admin Verification',
    certStatusVerified: 'Verified by Admin',
    certStatusRejected: 'Verification Rejected',
    saveProfileBtn: 'Save Skill Profile',
    profileSavedMsg: 'Your vocational skill profile has been saved and job matches updated.',
    guestSkillNotice:
      'Testing skills as Guest: select skills below to see live match scores, or Sign In as a Candidate to save permanently and apply.',
    quickApplyTitle: 'One-Tap Quick Apply',
    confirmDetailsNote: 'Your skill profile and registered mobile number will be shared directly with this employer.',
    yourSkillsLabel: 'Your Matched Skills',
    confirmApplyBtn: 'Confirm & Submit Application',
    applySuccessTitle: 'Application Submitted Successfully',
    applySuccessBody:
      'Your application has been recorded. You can track interview calls and status updates anytime in My Applications.',
    goToTrackingBtn: 'Track My Applications',
    closeBtn: 'Close',
    trackingTitle: 'Applicant Tracking Dashboard',
    trackingSubtitle: 'Track your submitted applications, interview calls, and skill-matched recommendations.',
    myProfileSummary: 'Candidate Summary',
    appliedJobsHeading: 'My Applied Jobs',
    noApplicationsYet: 'You have not applied to any job yet. Browse matched regional jobs to apply in one tap.',
    browseJobsCta: 'Browse Regional Jobs',
    recommendedJobsHeading: 'Top Recommended Jobs for Your Skills',
    appliedOn: 'Applied on',
    availableFrom: 'Available from',
    employerNotesLabel: 'Employer Update',
    employerTitle: 'Employer Recruitment Dashboard',
    employerSubtitle: 'Post regional technical vacancies, review skilled applicants, and update interview calls.',
    companyProfileTab: 'Company Profile',
    postJobTab: 'Post New Job',
    myJobsTab: 'My Vacancies',
    applicantsTab: 'Applicants',
    companyNameLabel: 'Company / Enterprise Name',
    sectorLabel: 'Industry Sector',
    postNewJobHeading: 'Post a New Rural Vocational Vacancy',
    jobTitleEnLabel: 'Job Title (English)',
    jobTitleHiLabel: 'Job Title (Hindi - Optional)',
    tradeCategoryLabel: 'Vocational Trade Category',
    salaryMonthlyLabel: 'Monthly Take-Home Salary (₹)',
    districtLabel: 'Work District',
    jobDescEnLabel: 'Work Description (English)',
    jobDescHiLabel: 'Work Description (Hindi - Optional)',
    submitJobBtn: 'Submit Vacancy for Admin Approval',
    jobSubmittedPendingMsg: 'Vacancy submitted! It will appear in the public directory once approved by an Admin.',
    noApplicantsYet: 'No applications received yet for your posted vacancies.',
    updateStatusBtn: 'Save Status',
    interviewNotePlaceholder: 'Add interview date, venue, or note for candidate...',
    adminTitle: 'Platform Administration Console',
    adminSubtitle: 'Verify employer job postings, review ITI/PMKVY certificates, and monitor platform safety.',
    statCandidates: 'Candidates',
    statEmployers: 'Employers',
    statJobs: 'Total Vacancies',
    statApplications: 'Applications',
    statPendingJobs: 'Pending Jobs',
    statPendingCerts: 'Cert Reviews',
    pendingJobsHeading: 'Pending Job Approvals',
    certVerificationHeading: 'ITI & PMKVY Certificate Verification Queue',
    allJobsHeading: 'All Job Listings Management',
    employersHeading: 'Registered Employers',
    applicationsMonitorHeading: 'Recent Applications Monitor',
    approveBtn: 'Approve',
    rejectBtn: 'Reject',
    verifyCertBtn: 'Verify Certificate',
    authModalTitleSignIn: 'Sign In to GramJobs – RuralRise',
    authModalTitleRegister: 'Create Free Account',
    authTabSignIn: 'Sign In',
    authTabRegister: 'New Registration',
    roleCandidate: 'Job Seeker (Candidate)',
    roleEmployer: 'Employer / Contractor',
    pinPasswordLabel: '4+ Digit PIN or Password',
    demoAccessHeading: 'Instant Demo Access (One Click)',
    demoCandidateBtn: 'Demo Job Seeker (Ramesh · Solar & Electrical)',
    demoEmployerBtn: 'Demo Employer (SuryaShakti Solar EPC)',
    demoAdminBtn: 'Demo Platform Admin',
    cancelBtn: 'Cancel',
  },
  hi: {
    brandName: 'ग्रामजॉब्स – रूरलराइज़',
    navFindJobs: 'नौकरियां खोजें',
    navSkillProfile: 'कौशल प्रोफ़ाइल',
    navMyApplications: 'मेरे आवेदन',
    navEmployerHub: 'नियोक्ता केंद्र',
    navAdmin: 'एडमिन',
    signIn: 'लॉग इन करें',
    signOut: 'लॉग आउट',
    langEnglish: 'English',
    langHindi: 'हिंदी',
    languageLabel: 'भाषा',
    heroEyebrow: 'बिना रिज्यूमे के · सत्यापित कौशल आधारित भर्ती',
    heroTitle: 'आपके व्यावहारिक कौशल के आधार पर नजदीकी ग्रामीण रोजगार',
    heroSubtitle:
      'ITI पास, PMKVY प्रशिक्षित और ग्रामीण युवाओं के लिए। अपने तकनीकी कौशल चुनें, वेतन और मुफ्त आवास की पूरी जानकारी देखें, और एक टैप में आवेदन करें।',
    heroPrimaryCta: 'मेरी कौशल प्रोफ़ाइल बनाएं',
    heroSecondaryCta: '18 नमूना नौकरियां देखें',
    heroStatJobs: '18 नमूना भर्तियां',
    heroStatTrades: '8 ट्रेड क्षेत्र',
    heroStatNoResume: '0 रिज्यूमे आवश्यक',
    heroStatFree: '100% निःशुल्क सेवा',
    fraudWarningTitle: '100% निःशुल्क नौकरी – भर्तीकर्ता को कभी पैसे न दें।',
    fraudWarningBody:
      'ग्रामजॉब्स – रूरलराइज़ आवेदन, इंटरव्यू या जॉइनिंग के लिए कोई शुल्क नहीं लेता। पैसे या यूपीआई मांगने वाले किसी भी व्यक्ति की शिकायत करें।',
    sampleListingLabel: 'नमूना भर्ती',
    verifiedListingLabel: 'नियोक्ता सत्यापित',
    pendingApprovalLabel: 'एडमिन स्वीकृति लंबित',
    rejectedListingLabel: 'अस्वीकृत',
    searchPlaceholder: 'नौकरी का नाम, कौशल या जिला खोजें (जैसे जयपुर, सोलर)...',
    filterAllTrades: 'सभी ट्रेड',
    filterAllLocations: 'सभी जिले / राज्य',
    filterSalaryAny: 'कोई भी वेतन',
    filterSalary15k: '₹15,000+ / माह',
    filterSalary18k: '₹18,000+ / माह',
    filterSalary20k: '₹20,000+ / माह',
    filterExpAny: 'कोई भी अनुभव',
    filterExp0: 'फ्रेशर (0 वर्ष)',
    filterExp1: '1 वर्ष तक',
    filterExp2: '2 वर्ष तक',
    filterAccomOnly: 'केवल मुफ्त आवास वाली नौकरियां',
    resetFilters: 'फ़िल्टर रीसेट करें',
    jobsFoundCount: 'रिक्तियां उपलब्ध',
    matchLabel: 'मेल (Match)',
    perMonth: '/माह',
    freeAccommodation: 'मुफ्त आवास',
    foodProvided: 'भोजन उपलब्ध',
    regionalEmployment: 'क्षेत्रीय रोजगार',
    kmAway: 'किमी जिला केंद्र से',
    viewDetails: 'विवरण देखें',
    quickApply: 'तुरंत आवेदन करें',
    alreadyApplied: 'आवेदन किया गया',
    listenToJob: 'हिंदी में नौकरी का विवरण सुनें',
    listenHint: 'यह नौकरी की जिम्मेदारियां, वेतन, स्थान और आवास की जानकारी हिंदी में पढ़कर सुनाता है।',
    audioPlay: 'सुनें',
    audioPause: 'रोकें',
    audioResume: 'फिर शुरू करें',
    audioStop: 'बंद करें',
    audioUnsupported: 'इस ब्राउज़र में वॉइस ऑडियो उपलब्ध नहीं है।',
    whatsappEmployer: 'व्हाट्सएप पर संपर्क करें',
    whatsappPrefillPrefix: 'नमस्ते, मुझे ग्रामजॉब्स – रूरलराइज़ पर विज्ञापन की गई इस नौकरी में रुचि है:',
    requiredSkillsHeading: 'आवश्यक तकनीकी कौशल',
    responsibilitiesHeading: 'मुख्य कार्य और जिम्मेदारियां',
    matchBreakdownHeading: 'कौशल मिलान विवरण',
    exactMatchNote: 'सीधा कौशल मेल',
    transferableMatchNote: 'संबंधित ट्रेड कौशल से मेल:',
    missingSkillNote: 'कार्य पर सीखने योग्य कौशल',
    experienceRequired: 'अनुभव',
    yearsExp: 'वर्ष न्यूनतम',
    fresherWelcome: 'फ्रेशर आवेदन कर सकते हैं',
    postedOn: 'पोस्ट की तिथि',
    profileTitle: 'व्यावहारिक कौशल प्रोफ़ाइल बिल्डर',
    profileSubtitle:
      'नीचे दिए गए ट्रेड कार्ड से अपने व्यावहारिक कौशल चुनें। पीडीएफ रिज्यूमे की कोई आवश्यकता नहीं है—चयन करते ही सभी नौकरियों पर आपका मैच प्रतिशत अपने आप अपडेट हो जाएगा।',
    fullNameLabel: 'पूरा नाम',
    mobileNumberLabel: 'मोबाइल नंबर (10 अंक)',
    mobileStatusRegistered: 'पंजीकृत नंबर (गोपनीयता सुरक्षित)',
    homeDistrictLabel: 'गृह जिला',
    stateLabel: 'राज्य',
    experienceYearsLabel: 'व्यावहारिक अनुभव (वर्षों में)',
    availabilityDateLabel: 'कार्य शुरू करने की तिथि',
    selectSkillsHeading: 'अपने व्यावहारिक व्यावसायिक कौशल चुनें',
    selectSkillsHint: 'जिस काम का आपको अनुभव है उन कार्ड पर टैप करें। आप एक से अधिक कौशल चुन सकते हैं।',
    selectedCount: 'कौशल चुने गए',
    certificationsHeading: 'व्यावहारिक प्रमाणपत्र (एडमिन समीक्षाधीन)',
    itiLabel: 'मेरे पास ITI प्रमाणपत्र है',
    itiTradePlaceholder: 'ITI ट्रेड (जैसे इलेक्ट्रिशियन, फिटर)',
    itiCodePlaceholder: 'ITI प्रमाणपत्र / रोल नंबर',
    pmkvyLabel: 'मेरे पास PMKVY प्रमाणपत्र है',
    pmkvyTradePlaceholder: 'PMKVY जॉब रोल',
    pmkvyCodePlaceholder: 'PMKVY प्रमाणपत्र आईडी',
    certStatusNotSubmitted: 'सत्यापित नहीं / जमा नहीं',
    certStatusPending: 'एडमिन सत्यापन लंबित',
    certStatusVerified: 'एडमिन द्वारा सत्यापित',
    certStatusRejected: 'सत्यापन अस्वीकृत',
    saveProfileBtn: 'कौशल प्रोफ़ाइल सहेजें',
    profileSavedMsg: 'आपकी कौशल प्रोफ़ाइल सहेजी गई है और नौकरी मिलान अपडेट हो गया है।',
    guestSkillNotice:
      'गेस्ट मोड: लाइव मिलान देखने के लिए नीचे कौशल चुनें, या प्रोफ़ाइल सहेजने और आवेदन करने के लिए लॉग इन करें।',
    quickApplyTitle: 'एक-टैप त्वरित आवेदन',
    confirmDetailsNote: 'आपकी कौशल प्रोफ़ाइल और पंजीकृत मोबाइल नंबर सीधे इस नियोक्ता के साथ साझा किया जाएगा।',
    yourSkillsLabel: 'आपके चुने हुए कौशल',
    confirmApplyBtn: 'आवेदन की पुष्टि करें',
    applySuccessTitle: 'आवेदन सफलतापूर्वक जमा हो गया',
    applySuccessBody:
      'आपका आवेदन दर्ज हो गया है। आप "मेरे आवेदन" डैशबोर्ड में कभी भी इंटरव्यू कॉल और स्थिति देख सकते हैं।',
    goToTrackingBtn: 'मेरे आवेदन ट्रैक करें',
    closeBtn: 'बंद करें',
    trackingTitle: 'आवेदक ट्रैकिंग डैशबोर्ड',
    trackingSubtitle: 'अपने जमा किए गए आवेदन, इंटरव्यू कॉल और कौशल-मिलान वाली नौकरियां यहां देखें।',
    myProfileSummary: 'उम्मीदवार सारांश',
    appliedJobsHeading: 'मेरे द्वारा किए गए आवेदन',
    noApplicationsYet: 'आपने अभी तक किसी नौकरी के लिए आवेदन नहीं किया है। अपनी कौशल-मिलान नौकरियां देखें।',
    browseJobsCta: 'क्षेत्रीय नौकरियां देखें',
    recommendedJobsHeading: 'आपके कौशल के लिए सर्वोत्तम नौकरियां',
    appliedOn: 'आवेदन तिथि',
    availableFrom: 'उपलब्धता तिथि',
    employerNotesLabel: 'नियोक्ता संदेश',
    employerTitle: 'नियोक्ता भर्ती डैशबोर्ड',
    employerSubtitle: 'नई ग्रामीण रिक्तियां पोस्ट करें, आवेदकों की जांच करें और इंटरव्यू कॉल अपडेट करें।',
    companyProfileTab: 'कंपनी प्रोफ़ाइल',
    postJobTab: 'नई नौकरी पोस्ट करें',
    myJobsTab: 'मेरी पोस्ट की गई नौकरियां',
    applicantsTab: 'आवेदक',
    companyNameLabel: 'कंपनी / उद्यम का नाम',
    sectorLabel: 'उद्योग क्षेत्र',
    postNewJobHeading: 'नई ग्रामीण तकनीकी भर्ती पोस्ट करें',
    jobTitleEnLabel: 'नौकरी का शीर्षक (अंग्रेजी)',
    jobTitleHiLabel: 'नौकरी का शीर्षक (हिंदी - वैकल्पिक)',
    tradeCategoryLabel: 'व्यावहारिक ट्रेड श्रेणी',
    salaryMonthlyLabel: 'मासिक वेतन (₹)',
    districtLabel: 'कार्य जिला',
    jobDescEnLabel: 'कार्य विवरण (अंग्रेजी)',
    jobDescHiLabel: 'कार्य विवरण (हिंदी - वैकल्पिक)',
    submitJobBtn: 'एडमिन स्वीकृति के लिए भेजें',
    jobSubmittedPendingMsg: 'भर्ती सबमिट हो गई है! एडमिन की स्वीकृति के बाद यह नौकरी सूची में दिखाई देगी।',
    noApplicantsYet: 'आपकी नौकरियों पर अभी तक कोई आवेदन प्राप्त नहीं हुआ है।',
    updateStatusBtn: 'स्थिति सहेजें',
    interviewNotePlaceholder: 'इंटरव्यू की तारीख, स्थान या संदेश लिखें...',
    adminTitle: 'प्लेटफ़ॉर्म एडमिन कंसोल',
    adminSubtitle: 'नियोक्ता की नौकरियां स्वीकृत करें, ITI/PMKVY प्रमाणपत्र जांचें और प्लेटफ़ॉर्म की सुरक्षा बनाए रखें।',
    statCandidates: 'उम्मीदवार',
    statEmployers: 'नियोक्ता',
    statJobs: 'कुल रिक्तियां',
    statApplications: 'कुल आवेदन',
    statPendingJobs: 'लंबित भर्तियां',
    statPendingCerts: 'प्रमाणपत्र जांच',
    pendingJobsHeading: 'स्वीकृति के लिए लंबित नौकरियां',
    certVerificationHeading: 'ITI और PMKVY प्रमाणपत्र सत्यापन कतार',
    allJobsHeading: 'सभी नौकरियों का प्रबंधन',
    employersHeading: 'पंजीकृत नियोक्ता',
    applicationsMonitorHeading: 'हाल के आवेदन निगरानी',
    approveBtn: 'स्वीकृत करें',
    rejectBtn: 'अस्वीकृत करें',
    verifyCertBtn: 'प्रमाणपत्र सत्यापित करें',
    authModalTitleSignIn: 'ग्रामजॉब्स – रूरलराइज़ में लॉग इन करें',
    authModalTitleRegister: 'निःशुल्क खाता बनाएं',
    authTabSignIn: 'लॉग इन',
    authTabRegister: 'नया पंजीकरण',
    roleCandidate: 'नौकरी खोजने वाले (उम्मीदवार)',
    roleEmployer: 'नियोक्ता / ठेकेदार',
    pinPasswordLabel: '4+ अंकों का पिन या पासवर्ड',
    demoAccessHeading: 'त्वरित डेमो लॉगिन (एक क्लिक)',
    demoCandidateBtn: 'डेमो उम्मीदवार (रमेश · सोलर व इलेक्ट्रिकल)',
    demoEmployerBtn: 'डेमो नियोक्ता (सूर्यशक्ति सोलर ईपीसी)',
    demoAdminBtn: 'डेमो प्लेटफ़ॉर्म एडमिन',
    cancelBtn: 'रद्द करें',
  },
};
