/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppProvider, useApp } from './context/AppContext';
import { AdminDashboardView } from './components/AdminDashboardView';
import { ApplicantTrackingView } from './components/ApplicantTrackingView';
import { AuthModal } from './components/AuthModal';
import { CandidateProfileView } from './components/CandidateProfileView';
import { EmployerDashboardView } from './components/EmployerDashboardView';
import { JobDetailModal } from './components/JobDetailModal';
import { JobDirectoryView } from './components/JobDirectoryView';
import { Navbar } from './components/Navbar';
import { QuickApplyModal } from './components/QuickApplyModal';

function MainLayout() {
  const { view, t, setView } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Navbar />

      <main className="flex-1">
        {view === 'directory' && <JobDirectoryView />}
        {view === 'profile' && <CandidateProfileView />}
        {view === 'applications' && <ApplicantTrackingView />}
        {view === 'employer' && <EmployerDashboardView />}
        {view === 'admin' && <AdminDashboardView />}
      </main>

      <footer className="hidden md:block bg-white border-t border-slate-200 py-6">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap items-center justify-between gap-4 text-xs sm:text-sm text-slate-600">
          <p className="font-semibold text-[#0F2942]">{t.brandName}</p>
          <p className="font-medium text-amber-900">{t.fraudWarningTitle}</p>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setView('directory')}
              className="hover:text-[#0F2942] font-medium"
            >
              {t.navFindJobs}
            </button>
            <button
              type="button"
              onClick={() => setView('profile')}
              className="hover:text-[#0F2942] font-medium"
            >
              {t.navSkillProfile}
            </button>
            <button
              type="button"
              onClick={() => setView('employer')}
              className="hover:text-[#0F2942] font-medium"
            >
              {t.navEmployerHub}
            </button>
          </div>
        </div>
      </footer>

      <JobDetailModal />
      <QuickApplyModal />
      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
