import { useEffect, useState } from 'react';
import { Pause, Play, Square, Volume2 } from 'lucide-react';
import { VOCATIONAL_SKILLS } from '../../shared/vocational';
import { useApp, type EnrichedJob } from '../context/AppContext';

export function HindiAudioPlayer({ job }: { job: EnrichedJob }) {
  const { t } = useApp();
  const [status, setStatus] = useState<'idle' | 'playing' | 'paused'>('idle');
  const [supported] = useState<boolean>(() => typeof window !== 'undefined' && 'speechSynthesis' in window);

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [job.id]);

  function buildHindiSpeechScript(): string {
    const skillNamesHi = job.requiredSkills
      .map((id) => VOCATIONAL_SKILLS.find((s) => s.id === id)?.nameHi || id)
      .join(', ');

    const accomText = job.accommodationFree
      ? 'निःशुल्क रहने की व्यवस्था उपलब्ध है।'
      : 'आवास की व्यवस्था स्वयं करनी होगी।';
    const foodText = job.foodProvided ? 'भोजन की सुविधा भी दी जाएगी।' : '';
    const respText = job.responsibilitiesHi.join('। ');

    return `नौकरी का नाम: ${job.titleHi}। कंपनी: ${job.companyNameHi}। स्थान: ${job.locationDistrict}, ${job.locationState}। मासिक वेतन: ${job.salaryMonthly} रुपये प्रति माह। ${accomText} ${foodText} आवश्यक तकनीकी कौशल: ${skillNamesHi}। मुख्य कार्य: ${respText}। ध्यान दें: यह नौकरी 100 प्रतिशत निःशुल्क है, किसी भी भर्तीकर्ता को पैसे न दें।`;
  }

  function handlePlay() {
    if (!supported) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(buildHindiSpeechScript());
    utterance.lang = 'hi-IN';
    utterance.rate = 0.94;

    const voices = window.speechSynthesis.getVoices();
    const hindiVoice =
      voices.find((v) => v.lang.toLowerCase().startsWith('hi')) ||
      voices.find((v) => v.name.toLowerCase().includes('hindi'));
    if (hindiVoice) {
      utterance.voice = hindiVoice;
    }

    utterance.onend = () => setStatus('idle');
    utterance.onerror = () => setStatus('idle');

    setStatus('playing');
    window.speechSynthesis.speak(utterance);
  }

  function handlePause() {
    if (!supported) return;
    window.speechSynthesis.pause();
    setStatus('paused');
  }

  function handleResume() {
    if (!supported) return;
    window.speechSynthesis.resume();
    setStatus('playing');
  }

  function handleStop() {
    if (!supported) return;
    window.speechSynthesis.cancel();
    setStatus('idle');
  }

  return (
    <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 space-y-3">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-[#0F2942] text-white flex items-center justify-center shrink-0">
          <Volume2 className="w-5 h-5" aria-hidden="true" />
        </div>
        <div>
          <h3 className="text-base font-bold text-[#0F2942]">{t.listenToJob}</h3>
          <p className="text-xs sm:text-sm text-slate-700 mt-0.5">{t.listenHint}</p>
        </div>
      </div>

      {!supported ? (
        <p className="text-sm text-red-700 font-medium">{t.audioUnsupported}</p>
      ) : (
        <div className="flex flex-wrap items-center gap-2">
          {status === 'idle' && (
            <button
              type="button"
              onClick={handlePlay}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0F2942] hover:bg-slate-800 text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Play className="w-4 h-4" aria-hidden="true" />
              {t.audioPlay}
            </button>
          )}

          {status === 'playing' && (
            <button
              type="button"
              onClick={handlePause}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Pause className="w-4 h-4" aria-hidden="true" />
              {t.audioPause}
            </button>
          )}

          {status === 'paused' && (
            <button
              type="button"
              onClick={handleResume}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-[#15803D] hover:bg-[#166534] text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Play className="w-4 h-4" aria-hidden="true" />
              {t.audioResume}
            </button>
          )}

          {status !== 'idle' && (
            <button
              type="button"
              onClick={handleStop}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Square className="w-4 h-4" aria-hidden="true" />
              {t.audioStop}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
