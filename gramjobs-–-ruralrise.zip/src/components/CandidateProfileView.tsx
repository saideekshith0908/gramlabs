import React, { useEffect, useState } from 'react';
import {
  Check,
  Flame,
  HeartPulse,
  ShieldCheck,
  Smartphone,
  Sprout,
  Store,
  Sun,
  Wrench,
  Zap,
} from 'lucide-react';
import {
  INDIAN_STATES,
  TRADE_CATEGORIES,
  VOCATIONAL_SKILLS,
  type CertificationStatus,
  type TradeCategoryId,
} from '../../shared/vocational';
import { useApp } from '../context/AppContext';

const TRADE_ICONS: Record<TradeCategoryId, typeof Sun> = {
  solar: Sun,
  electrical: Zap,
  mechanical: Wrench,
  agriculture: Sprout,
  electronics: Smartphone,
  healthcare: HeartPulse,
  welding: Flame,
  retail: Store,
};

export function CandidateProfileView() {
  const {
    lang,
    t,
    user,
    candidateProfile,
    activeSkills,
    setGuestSkills,
    setAuthModalOpen,
    setView,
    apiFetch,
    refreshSession,
  } = useApp();

  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [homeDistrict, setHomeDistrict] = useState('Jaipur');
  const [state, setState] = useState('Rajasthan');
  const [selectedSkills, setSelectedSkills] = useState<string[]>(activeSkills);
  const [experienceYears, setExperienceYears] = useState(1);
  const [availabilityDate, setAvailabilityDate] = useState('');
  const [itiQualified, setItiQualified] = useState(false);
  const [itiTrade, setItiTrade] = useState('');
  const [itiCertificateCode, setItiCertificateCode] = useState('');
  const [pmkvyCertified, setPmkvyCertified] = useState(false);
  const [pmkvyTrade, setPmkvyTrade] = useState('');
  const [pmkvyCertificateCode, setPmkvyCertificateCode] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (candidateProfile) {
      setFullName(candidateProfile.fullName);
      setMobile(candidateProfile.mobile);
      setHomeDistrict(candidateProfile.homeDistrict);
      setState(candidateProfile.state);
      setSelectedSkills(candidateProfile.skills);
      setExperienceYears(candidateProfile.experienceYears);
      setAvailabilityDate(candidateProfile.availabilityDate);
      setItiQualified(candidateProfile.itiQualified);
      setItiTrade(candidateProfile.itiTrade);
      setItiCertificateCode(candidateProfile.itiCertificateCode);
      setPmkvyCertified(candidateProfile.pmkvyCertified);
      setPmkvyTrade(candidateProfile.pmkvyTrade);
      setPmkvyCertificateCode(candidateProfile.pmkvyCertificateCode);
    } else {
      setSelectedSkills(activeSkills);
    }
  }, [candidateProfile, activeSkills]);

  function toggleSkill(skillId: string) {
    setSavedMsg('');
    const next = selectedSkills.includes(skillId)
      ? selectedSkills.filter((s) => s !== skillId)
      : [...selectedSkills, skillId];
    setSelectedSkills(next);
    if (!user || user.role !== 'candidate') {
      setGuestSkills(next);
    }
  }

  function certBadgeLabel(status: CertificationStatus): { text: string; cls: string } {
    switch (status) {
      case 'verified':
        return { text: t.certStatusVerified, cls: 'text-emerald-800 bg-emerald-50 border-emerald-200' };
      case 'pending':
        return { text: t.certStatusPending, cls: 'text-amber-900 bg-amber-50 border-amber-200' };
      case 'rejected':
        return { text: t.certStatusRejected, cls: 'text-red-800 bg-red-50 border-red-200' };
      default:
        return { text: t.certStatusNotSubmitted, cls: 'text-slate-700 bg-slate-100 border-slate-200' };
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSavedMsg('');

    if (!user || user.role !== 'candidate') {
      setGuestSkills(selectedSkills);
      setAuthModalOpen(true);
      return;
    }

    setSaving(true);
    try {
      const res = await apiFetch('/api/candidate/profile', {
        method: 'PUT',
        body: JSON.stringify({
          fullName,
          mobile,
          homeDistrict,
          state,
          skills: selectedSkills,
          experienceYears,
          availabilityDate,
          itiQualified,
          itiTrade,
          itiCertificateCode,
          pmkvyCertified,
          pmkvyTrade,
          pmkvyCertificateCode,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not save profile.');
        return;
      }
      await refreshSession();
      setSavedMsg(t.profileSavedMsg);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 pb-24 md:pb-12 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div className="space-y-1.5">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2942]">{t.profileTitle}</h1>
          <p className="text-sm sm:text-base text-slate-700 max-w-3xl">{t.profileSubtitle}</p>
        </div>
        <button
          type="button"
          onClick={() => setView('directory')}
          className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0F2942] hover:bg-slate-800 text-white text-sm font-bold whitespace-nowrap shrink-0"
        >
          {lang === 'hi' ? 'मैच हुई नौकरियां देखें' : 'View Matched Jobs'}
        </button>
      </div>

      {(!user || user.role !== 'candidate') && (
        <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <p className="text-sm font-semibold text-[#0F2942]">{t.guestSkillNotice}</p>
          <button
            type="button"
            onClick={() => setAuthModalOpen(true)}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#15803D] text-white text-sm font-bold whitespace-nowrap shrink-0"
          >
            {t.signIn} / {t.authTabRegister}
          </button>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-8">
        {/* Step 1: Visual Trade Cards Skill Selector */}
        <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-[#0F2942]">{t.selectSkillsHeading}</h2>
              <p className="text-sm text-slate-600">{t.selectSkillsHint}</p>
            </div>
            <span className="font-mono-tabular text-sm font-bold text-emerald-800">
              {selectedSkills.length} {t.selectedCount}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {TRADE_CATEGORIES.map((cat) => {
              const Icon = TRADE_ICONS[cat.id];
              const categorySkills = VOCATIONAL_SKILLS.filter((s) => s.category === cat.id);

              return (
                <div
                  key={cat.id}
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-[#0F2942] shrink-0">
                      <Icon className="w-5 h-5" aria-hidden="true" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-[#0F2942]">
                        {lang === 'hi' ? cat.nameHi : cat.nameEn}
                      </h3>
                      <p className="text-xs text-slate-600">
                        {lang === 'hi' ? cat.summaryHi : cat.summaryEn}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {categorySkills.map((sk) => {
                      const active = selectedSkills.includes(sk.id);
                      return (
                        <button
                          key={sk.id}
                          type="button"
                          onClick={() => toggleSkill(sk.id)}
                          aria-pressed={active}
                          className={`min-h-[44px] px-3.5 py-2 rounded-xl border text-sm font-semibold inline-flex items-center gap-2 transition-colors text-left ${
                            active
                              ? 'bg-[#15803D] border-[#15803D] text-white'
                              : 'bg-white border-slate-300 text-slate-800 hover:border-emerald-700'
                          }`}
                        >
                          {active && <Check className="w-4 h-4 shrink-0" aria-hidden="true" />}
                          <span>{lang === 'hi' ? sk.nameHi : sk.nameEn}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Step 2: Candidate Basic Details (No PDF Resume) */}
        {user?.role === 'candidate' && (
          <>
            <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5">
              <h2 className="text-lg sm:text-xl font-bold text-[#0F2942]">
                {lang === 'hi' ? 'व्यक्तिगत और स्थान विवरण' : 'Personal & Location Details'}
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.fullNameLabel}
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.mobileNumberLabel}
                  </label>
                  <input
                    type="tel"
                    inputMode="numeric"
                    required
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base font-mono-tabular"
                  />
                  <p className="text-xs text-slate-500 mt-1">{t.mobileStatusRegistered}</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.homeDistrictLabel}
                  </label>
                  <input
                    type="text"
                    required
                    value={homeDistrict}
                    onChange={(e) => setHomeDistrict(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.stateLabel}
                  </label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 text-base bg-white"
                  >
                    {INDIAN_STATES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.experienceYearsLabel}
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={40}
                    value={experienceYears}
                    onChange={(e) => setExperienceYears(Number(e.target.value))}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base font-mono-tabular"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.availabilityDateLabel}
                  </label>
                  <input
                    type="date"
                    value={availabilityDate}
                    onChange={(e) => setAvailabilityDate(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                  />
                </div>
              </div>
            </section>

            {/* Step 3: ITI & PMKVY Certificate Badges */}
            <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-6 h-6 text-[#0F2942]" aria-hidden="true" />
                <h2 className="text-lg sm:text-xl font-bold text-[#0F2942]">{t.certificationsHeading}</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* ITI Block */}
                <div className="p-4 rounded-xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <label className="inline-flex items-center gap-2.5 font-bold text-slate-900 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={itiQualified}
                        onChange={(e) => setItiQualified(e.target.checked)}
                        className="w-5 h-5 accent-[#15803D]"
                      />
                      <span>{t.itiLabel}</span>
                    </label>
                    <span
                      className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${
                        certBadgeLabel(candidateProfile?.itiStatus || 'not_submitted').cls
                      }`}
                    >
                      {certBadgeLabel(candidateProfile?.itiStatus || 'not_submitted').text}
                    </span>
                  </div>

                  {itiQualified && (
                    <div className="space-y-2.5 pt-1">
                      <input
                        type="text"
                        value={itiTrade}
                        onChange={(e) => setItiTrade(e.target.value)}
                        placeholder={t.itiTradePlaceholder}
                        className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                      />
                      <input
                        type="text"
                        value={itiCertificateCode}
                        onChange={(e) => setItiCertificateCode(e.target.value)}
                        placeholder={t.itiCodePlaceholder}
                        className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-sm font-mono-tabular"
                      />
                    </div>
                  )}
                </div>

                {/* PMKVY Block */}
                <div className="p-4 rounded-xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <label className="inline-flex items-center gap-2.5 font-bold text-slate-900 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={pmkvyCertified}
                        onChange={(e) => setPmkvyCertified(e.target.checked)}
                        className="w-5 h-5 accent-[#15803D]"
                      />
                      <span>{t.pmkvyLabel}</span>
                    </label>
                    <span
                      className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${
                        certBadgeLabel(candidateProfile?.pmkvyStatus || 'not_submitted').cls
                      }`}
                    >
                      {certBadgeLabel(candidateProfile?.pmkvyStatus || 'not_submitted').text}
                    </span>
                  </div>

                  {pmkvyCertified && (
                    <div className="space-y-2.5 pt-1">
                      <input
                        type="text"
                        value={pmkvyTrade}
                        onChange={(e) => setPmkvyTrade(e.target.value)}
                        placeholder={t.pmkvyTradePlaceholder}
                        className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                      />
                      <input
                        type="text"
                        value={pmkvyCertificateCode}
                        onChange={(e) => setPmkvyCertificateCode(e.target.value)}
                        placeholder={t.pmkvyCodePlaceholder}
                        className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-sm font-mono-tabular"
                      />
                    </div>
                  )}
                </div>
              </div>
            </section>
          </>
        )}

        {error && (
          <div role="alert" className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-900 font-semibold">
            {error}
          </div>
        )}

        {savedMsg && (
          <div role="status" className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 font-semibold">
            {savedMsg}
          </div>
        )}

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <button
            type="submit"
            disabled={saving}
            className="min-h-[48px] px-8 py-3 rounded-xl bg-[#15803D] hover:bg-[#166534] disabled:opacity-60 text-white font-bold text-base transition-colors"
          >
            {user?.role === 'candidate'
              ? t.saveProfileBtn
              : `${t.signIn} & ${t.saveProfileBtn}`}
          </button>
        </div>
      </form>
    </div>
  );
}
