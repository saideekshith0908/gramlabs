import React, { useCallback, useEffect, useState } from 'react';
import { Building2, Check, PlusCircle, Users } from 'lucide-react';
import {
  INDIAN_STATES,
  TRADE_CATEGORIES,
  VOCATIONAL_SKILLS,
  type ApplicationStatus,
  type CandidateProfile,
  type EmployerProfile,
  type JobPosting,
  type TradeCategoryId,
} from '../../shared/vocational';
import { useApp } from '../context/AppContext';

interface EmployerApplicantRow {
  id: number;
  jobId: number;
  jobTitleEn: string;
  jobTitleHi: string;
  candidateUserId: number;
  availabilityDate: string;
  status: ApplicationStatus;
  employerNotes: string;
  appliedAt: string;
  matchScore: number;
  candidate: CandidateProfile;
}

const APPLICATION_STATUSES: ApplicationStatus[] = [
  'Applied',
  'Under Review',
  'Shortlisted',
  'Interview Call',
  'Rejected',
  'Selected',
];

export function EmployerDashboardView() {
  const { lang, t, user, setAuthModalOpen, apiFetch } = useApp();

  const [tab, setTab] = useState<'applicants' | 'post' | 'jobs' | 'company'>('applicants');
  const [employer, setEmployer] = useState<EmployerProfile | null>(null);
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [applications, setApplications] = useState<EmployerApplicantRow[]>([]);
  const [loading, setLoading] = useState(false);

  // Post Job Form State
  const [titleEn, setTitleEn] = useState('');
  const [titleHi, setTitleHi] = useState('');
  const [category, setCategory] = useState<TradeCategoryId>('solar');
  const [salaryMonthly, setSalaryMonthly] = useState(18000);
  const [locationDistrict, setLocationDistrict] = useState('Jaipur');
  const [locationState, setLocationState] = useState('Rajasthan');
  const [accommodationFree, setAccommodationFree] = useState(true);
  const [foodProvided, setFoodProvided] = useState(false);
  const [experienceMinYears, setExperienceMinYears] = useState(1);
  const [employmentType, setEmploymentType] = useState<'Full-Time' | 'Contract' | 'Apprenticeship'>('Full-Time');
  const [requiredSkills, setRequiredSkills] = useState<string[]>(['Solar PV Installation']);
  const [descriptionEn, setDescriptionEn] = useState('');
  const [descriptionHi, setDescriptionHi] = useState('');
  const [formMsg, setFormMsg] = useState('');
  const [formErr, setFormErr] = useState('');

  // Company Profile Edit State
  const [compName, setCompName] = useState('');
  const [compSector, setCompSector] = useState('');
  const [compDistrict, setCompDistrict] = useState('');
  const [compState, setCompState] = useState('Rajasthan');
  const [compPhone, setCompPhone] = useState('');
  const [compWa, setCompWa] = useState('');
  const [compDesc, setCompDesc] = useState('');
  const [compMsg, setCompMsg] = useState('');

  // Local note drafts per application ID
  const [noteDrafts, setNoteDrafts] = useState<Record<number, string>>({});
  const [statusDrafts, setStatusDrafts] = useState<Record<number, ApplicationStatus>>({});

  const loadOverview = useCallback(async () => {
    if (!user || user.role !== 'employer') return;
    setLoading(true);
    try {
      const res = await apiFetch('/api/employer/overview');
      if (res.ok) {
        const data = await res.json();
        setEmployer(data.employer);
        setJobs(data.jobs || []);
        setApplications(data.applications || []);

        if (data.employer) {
          setCompName(data.employer.companyName);
          setCompSector(data.employer.sector);
          setCompDistrict(data.employer.district);
          setCompState(data.employer.state);
          setCompPhone(data.employer.contactPhone);
          setCompWa(data.employer.whatsappPhone);
          setCompDesc(data.employer.description);
        }

        const nDrafts: Record<number, string> = {};
        const sDrafts: Record<number, ApplicationStatus> = {};
        for (const a of (data.applications || []) as EmployerApplicantRow[]) {
          nDrafts[a.id] = a.employerNotes || '';
          sDrafts[a.id] = a.status;
        }
        setNoteDrafts(nDrafts);
        setStatusDrafts(sDrafts);
      }
    } finally {
      setLoading(false);
    }
  }, [user, apiFetch]);

  useEffect(() => {
    void loadOverview();
  }, [loadOverview]);

  function toggleJobSkill(skillId: string) {
    setRequiredSkills((prev) =>
      prev.includes(skillId) ? prev.filter((s) => s !== skillId) : [...prev, skillId]
    );
  }

  async function handlePostJob(e: React.FormEvent) {
    e.preventDefault();
    setFormErr('');
    setFormMsg('');
    const res = await apiFetch('/api/employer/jobs', {
      method: 'POST',
      body: JSON.stringify({
        titleEn,
        titleHi,
        category,
        salaryMonthly,
        locationDistrict,
        locationState,
        accommodationFree,
        foodProvided,
        experienceMinYears,
        employmentType,
        requiredSkills,
        descriptionEn,
        descriptionHi,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setFormErr(data.error || 'Could not post job.');
      return;
    }
    setTitleEn('');
    setTitleHi('');
    setDescriptionEn('');
    setDescriptionHi('');
    setFormMsg(t.jobSubmittedPendingMsg);
    await loadOverview();
  }

  async function handleSaveCompany(e: React.FormEvent) {
    e.preventDefault();
    setCompMsg('');
    const res = await apiFetch('/api/employer/profile', {
      method: 'PUT',
      body: JSON.stringify({
        companyName: compName,
        sector: compSector,
        district: compDistrict,
        state: compState,
        contactPhone: compPhone,
        whatsappPhone: compWa,
        description: compDesc,
      }),
    });
    if (res.ok) {
      setCompMsg(lang === 'hi' ? 'कंपनी विवरण सहेजा गया।' : 'Company profile updated.');
      await loadOverview();
    }
  }

  async function handleUpdateApplicant(appId: number) {
    const res = await apiFetch(`/api/employer/applications/${appId}`, {
      method: 'PATCH',
      body: JSON.stringify({
        status: statusDrafts[appId],
        employerNotes: noteDrafts[appId],
      }),
    });
    if (res.ok) {
      await loadOverview();
    }
  }

  if (!user || user.role !== 'employer') {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 pb-24">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
          <Building2 className="w-10 h-10 text-[#0F2942] mx-auto" aria-hidden="true" />
          <h1 className="text-2xl font-bold text-[#0F2942]">{t.employerTitle}</h1>
          <p className="text-sm sm:text-base text-slate-600">{t.employerSubtitle}</p>
          <button
            type="button"
            onClick={() => setAuthModalOpen(true)}
            className="min-h-[48px] px-6 py-3 rounded-xl bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-base"
          >
            {t.signIn} ({t.roleEmployer})
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 pb-24 md:pb-12 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-emerald-800">
            {employer?.companyName} · {employer?.verified ? t.verifiedListingLabel : t.pendingApprovalLabel}
          </p>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2942] mt-0.5">
            {t.employerTitle}
          </h1>
          <p className="text-sm text-slate-700 mt-1">{t.employerSubtitle}</p>
        </div>
      </div>

      {/* Employer Sub-Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1 bg-slate-200/70 rounded-xl w-fit">
        {(
          [
            { id: 'applicants', label: `${t.applicantsTab} (${applications.length})` },
            { id: 'post', label: t.postJobTab },
            { id: 'jobs', label: `${t.myJobsTab} (${jobs.length})` },
            { id: 'company', label: t.companyProfileTab },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={`min-h-[44px] px-4 py-2 rounded-lg text-sm font-bold transition-colors whitespace-nowrap ${
              tab === item.id ? 'bg-white text-[#0F2942] shadow-xs' : 'text-slate-700 hover:text-[#0F2942]'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {loading && <p className="text-sm text-slate-600">Loading...</p>}

      {/* Tab 1: Applicants & Interview Call Management */}
      {tab === 'applicants' && (
        <section className="space-y-4">
          {applications.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
              <Users className="w-8 h-8 text-slate-400 mx-auto" aria-hidden="true" />
              <p className="text-slate-700">{t.noApplicantsYet}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {applications.map((app) => (
                <div
                  key={app.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
                >
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                    <div className="space-y-1">
                      <p className="text-xs font-semibold text-slate-500">
                        {lang === 'hi' ? app.jobTitleHi : app.jobTitleEn} ·{' '}
                        <span className="font-mono-tabular text-emerald-800">
                          {app.matchScore}% {t.matchLabel}
                        </span>
                      </p>
                      <h3 className="text-lg font-bold text-[#0F2942]">{app.candidate.fullName}</h3>
                      <p className="text-sm text-slate-700">
                        {app.candidate.homeDistrict}, {app.candidate.state} ·{' '}
                        <span className="font-mono-tabular">{app.candidate.mobile}</span> ·{' '}
                        {app.candidate.experienceYears} yrs exp
                      </p>
                      <p className="text-xs text-slate-600">
                        {t.yourSkillsLabel}:{' '}
                        <span className="font-semibold text-slate-900">
                          {app.candidate.skills.join(' · ')}
                        </span>
                      </p>
                      <p className="text-xs text-slate-600">
                        ITI: <span className="font-semibold">{app.candidate.itiStatus}</span> · PMKVY:{' '}
                        <span className="font-semibold">{app.candidate.pmkvyStatus}</span> ·{' '}
                        {t.availableFrom}:{' '}
                        <span className="font-mono-tabular">{app.availabilityDate}</span>
                      </p>
                    </div>

                    <div className="w-full md:w-80 space-y-2.5 shrink-0">
                      <div className="flex gap-2">
                        <select
                          value={statusDrafts[app.id] || app.status}
                          onChange={(e) =>
                            setStatusDrafts((prev) => ({
                              ...prev,
                              [app.id]: e.target.value as ApplicationStatus,
                            }))
                          }
                          className="min-h-[44px] flex-1 px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm font-semibold"
                        >
                          {APPLICATION_STATUSES.map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => void handleUpdateApplicant(app.id)}
                          className="min-h-[44px] px-4 py-2 rounded-xl bg-[#15803D] hover:bg-[#166534] text-white text-sm font-bold whitespace-nowrap"
                        >
                          {t.updateStatusBtn}
                        </button>
                      </div>
                      <input
                        type="text"
                        value={noteDrafts[app.id] || ''}
                        onChange={(e) =>
                          setNoteDrafts((prev) => ({ ...prev, [app.id]: e.target.value }))
                        }
                        placeholder={t.interviewNotePlaceholder}
                        className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Tab 2: Post New Job Form */}
      {tab === 'post' && (
        <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6">
          <div className="flex items-center gap-2 mb-5">
            <PlusCircle className="w-5 h-5 text-emerald-700" aria-hidden="true" />
            <h2 className="text-xl font-bold text-[#0F2942]">{t.postNewJobHeading}</h2>
          </div>

          <form onSubmit={handlePostJob} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.jobTitleEnLabel}
                </label>
                <input
                  type="text"
                  required
                  value={titleEn}
                  onChange={(e) => setTitleEn(e.target.value)}
                  placeholder="e.g., Village Solar Streetlight Technician"
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.jobTitleHiLabel}
                </label>
                <input
                  type="text"
                  value={titleHi}
                  onChange={(e) => setTitleHi(e.target.value)}
                  placeholder="जैसे: सोलर स्ट्रीटलाइट तकनीशियन"
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.tradeCategoryLabel}
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as TradeCategoryId)}
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 bg-white text-base"
                >
                  {TRADE_CATEGORIES.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {lang === 'hi' ? cat.nameHi : cat.nameEn}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.salaryMonthlyLabel}
                </label>
                <input
                  type="number"
                  required
                  min={5000}
                  max={200000}
                  value={salaryMonthly}
                  onChange={(e) => setSalaryMonthly(Number(e.target.value))}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base font-mono-tabular"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.districtLabel}
                </label>
                <input
                  type="text"
                  required
                  value={locationDistrict}
                  onChange={(e) => setLocationDistrict(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.stateLabel}
                </label>
                <select
                  value={locationState}
                  onChange={(e) => setLocationState(e.target.value)}
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 bg-white text-base"
                >
                  {INDIAN_STATES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.experienceRequired} (yrs)
                </label>
                <input
                  type="number"
                  min={0}
                  max={15}
                  value={experienceMinYears}
                  onChange={(e) => setExperienceMinYears(Number(e.target.value))}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base font-mono-tabular"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  Employment Type
                </label>
                <select
                  value={employmentType}
                  onChange={(e) =>
                    setEmploymentType(e.target.value as 'Full-Time' | 'Contract' | 'Apprenticeship')
                  }
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 bg-white text-base"
                >
                  <option value="Full-Time">Full-Time</option>
                  <option value="Contract">Contract</option>
                  <option value="Apprenticeship">Apprenticeship</option>
                </select>
              </div>
            </div>

            <div className="flex flex-wrap gap-6 pt-1">
              <label className="inline-flex items-center gap-2.5 text-sm font-semibold text-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={accommodationFree}
                  onChange={(e) => setAccommodationFree(e.target.checked)}
                  className="w-5 h-5 accent-[#15803D]"
                />
                {t.freeAccommodation}
              </label>

              <label className="inline-flex items-center gap-2.5 text-sm font-semibold text-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={foodProvided}
                  onChange={(e) => setFoodProvided(e.target.checked)}
                  className="w-5 h-5 accent-[#15803D]"
                />
                {t.foodProvided}
              </label>
            </div>

            <div>
              <p className="text-sm font-semibold text-slate-800 mb-2">{t.requiredSkillsHeading}</p>
              <div className="flex flex-wrap gap-2">
                {VOCATIONAL_SKILLS.map((sk) => {
                  const active = requiredSkills.includes(sk.id);
                  return (
                    <button
                      key={sk.id}
                      type="button"
                      onClick={() => toggleJobSkill(sk.id)}
                      className={`min-h-[40px] px-3 py-1.5 rounded-lg border text-xs sm:text-sm font-semibold inline-flex items-center gap-1.5 ${
                        active
                          ? 'bg-[#0F2942] border-[#0F2942] text-white'
                          : 'bg-white border-slate-300 text-slate-700'
                      }`}
                    >
                      {active && <Check className="w-3.5 h-3.5" aria-hidden="true" />}
                      {lang === 'hi' ? sk.nameHi : sk.nameEn}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.jobDescEnLabel}
                </label>
                <textarea
                  required
                  rows={3}
                  value={descriptionEn}
                  onChange={(e) => setDescriptionEn(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.jobDescHiLabel}
                </label>
                <textarea
                  rows={3}
                  value={descriptionHi}
                  onChange={(e) => setDescriptionHi(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 text-base"
                />
              </div>
            </div>

            {formErr && (
              <div role="alert" className="p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800 font-semibold">
                {formErr}
              </div>
            )}
            {formMsg && (
              <div role="status" className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-900 font-semibold">
                {formMsg}
              </div>
            )}

            <button
              type="submit"
              className="min-h-[48px] px-6 py-3 rounded-xl bg-[#15803D] hover:bg-[#166534] text-white font-bold text-base"
            >
              {t.submitJobBtn}
            </button>
          </form>
        </section>
      )}

      {/* Tab 3: Employer's Posted Jobs */}
      {tab === 'jobs' && (
        <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {jobs.map((j) => (
            <div key={j.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-lg font-bold text-[#0F2942]">
                  {lang === 'hi' ? j.titleHi : j.titleEn}
                </h3>
                <span
                  className={`px-2.5 py-1 rounded-md border text-xs font-bold ${
                    j.approvalStatus === 'approved'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : j.approvalStatus === 'pending'
                        ? 'bg-amber-50 text-amber-900 border-amber-200'
                        : 'bg-red-50 text-red-800 border-red-200'
                  }`}
                >
                  {j.approvalStatus === 'approved'
                    ? t.verifiedListingLabel
                    : j.approvalStatus === 'pending'
                      ? t.pendingApprovalLabel
                      : t.rejectedListingLabel}
                </span>
              </div>
              <p className="text-sm text-slate-700">
                <span className="font-mono-tabular font-bold text-emerald-900">
                  ₹{j.salaryMonthly.toLocaleString('en-IN')}
                  {t.perMonth}
                </span>{' '}
                · {j.locationDistrict}, {j.locationState}
              </p>
              <p className="text-xs text-slate-600">{j.requiredSkills.join(' · ')}</p>
            </div>
          ))}
        </section>
      )}

      {/* Tab 4: Company Profile */}
      {tab === 'company' && (
        <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 max-w-2xl">
          <form onSubmit={handleSaveCompany} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1">
                {t.companyNameLabel}
              </label>
              <input
                type="text"
                required
                value={compName}
                onChange={(e) => setCompName(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.sectorLabel}
                </label>
                <input
                  type="text"
                  value={compSector}
                  onChange={(e) => setCompSector(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.districtLabel}
                </label>
                <input
                  type="text"
                  value={compDistrict}
                  onChange={(e) => setCompDistrict(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.stateLabel}
                </label>
                <select
                  value={compState}
                  onChange={(e) => setCompState(e.target.value)}
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 bg-white text-base"
                >
                  {INDIAN_STATES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  WhatsApp Number
                </label>
                <input
                  type="tel"
                  value={compWa}
                  onChange={(e) => setCompWa(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base font-mono-tabular"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1">
                Company Description
              </label>
              <textarea
                rows={3}
                value={compDesc}
                onChange={(e) => setCompDesc(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-300 text-base"
              />
            </div>

            {compMsg && (
              <p className="text-sm font-semibold text-emerald-800">{compMsg}</p>
            )}

            <button
              type="submit"
              className="min-h-[48px] px-6 py-3 rounded-xl bg-[#0F2942] text-white font-bold"
            >
              Save Company Info
            </button>
          </form>
        </section>
      )}
    </div>
  );
}
