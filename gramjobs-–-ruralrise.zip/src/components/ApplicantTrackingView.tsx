import { useEffect, useState } from 'react';
import { Award, Briefcase, Calendar, CheckCircle2, Clock, MapPin } from 'lucide-react';
import { VOCATIONAL_SKILLS, type ApplicationStatus, type CertificationStatus } from '../../shared/vocational';
import { useApp, type EnrichedJob } from '../context/AppContext';

export function ApplicantTrackingView() {
  const {
    lang,
    t,
    user,
    candidateProfile,
    candidateApplications,
    refreshCandidateApplications,
    setAuthModalOpen,
    setView,
    setSelectedJob,
    setQuickApplyJob,
    appliedJobIds,
    apiFetch,
  } = useApp();

  const [recommended, setRecommended] = useState<EnrichedJob[]>([]);

  useEffect(() => {
    if (user?.role === 'candidate') {
      void refreshCandidateApplications();
      const skillsParam = (candidateProfile?.skills || []).join(',');
      apiFetch(`/api/jobs?skills=${encodeURIComponent(skillsParam)}`)
        .then((r) => r.json())
        .then((data) => {
          const list = (data.jobs || []) as EnrichedJob[];
          setRecommended(list.slice(0, 3));
        })
        .catch(() => {});
    }
  }, [user, candidateProfile, refreshCandidateApplications, apiFetch]);

  function skillLabel(id: string): string {
    const found = VOCATIONAL_SKILLS.find((s) => s.id === id);
    return found ? (lang === 'hi' ? found.nameHi : found.nameEn) : id;
  }

  function statusStyle(status: ApplicationStatus): string {
    switch (status) {
      case 'Interview Call':
      case 'Selected':
        return 'bg-emerald-50 text-emerald-900 border-emerald-300';
      case 'Shortlisted':
      case 'Under Review':
        return 'bg-blue-50 text-[#0F2942] border-blue-300';
      case 'Rejected':
        return 'bg-red-50 text-red-900 border-red-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  }

  function certStatusText(status: CertificationStatus): string {
    switch (status) {
      case 'verified':
        return t.certStatusVerified;
      case 'pending':
        return t.certStatusPending;
      case 'rejected':
        return t.certStatusRejected;
      default:
        return t.certStatusNotSubmitted;
    }
  }

  if (!user || user.role !== 'candidate') {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 pb-24">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
          <Briefcase className="w-10 h-10 text-[#0F2942] mx-auto" aria-hidden="true" />
          <h1 className="text-2xl font-bold text-[#0F2942]">{t.trackingTitle}</h1>
          <p className="text-sm sm:text-base text-slate-600">{t.trackingSubtitle}</p>
          <button
            type="button"
            onClick={() => setAuthModalOpen(true)}
            className="min-h-[48px] px-6 py-3 rounded-xl bg-[#15803D] hover:bg-[#166534] text-white font-bold text-base"
          >
            {t.signIn} ({t.roleCandidate})
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 pb-24 md:pb-12 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2942]">{t.trackingTitle}</h1>
          <p className="text-sm sm:text-base text-slate-700 mt-1">{t.trackingSubtitle}</p>
        </div>
        <button
          type="button"
          onClick={() => setView('profile')}
          className="min-h-[44px] px-5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-[#0F2942] text-sm font-bold whitespace-nowrap"
        >
          {lang === 'hi' ? 'कौशल प्रोफ़ाइल संपादित करें' : 'Edit Skill Profile'}
        </button>
      </div>

      {/* Candidate Profile & Certifications Summary */}
      {candidateProfile && (
        <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-1.5">
            <p className="text-xs font-semibold text-slate-500">{t.myProfileSummary}</p>
            <h2 className="text-xl font-bold text-[#0F2942]">{candidateProfile.fullName}</h2>
            <p className="text-sm text-slate-700">
              {candidateProfile.homeDistrict}, {candidateProfile.state} ·{' '}
              <span className="font-mono-tabular">{candidateProfile.mobile}</span>
            </p>
            <p className="text-xs text-slate-600">
              {t.experienceYearsLabel}:{' '}
              <span className="font-semibold text-slate-900 tabular-nums">
                {candidateProfile.experienceYears} yrs
              </span>
            </p>
          </div>

          <div className="space-y-1.5">
            <p className="text-xs font-semibold text-slate-500">{t.yourSkillsLabel}</p>
            <p className="text-sm font-semibold text-slate-900 leading-relaxed">
              {candidateProfile.skills.length > 0
                ? candidateProfile.skills.map((s) => skillLabel(s)).join(' · ')
                : lang === 'hi'
                  ? 'अभी कोई कौशल नहीं चुना गया'
                  : 'No skills selected yet'}
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-500">{t.certificationsHeading}</p>
            <div className="space-y-1.5 text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 font-semibold text-slate-800">
                  <Award className="w-4 h-4 text-[#0F2942]" aria-hidden="true" />
                  ITI
                </span>
                <span className="text-xs font-semibold text-slate-700">
                  {certStatusText(candidateProfile.itiStatus)}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 font-semibold text-slate-800">
                  <Award className="w-4 h-4 text-emerald-700" aria-hidden="true" />
                  PMKVY
                </span>
                <span className="text-xs font-semibold text-slate-700">
                  {certStatusText(candidateProfile.pmkvyStatus)}
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Applied Jobs Tracking */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-[#0F2942]">
          {t.appliedJobsHeading} ({candidateApplications.length})
        </h2>

        {candidateApplications.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
            <p className="text-base text-slate-700">{t.noApplicationsYet}</p>
            <button
              type="button"
              onClick={() => setView('directory')}
              className="min-h-[48px] px-6 py-3 rounded-xl bg-[#15803D] hover:bg-[#166534] text-white font-bold"
            >
              {t.browseJobsCta}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {candidateApplications.map((app) => {
              const job = app.job;
              const jobTitle = job ? (lang === 'hi' ? job.titleHi : job.titleEn) : `Job #${app.jobId}`;
              const company = job ? (lang === 'hi' ? job.companyNameHi : job.companyName) : '';

              return (
                <div
                  key={app.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="text-lg font-bold text-[#0F2942]">{jobTitle}</h3>
                      <p className="text-sm font-medium text-slate-600">{company}</p>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-lg border text-xs font-bold whitespace-nowrap ${statusStyle(
                        app.status
                      )}`}
                    >
                      {app.status}
                    </span>
                  </div>

                  {job && (
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-700">
                      <span className="font-mono-tabular font-bold text-emerald-900">
                        ₹{job.salaryMonthly.toLocaleString('en-IN')}
                        {t.perMonth}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-4 h-4 text-slate-500" aria-hidden="true" />
                        {job.locationDistrict}, {job.locationState}
                      </span>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 pt-2 border-t border-slate-100">
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                      {t.appliedOn}: <span className="tabular-nums">{app.appliedAt.slice(0, 10)}</span>
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" aria-hidden="true" />
                      {t.availableFrom}: <span className="tabular-nums">{app.availabilityDate}</span>
                    </span>
                  </div>

                  {app.employerNotes && (
                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs sm:text-sm text-emerald-950">
                      <span className="font-bold">{t.employerNotesLabel}: </span>
                      {app.employerNotes}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Recommended Jobs */}
      {recommended.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-[#0F2942]">{t.recommendedJobsHeading}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recommended.map((job) => {
              const applied = appliedJobIds.has(job.id);
              return (
                <div
                  key={job.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium text-slate-500">
                        {job.locationDistrict}
                      </span>
                      <span className="font-mono-tabular text-sm font-extrabold text-emerald-800">
                        {job.match.score}% {t.matchLabel}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-[#0F2942]">
                      {lang === 'hi' ? job.titleHi : job.titleEn}
                    </h3>
                    <p className="font-mono-tabular text-lg font-bold text-emerald-900">
                      ₹{job.salaryMonthly.toLocaleString('en-IN')}
                      <span className="text-xs font-sans font-normal text-slate-600">
                        {t.perMonth}
                      </span>
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedJob(job)}
                      className="min-h-[44px] flex-1 px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold text-[#0F2942]"
                    >
                      {t.viewDetails}
                    </button>
                    <button
                      type="button"
                      disabled={applied}
                      onClick={() => setQuickApplyJob(job)}
                      className={`min-h-[44px] flex-1 px-3 py-2 rounded-xl text-sm font-bold inline-flex items-center justify-center gap-1 ${
                        applied ? 'bg-slate-200 text-slate-600' : 'bg-[#15803D] text-white'
                      }`}
                    >
                      {applied && <CheckCircle2 className="w-4 h-4" aria-hidden="true" />}
                      {applied ? t.alreadyApplied : t.quickApply}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
