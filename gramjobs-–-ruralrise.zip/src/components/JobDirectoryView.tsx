import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Briefcase,
  Home,
  MapPin,
  Search,
  SlidersHorizontal,
  Sun,
  Utensils,
  Wrench,
} from 'lucide-react';
import { TRADE_CATEGORIES, VOCATIONAL_SKILLS } from '../../shared/vocational';
import { useApp, type EnrichedJob } from '../context/AppContext';

const HERO_IMG = '/src/assets/images/hero_solar_technician_1795114646236.jpg';

export function JobDirectoryView() {
  const {
    lang,
    t,
    activeSkills,
    setView,
    setSelectedJob,
    setQuickApplyJob,
    appliedJobIds,
    apiFetch,
  } = useApp();

  const [jobs, setJobs] = useState<EnrichedJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  // Search & Filters
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [location, setLocation] = useState('all');
  const [minSalary, setMinSalary] = useState(0);
  const [maxExp, setMaxExp] = useState<string>('');
  const [accommodationOnly, setAccommodationOnly] = useState(false);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = new URLSearchParams();
      if (activeSkills.length > 0) {
        params.set('skills', activeSkills.join(','));
      }
      if (search.trim()) params.set('search', search.trim());
      if (category !== 'all') params.set('category', category);
      if (location !== 'all') params.set('location', location);
      if (minSalary > 0) params.set('minSalary', String(minSalary));
      if (maxExp !== '') params.set('maxExp', maxExp);
      if (accommodationOnly) params.set('accommodationOnly', 'true');

      const res = await apiFetch(`/api/jobs?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to load jobs');
      const data = await res.json();
      setJobs(data.jobs || []);
    } catch {
      setError(
        lang === 'hi'
          ? 'नौकरियां लोड करने में समस्या हुई। कृपया पुनः प्रयास करें।'
          : 'Could not load job directory. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, [activeSkills, search, category, location, minSalary, maxExp, accommodationOnly, apiFetch, lang]);

  useEffect(() => {
    void fetchJobs();
  }, [fetchJobs]);

  const locationOptions = useMemo(
    () => [
      'Jaipur',
      'Sikar',
      'Jodhpur',
      'Alwar',
      'Kota',
      'Ajmer',
      'Udaipur',
      'Bikaner',
      'Bhiwadi',
      'Bharatpur',
      'Anand',
      'Lucknow',
      'Indore',
      'Karnal',
      'Hisar',
      'Nashik',
      'Nagpur',
    ],
    []
  );

  function resetAllFilters() {
    setSearch('');
    setCategory('all');
    setLocation('all');
    setMinSalary(0);
    setMaxExp('');
    setAccommodationOnly(false);
  }

  function skillName(skillId: string): string {
    const found = VOCATIONAL_SKILLS.find((s) => s.id === skillId);
    if (!found) return skillId;
    return lang === 'hi' ? found.nameHi : found.nameEn;
  }

  function scrollToDirectory() {
    const el = document.getElementById('job-directory-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  }

  return (
    <div className="space-y-10 pb-24 md:pb-12">
      {/* Hero Section */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 lg:py-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center space-y-5">
              <p className="text-sm font-bold text-emerald-800">{t.heroEyebrow}</p>
              <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold text-[#0F2942] leading-[1.15] text-balance max-w-2xl">
                {t.heroTitle}
              </h1>
              <p className="text-base sm:text-lg text-slate-700 leading-relaxed max-w-2xl">
                {t.heroSubtitle}
              </p>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setView('profile')}
                  className="min-h-[48px] px-6 py-3 rounded-xl bg-[#15803D] hover:bg-[#166534] text-white font-bold text-base transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <Wrench className="w-5 h-5 shrink-0" aria-hidden="true" />
                  {t.heroPrimaryCta}
                </button>
                <button
                  type="button"
                  onClick={scrollToDirectory}
                  className="min-h-[48px] px-6 py-3 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-[#0F2942] font-bold text-base transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <Briefcase className="w-5 h-5 shrink-0" aria-hidden="true" />
                  {t.heroSecondaryCta}
                </button>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="h-64 sm:h-80 lg:h-full min-h-[260px] rounded-2xl overflow-hidden border border-slate-200 bg-emerald-950 relative">
                {!heroImgFailed ? (
                  <img
                    src={HERO_IMG}
                    alt="Rural solar rooftop technician installing photovoltaic panels"
                    referrerPolicy="no-referrer"
                    onError={() => setHeroImgFailed(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center text-white bg-gradient-to-br from-[#0F2942] to-[#15803D]">
                    <Sun className="w-12 h-12 text-amber-300 mb-3" aria-hidden="true" />
                    <p className="font-bold text-lg">{t.brandName}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 4-column Platform Summary Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-6 border-t border-slate-200">
            <div className="py-2">
              <p className="text-base sm:text-lg font-bold text-[#0F2942] tabular-nums">{t.heroStatJobs}</p>
              <p className="text-xs sm:text-sm text-slate-600">{t.sampleListingLabel}</p>
            </div>
            <div className="py-2">
              <p className="text-base sm:text-lg font-bold text-[#0F2942] tabular-nums">{t.heroStatTrades}</p>
              <p className="text-xs sm:text-sm text-slate-600">
                {lang === 'hi' ? 'सोलर, बिजली, कृषि, मैकेनिकल' : 'Solar, Electrical, Agri, Mechanical'}
              </p>
            </div>
            <div className="py-2">
              <p className="text-base sm:text-lg font-bold text-[#0F2942] tabular-nums">{t.heroStatNoResume}</p>
              <p className="text-xs sm:text-sm text-slate-600">
                {lang === 'hi' ? 'सीधे कौशल कार्ड चुनें' : 'Select practical trade cards'}
              </p>
            </div>
            <div className="py-2">
              <p className="text-base sm:text-lg font-bold text-emerald-800 tabular-nums">{t.heroStatFree}</p>
              <p className="text-xs sm:text-sm text-slate-600">
                {lang === 'hi' ? 'भर्ती के लिए कोई शुल्क नहीं' : 'Zero candidate fees'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Directory Section */}
      <section id="job-directory-section" className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Active Skill Match Banner */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-slate-500">
              {lang === 'hi'
                ? 'आपकी सक्रिय कौशल प्रोफ़ाइल से मिलान'
                : 'Live skill matching active for'}
            </p>
            <p className="text-sm sm:text-base font-bold text-[#0F2942] mt-0.5">
              {activeSkills.length > 0
                ? activeSkills.map((sk) => skillName(sk)).join(' · ')
                : lang === 'hi'
                  ? 'अभी कोई कौशल नहीं चुना गया (नीचे से अपनी प्रोफ़ाइल चुनें)'
                  : 'No skills selected yet — pick your trades to see match scores'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setView('profile')}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 text-sm font-bold transition-colors whitespace-nowrap shrink-0"
          >
            {lang === 'hi' ? 'कौशल बदलें' : 'Edit My Skills'}
          </button>
        </div>

        {/* Search & Filter Panel */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search
                className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t.searchPlaceholder}
                aria-label={t.searchPlaceholder}
                className="w-full min-h-[48px] pl-11 pr-4 py-2.5 rounded-xl border border-slate-300 text-base focus:outline-2 focus:outline-emerald-700"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:flex gap-3">
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                aria-label={t.filterAllLocations}
                className="min-h-[48px] px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-sm font-medium text-slate-800"
              >
                <option value="all">{t.filterAllLocations}</option>
                {locationOptions.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>

              <select
                value={minSalary}
                onChange={(e) => setMinSalary(Number(e.target.value))}
                aria-label={t.filterSalaryAny}
                className="min-h-[48px] px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-sm font-medium text-slate-800"
              >
                <option value={0}>{t.filterSalaryAny}</option>
                <option value={15000}>{t.filterSalary15k}</option>
                <option value={18000}>{t.filterSalary18k}</option>
                <option value={20000}>{t.filterSalary20k}</option>
              </select>

              <select
                value={maxExp}
                onChange={(e) => setMaxExp(e.target.value)}
                aria-label={t.filterExpAny}
                className="min-h-[48px] px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-sm font-medium text-slate-800"
              >
                <option value="">{t.filterExpAny}</option>
                <option value="0">{t.filterExp0}</option>
                <option value="1">{t.filterExp1}</option>
                <option value="2">{t.filterExp2}</option>
              </select>
            </div>
          </div>

          {/* Interactive Trade Filter Tabs & Accommodation Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label={t.filterAllTrades}>
              <button
                type="button"
                onClick={() => setCategory('all')}
                className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
                  category === 'all'
                    ? 'bg-[#0F2942] text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {t.filterAllTrades}
              </button>
              {TRADE_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id)}
                  className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
                    category === cat.id
                      ? 'bg-[#0F2942] text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {lang === 'hi' ? cat.nameHi : cat.nameEn}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <label className="min-h-[44px] inline-flex items-center gap-2 cursor-pointer text-sm font-semibold text-slate-800 select-none">
                <input
                  type="checkbox"
                  checked={accommodationOnly}
                  onChange={(e) => setAccommodationOnly(e.target.checked)}
                  className="w-5 h-5 accent-[#15803D] rounded"
                />
                <span>{t.filterAccomOnly}</span>
              </label>

              <button
                type="button"
                onClick={resetAllFilters}
                className="min-h-[40px] px-3 py-1.5 text-xs sm:text-sm font-semibold text-slate-600 hover:text-[#0F2942] underline underline-offset-2 whitespace-nowrap"
              >
                {t.resetFilters}
              </button>
            </div>
          </div>
        </div>

        {/* Count Header */}
        <div className="flex items-center justify-between">
          <p className="text-sm sm:text-base font-bold text-[#0F2942] tabular-nums">
            <SlidersHorizontal className="w-4 h-4 inline mr-2 text-emerald-700" aria-hidden="true" />
            {jobs.length} {t.jobsFoundCount}
          </p>
        </div>

        {/* Job Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array.from({ length: 6 }).map((_, idx) => (
              <div
                key={idx}
                className="h-72 rounded-2xl bg-white border border-slate-200 p-5 animate-pulse space-y-4"
              >
                <div className="h-5 w-2/3 bg-slate-200 rounded" />
                <div className="h-4 w-1/2 bg-slate-100 rounded" />
                <div className="h-20 bg-slate-100 rounded" />
                <div className="h-10 bg-slate-200 rounded-xl" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="p-6 rounded-2xl bg-red-50 border border-red-200 text-red-900 text-center space-y-3">
            <p className="font-semibold">{error}</p>
            <button
              type="button"
              onClick={() => void fetchJobs()}
              className="min-h-[44px] px-5 py-2 rounded-xl bg-red-700 text-white font-semibold"
            >
              Retry
            </button>
          </div>
        ) : jobs.length === 0 ? (
          <div className="p-10 rounded-2xl bg-white border border-slate-200 text-center space-y-3">
            <p className="text-lg font-bold text-[#0F2942]">
              {lang === 'hi' ? 'कोई मेल खाती नौकरी नहीं मिली' : 'No matching vacancies found'}
            </p>
            <p className="text-sm text-slate-600">
              {lang === 'hi'
                ? 'कृपया खोज शब्द बदलें या फ़िल्टर रीसेट करें।'
                : 'Try adjusting your location, salary, or trade filters.'}
            </p>
            <button
              type="button"
              onClick={resetAllFilters}
              className="min-h-[44px] px-5 py-2 rounded-xl bg-[#0F2942] text-white font-semibold"
            >
              {t.resetFilters}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {jobs.map((job) => {
              const isApplied = appliedJobIds.has(job.id);
              const title = lang === 'hi' ? job.titleHi : job.titleEn;
              const company = lang === 'hi' ? job.companyNameHi : job.companyName;

              return (
                <article
                  key={job.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between gap-4 hover:border-emerald-600/60 transition-colors"
                >
                  <div className="space-y-3">
                    {/* Clean unboxed top metadata + tabular match score */}
                    <div className="flex items-start justify-between gap-3">
                      <p className="text-xs font-medium text-slate-500">
                        {job.isSample ? t.sampleListingLabel : t.verifiedListingLabel} · {job.employmentType}
                      </p>
                      {activeSkills.length > 0 && (
                        <span
                          className={`font-mono-tabular text-sm font-extrabold shrink-0 ${
                            job.match.score >= 80
                              ? 'text-emerald-800'
                              : job.match.score >= 50
                                ? 'text-[#0F2942]'
                                : 'text-slate-600'
                          }`}
                        >
                          {job.match.score}% {t.matchLabel}
                        </span>
                      )}
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-[#0F2942] leading-snug">{title}</h3>
                      <p className="text-sm font-medium text-slate-600 mt-0.5">{company}</p>
                    </div>

                    {/* Transparent Compensation & Facilities */}
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                      <p className="font-mono-tabular text-xl font-bold text-emerald-900">
                        ₹{job.salaryMonthly.toLocaleString('en-IN')}
                        <span className="text-xs font-sans font-semibold text-slate-600">
                          {t.perMonth}
                        </span>
                      </p>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-semibold text-slate-700">
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#0F2942]" aria-hidden="true" />
                          {job.locationDistrict}, {job.locationState} ({job.proximityKm} km)
                        </span>
                        {job.accommodationFree && (
                          <span className="inline-flex items-center gap-1 text-emerald-800">
                            <Home className="w-3.5 h-3.5" aria-hidden="true" />
                            {t.freeAccommodation}
                          </span>
                        )}
                        {job.foodProvided && (
                          <span className="inline-flex items-center gap-1 text-emerald-800">
                            <Utensils className="w-3.5 h-3.5" aria-hidden="true" />
                            {t.foodProvided}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Required Skills as crisp inline text */}
                    <p className="text-xs text-slate-600 leading-relaxed">
                      <span className="font-semibold text-slate-800">
                        {lang === 'hi' ? 'कौशल:' : 'Skills:'}{' '}
                      </span>
                      {job.requiredSkills.map((sk) => skillName(sk)).join(' · ')}
                    </p>
                  </div>

                  {/* Touch-Friendly Actions */}
                  <div className="flex items-center gap-2.5 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setSelectedJob(job)}
                      className="min-h-[44px] flex-1 px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-[#0F2942] text-sm font-bold transition-colors whitespace-nowrap"
                    >
                      {t.viewDetails}
                    </button>
                    <button
                      type="button"
                      disabled={isApplied}
                      onClick={() => setQuickApplyJob(job)}
                      className={`min-h-[44px] flex-1 px-4 py-2 rounded-xl text-sm font-bold transition-colors whitespace-nowrap ${
                        isApplied
                          ? 'bg-slate-200 text-slate-600 cursor-default'
                          : 'bg-[#15803D] hover:bg-[#166534] text-white'
                      }`}
                    >
                      {isApplied ? t.alreadyApplied : t.quickApply}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
