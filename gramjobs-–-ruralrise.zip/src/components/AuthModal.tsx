import React, { useState } from 'react';
import { X } from 'lucide-react';
import { INDIAN_STATES } from '../../shared/vocational';
import { useApp } from '../context/AppContext';

export function AuthModal() {
  const { authModalOpen, setAuthModalOpen, login, register, t } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [role, setRole] = useState<'candidate' | 'employer'>('candidate');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [district, setDistrict] = useState('Jaipur');
  const [state, setState] = useState('Rajasthan');
  const [companyName, setCompanyName] = useState('');
  const [sector, setSector] = useState('Solar & Renewable Energy');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!authModalOpen) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result =
        mode === 'login'
          ? await login(phone, password)
          : await register({
              name,
              phone,
              password,
              role,
              district,
              state,
              companyName: role === 'employer' ? companyName : undefined,
              sector: role === 'employer' ? sector : undefined,
            });
      if (!result.ok) {
        setError(result.error || 'Operation failed');
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleDemoLogin(demoPhone: string) {
    setError('');
    setLoading(true);
    try {
      const result = await login(demoPhone, '1234');
      if (!result.ok) {
        setError(result.error || 'Demo login failed');
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="bg-white w-full max-w-lg rounded-2xl border border-slate-200 shadow-xl overflow-hidden my-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <h2 id="auth-modal-title" className="text-lg font-bold text-[#0F2942]">
            {mode === 'login' ? t.authModalTitleSignIn : t.authModalTitleRegister}
          </h2>
          <button
            type="button"
            onClick={() => setAuthModalOpen(false)}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-200"
            aria-label={t.closeBtn}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Segmented Mode Toggle */}
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError('');
              }}
              className={`min-h-[44px] py-2 px-3 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                mode === 'login' ? 'bg-white text-[#0F2942] shadow-xs' : 'text-slate-600'
              }`}
            >
              {t.authTabSignIn}
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError('');
              }}
              className={`min-h-[44px] py-2 px-3 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                mode === 'register' ? 'bg-white text-[#0F2942] shadow-xs' : 'text-slate-600'
              }`}
            >
              {t.authTabRegister}
            </button>
          </div>

          {error && (
            <div
              role="alert"
              className="p-3 rounded-xl bg-red-50 border border-red-200 text-sm font-medium text-red-800"
            >
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('candidate')}
                    className={`min-h-[44px] px-3 py-2 rounded-xl border text-sm font-semibold transition-colors ${
                      role === 'candidate'
                        ? 'bg-emerald-50 border-emerald-700 text-emerald-900'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    {t.roleCandidate}
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('employer')}
                    className={`min-h-[44px] px-3 py-2 rounded-xl border text-sm font-semibold transition-colors ${
                      role === 'employer'
                        ? 'bg-blue-50 border-[#0F2942] text-[#0F2942]'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    {t.roleEmployer}
                  </button>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-800 mb-1">
                    {t.fullNameLabel}
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., Arjun Singh"
                    className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base focus:outline-2 focus:outline-emerald-700"
                  />
                </div>

                {role === 'employer' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-semibold text-slate-800 mb-1">
                        {t.companyNameLabel}
                      </label>
                      <input
                        type="text"
                        required
                        value={companyName}
                        onChange={(e) => setCompanyName(e.target.value)}
                        placeholder="e.g., Gramin Solar Works"
                        className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-800 mb-1">
                        {t.sectorLabel}
                      </label>
                      <input
                        type="text"
                        value={sector}
                        onChange={(e) => setSector(e.target.value)}
                        className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                      />
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1">
                      {t.homeDistrictLabel}
                    </label>
                    <input
                      type="text"
                      required
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-800 mb-1">
                      {t.stateLabel}
                    </label>
                    <select
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-300 text-base bg-white"
                    >
                      {INDIAN_STATES.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1">
                {t.mobileNumberLabel}
              </label>
              <input
                type="tel"
                inputMode="numeric"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="9876543210"
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base font-mono-tabular"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1">
                {t.pinPasswordLabel}
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••"
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] px-5 py-3 bg-[#15803D] hover:bg-[#166534] disabled:opacity-60 text-white font-bold text-base rounded-xl transition-colors"
            >
              {mode === 'login' ? t.signIn : t.authTabRegister}
            </button>
          </form>

          {/* Instant Demo Access */}
          <div className="pt-4 border-t border-slate-200 space-y-2.5">
            <p className="text-xs font-bold tracking-wide text-slate-600">{t.demoAccessHeading}</p>
            <div className="grid grid-cols-1 gap-2">
              <button
                type="button"
                disabled={loading}
                onClick={() => void handleDemoLogin('9876543210')}
                className="min-h-[44px] w-full text-left px-4 py-2.5 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-sm font-semibold text-emerald-950 transition-colors"
              >
                {t.demoCandidateBtn}
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={() => void handleDemoLogin('9829011223')}
                className="min-h-[44px] w-full text-left px-4 py-2.5 rounded-xl border border-blue-200 bg-blue-50 hover:bg-blue-100 text-sm font-semibold text-[#0F2942] transition-colors"
              >
                {t.demoEmployerBtn}
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={() => void handleDemoLogin('9999000011')}
                className="min-h-[44px] w-full text-left px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-sm font-semibold text-slate-800 transition-colors"
              >
                {t.demoAdminBtn}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
