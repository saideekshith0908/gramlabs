import { Briefcase, ClipboardCheck, Globe, ShieldCheck, UserCheck, Wrench } from 'lucide-react';
import { useApp, type AppView } from '../context/AppContext';

export function Navbar() {
  const { lang, setLang, t, view, setView, user, logout, setAuthModalOpen } = useApp();

  const navItems: Array<{ id: AppView; label: string }> = [
    { id: 'directory', label: t.navFindJobs },
    { id: 'profile', label: t.navSkillProfile },
    { id: 'applications', label: t.navMyApplications },
    { id: 'employer', label: t.navEmployerHub },
    { id: 'admin', label: t.navAdmin },
  ];

  const mobileTabs: Array<{ id: AppView; label: string; icon: typeof Briefcase }> = [
    { id: 'directory', label: t.navFindJobs, icon: Briefcase },
    { id: 'profile', label: t.navSkillProfile, icon: Wrench },
    { id: 'applications', label: t.navMyApplications, icon: ClipboardCheck },
    {
      id: user?.role === 'admin' ? 'admin' : 'employer',
      label: user?.role === 'admin' ? t.navAdmin : t.navEmployerHub,
      icon: user?.role === 'admin' ? ShieldCheck : UserCheck,
    },
  ];

  return (
    <>
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => setView('directory')}
            className="text-lg sm:text-xl font-bold tracking-tight text-[#0F2942] whitespace-nowrap shrink-0 text-left focus-visible:outline-2 focus-visible:outline-emerald-700 rounded"
          >
            {t.brandName}
          </button>

          {/* Zone 2: Clean Single-Line Nav Links */}
          <nav className="hidden md:flex items-center gap-6" aria-label="Main navigation">
            {navItems.map((item) => {
              const active = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setView(item.id)}
                  className={`py-2 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 border-b-2 focus-visible:outline-2 focus-visible:outline-emerald-700 ${
                    active
                      ? 'text-emerald-800 border-emerald-700'
                      : 'text-slate-600 border-transparent hover:text-[#0F2942] hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center shrink-0">
            {user ? (
              <button
                type="button"
                onClick={() => void logout()}
                className="min-h-[40px] px-4 py-2 text-sm font-semibold text-[#0F2942] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-emerald-700"
              >
                {t.signOut}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setAuthModalOpen(true)}
                className="min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-[#15803D] hover:bg-[#166534] rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-emerald-700"
              >
                {t.signIn}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Accessible Workspace Language & Identity Strip */}
      <div className="bg-[#0F2942] text-white border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-200">
            {user ? (
              <span>
                {user.name} ·{' '}
                <span className="font-semibold text-emerald-300 capitalize">{user.role}</span>
              </span>
            ) : (
              <span>{t.heroEyebrow}</span>
            )}
          </div>

          <div
            className="flex items-center gap-2"
            role="group"
            aria-label={t.languageLabel}
          >
            <Globe className="w-4 h-4 text-emerald-300 shrink-0" aria-hidden="true" />
            <div className="inline-flex rounded-lg bg-slate-900/60 p-0.5 border border-slate-700">
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`min-h-[36px] px-3.5 py-1 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  lang === 'en'
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-200 hover:text-white'
                }`}
              >
                {t.langEnglish}
              </button>
              <button
                type="button"
                onClick={() => setLang('hi')}
                className={`min-h-[36px] px-3.5 py-1 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  lang === 'hi'
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-200 hover:text-white'
                }`}
              >
                {t.langHindi}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Fixed Thumb-Zone Bottom Navigation Bar (<= 64px height) */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200"
        aria-label="Mobile navigation"
      >
        <div className="grid grid-cols-4 h-16">
          {mobileTabs.map((tab) => {
            const Icon = tab.icon;
            const active = view === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setView(tab.id)}
                className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 px-1 text-[11px] font-semibold transition-colors ${
                  active ? 'text-emerald-800 bg-emerald-50/70' : 'text-slate-600'
                }`}
              >
                <Icon className="w-5 h-5 shrink-0" aria-hidden="true" />
                <span className="truncate max-w-full">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
