import React, { useEffect, useState } from 'react';
import { CheckCircle2, Phone, ShieldAlert, X } from 'lucide-react';
import { VOCATIONAL_SKILLS } from '../../shared/vocational';
import { useApp } from '../context/AppContext';

export function QuickApplyModal() {
  const {
    lang,
    t,
    user,
    candidateProfile,
    quickApplyJob,
    setQuickApplyJob,
    setSelectedJob,
    setAuthModalOpen,
    setView,
    apiFetch,
    refreshCandidateApplications,
    appliedJobIds,
  } = useApp();

  const [availabilityDate, setAvailabilityDate] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (quickApplyJob) {
      setError('');
      setSuccess(false);
      setAvailabilityDate(
        candidateProfile?.availabilityDate || new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10)
      );
    }
  }, [quickApplyJob, candidateProfile]);

  if (!quickApplyJob) return null;

  const isAlreadyApplied = appliedJobIds.has(quickApplyJob.id);
  const jobTitle = lang === 'hi' ? quickApplyJob.titleHi : quickApplyJob.titleEn;
  const company = lang === 'hi' ? quickApplyJob.companyNameHi : quickApplyJob.companyName;

  async function handleConfirmApply(e: React.FormEvent) {
    e.preventDefault();
    if (!quickApplyJob) return;
    setError('');
    setSubmitting(true);
    try {
      const res = await apiFetch('/api/applications', {
        method: 'POST',
        body: JSON.stringify({
          jobId: quickApplyJob.id,
          availabilityDate,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not submit application.');
        return;
      }
      await refreshCandidateApplications();
      setSuccess(true);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="quick-apply-title"
    >
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h2 id="quick-apply-title" className="text-lg font-bold text-[#0F2942]">
              {t.quickApplyTitle}
            </h2>
            <p className="text-xs text-slate-600">
              {jobTitle} · {company}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setQuickApplyJob(null)}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-200"
            aria-label={t.closeBtn}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {!user || user.role !== 'candidate' ? (
            <div className="space-y-4">
              <p className="text-sm text-slate-700 leading-relaxed">
                {lang === 'hi'
                  ? 'बिना रिज्यूमे एक-टैप आवेदन करने के लिए कृपया उम्मीदवार के रूप में लॉग इन करें या नया निःशुल्क खाता बनाएं।'
                  : 'Please sign in or register as a Job Seeker (Candidate) to submit a one-tap application without a resume.'}
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setQuickApplyJob(null);
                    setAuthModalOpen(true);
                  }}
                  className="min-h-[48px] flex-1 px-5 py-3 bg-[#15803D] hover:bg-[#166534] text-white font-bold rounded-xl transition-colors"
                >
                  {t.signIn} / {t.authTabRegister}
                </button>
                <button
                  type="button"
                  onClick={() => setQuickApplyJob(null)}
                  className="min-h-[48px] px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl transition-colors"
                >
                  {t.cancelBtn}
                </button>
              </div>
            </div>
          ) : success ? (
            <div className="space-y-4 py-2 text-center">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8" aria-hidden="true" />
              </div>
              <h3 className="text-xl font-bold text-[#0F2942]">{t.applySuccessTitle}</h3>
              <p className="text-sm text-slate-700 max-w-md mx-auto leading-relaxed">
                {t.applySuccessBody}
              </p>
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setQuickApplyJob(null);
                    setSelectedJob(null);
                    setView('applications');
                  }}
                  className="min-h-[48px] flex-1 px-5 py-3 bg-[#15803D] hover:bg-[#166534] text-white font-bold rounded-xl transition-colors"
                >
                  {t.goToTrackingBtn}
                </button>
                <button
                  type="button"
                  onClick={() => setQuickApplyJob(null)}
                  className="min-h-[48px] px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl transition-colors"
                >
                  {t.closeBtn}
                </button>
              </div>
            </div>
          ) : isAlreadyApplied ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm font-semibold">
                {lang === 'hi'
                  ? 'आप इस नौकरी के लिए पहले ही आवेदन कर चुके हैं।'
                  : 'You have already applied for this job vacancy.'}
              </div>
              <button
                type="button"
                onClick={() => {
                  setQuickApplyJob(null);
                  setSelectedJob(null);
                  setView('applications');
                }}
                className="w-full min-h-[48px] px-5 py-3 bg-[#0F2942] text-white font-bold rounded-xl"
              >
                {t.goToTrackingBtn}
              </button>
            </div>
          ) : (
            <form onSubmit={handleConfirmApply} className="space-y-4">
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-2.5 text-xs sm:text-sm font-semibold text-amber-950">
                <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{t.fraudWarningTitle}</span>
              </div>

              <p className="text-sm text-slate-700">{t.confirmDetailsNote}</p>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">{t.fullNameLabel}</span>
                  <span className="font-bold text-slate-900">
                    {candidateProfile?.fullName || user.name}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">{t.mobileNumberLabel}</span>
                  <span className="font-mono-tabular font-semibold text-slate-900 inline-flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                    {candidateProfile?.mobile || user.phone}
                  </span>
                </div>
                <div className="pt-2 border-t border-slate-200 text-sm">
                  <span className="text-slate-600 block mb-1">{t.yourSkillsLabel}</span>
                  <p className="font-medium text-slate-900">
                    {(candidateProfile?.skills || []).length > 0
                      ? (candidateProfile?.skills || [])
                          .map((id) => {
                            const s = VOCATIONAL_SKILLS.find((v) => v.id === id);
                            return s ? (lang === 'hi' ? s.nameHi : s.nameEn) : id;
                          })
                          .join(' · ')
                      : lang === 'hi'
                        ? 'कोई कौशल नहीं चुना गया'
                        : 'No skills selected yet'}
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-1">
                  {t.availabilityDateLabel}
                </label>
                <input
                  type="date"
                  required
                  value={availabilityDate}
                  onChange={(e) => setAvailabilityDate(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 text-base"
                />
              </div>

              {error && (
                <div
                  role="alert"
                  className="p-3 rounded-xl bg-red-50 border border-red-200 text-sm font-medium text-red-800"
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full min-h-[48px] px-5 py-3 bg-[#15803D] hover:bg-[#166534] disabled:opacity-60 text-white font-bold text-base rounded-xl transition-colors"
              >
                {t.confirmApplyBtn}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
