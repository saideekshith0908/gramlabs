import {
  CheckCircle2,
  Home,
  MapPin,
  MessageCircle,
  ShieldAlert,
  Utensils,
  X,
} from 'lucide-react';
import { VOCATIONAL_SKILLS } from '../../shared/vocational';
import { useApp } from '../context/AppContext';
import { HindiAudioPlayer } from './HindiAudioPlayer';

export function JobDetailModal() {
  const {
    lang,
    t,
    selectedJob,
    setSelectedJob,
    setQuickApplyJob,
    appliedJobIds,
  } = useApp();

  if (!selectedJob) return null;

  const job = selectedJob;
  const isApplied = appliedJobIds.has(job.id);
  const title = lang === 'hi' ? job.titleHi : job.titleEn;
  const company = lang === 'hi' ? job.companyNameHi : job.companyName;
  const description = lang === 'hi' ? job.descriptionHi : job.descriptionEn;
  const responsibilities = lang === 'hi' ? job.responsibilitiesHi : job.responsibilitiesEn;

  const whatsappMessage =
    lang === 'hi'
      ? `${t.whatsappPrefillPrefix} ${job.titleHi} (${job.companyNameHi})। कृपया अधिक जानकारी साझा करें।`
      : `${t.whatsappPrefillPrefix} ${job.titleEn} position advertised on GramJobs – RuralRise. Please share more details.`;

  const whatsappUrl = `https://wa.me/${job.whatsappPhone}?text=${encodeURIComponent(whatsappMessage)}`;

  function skillLabel(skillId: string): string {
    const found = VOCATIONAL_SKILLS.find((s) => s.id === skillId);
    if (!found) return skillId;
    return lang === 'hi' ? found.nameHi : found.nameEn;
  }

  return (
    <div
      className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="job-detail-title"
    >
      <div className="bg-white w-full sm:max-w-3xl max-h-[92vh] rounded-t-3xl sm:rounded-2xl border border-slate-200 shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 px-6 py-4 border-b border-slate-200 bg-white shrink-0">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-slate-500 mb-1">
              {job.isSample ? t.sampleListingLabel : t.verifiedListingLabel} · {job.employmentType} ·{' '}
              {t.postedOn} {job.postedDate}
            </p>
            <h2 id="job-detail-title" className="text-xl sm:text-2xl font-bold text-[#0F2942] leading-snug">
              {title}
            </h2>
            <p className="text-sm font-semibold text-slate-700 mt-0.5">{company}</p>
          </div>

          <button
            type="button"
            onClick={() => setSelectedJob(null)}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100 shrink-0"
            aria-label={t.closeBtn}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Mandatory Anti-Fraud Warning Banner */}
          <div
            role="alert"
            className="p-4 rounded-xl bg-amber-50 border border-amber-300 flex items-start gap-3"
          >
            <ShieldAlert className="w-6 h-6 text-amber-800 shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <p className="text-sm sm:text-base font-extrabold text-amber-950">
                {t.fraudWarningTitle}
              </p>
              <p className="text-xs sm:text-sm text-amber-900 mt-0.5">{t.fraudWarningBody}</p>
            </div>
          </div>

          {/* Transparent Salary, Accommodation & Match Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-mono-tabular text-2xl sm:text-3xl font-bold text-emerald-950">
                  ₹{job.salaryMonthly.toLocaleString('en-IN')}
                </span>
                <span className="text-sm font-semibold text-emerald-800">{t.perMonth}</span>
              </div>
              <div className="space-y-1.5 pt-1 text-sm font-medium text-emerald-950">
                <div className="flex items-center gap-2">
                  <Home className="w-4 h-4 text-emerald-700 shrink-0" aria-hidden="true" />
                  <span>
                    {job.accommodationFree
                      ? t.freeAccommodation
                      : lang === 'hi'
                        ? 'आवास स्वयं प्रबंधित'
                        : 'Self-arranged housing'}
                  </span>
                </div>
                {job.foodProvided && (
                  <div className="flex items-center gap-2">
                    <Utensils className="w-4 h-4 text-emerald-700 shrink-0" aria-hidden="true" />
                    <span>{t.foodProvided}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-700 shrink-0" aria-hidden="true" />
                  <span>
                    {job.locationDistrict}, {job.locationState} · {job.proximityKm} {t.kmAway} ·{' '}
                    {t.regionalEmployment}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-700">{t.matchBreakdownHeading}</span>
                <span className="font-mono-tabular text-xl font-extrabold text-[#0F2942]">
                  {job.match.score}% {t.matchLabel}
                </span>
              </div>
              <div className="space-y-1.5 text-xs sm:text-sm">
                {job.match.exactMatches.map((sk) => (
                  <div key={sk} className="flex items-center gap-2 text-emerald-800 font-medium">
                    <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>
                      {skillLabel(sk)} ({t.exactMatchNote})
                    </span>
                  </div>
                ))}
                {job.match.transferableMatches.map((tr) => (
                  <div key={tr.required} className="flex items-center gap-2 text-[#0F2942] font-medium">
                    <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" aria-hidden="true" />
                    <span>
                      {skillLabel(tr.required)} ({t.transferableMatchNote} {skillLabel(tr.matchedFrom)})
                    </span>
                  </div>
                ))}
                {job.match.missingSkills.map((ms) => (
                  <div key={ms} className="text-slate-500">
                    {skillLabel(ms)} · {t.missingSkillNote}
                  </div>
                ))}
              </div>
              <p className="text-xs text-slate-600 pt-1 border-t border-slate-200">
                {t.experienceRequired}:{' '}
                <span className="font-semibold text-slate-900">
                  {job.experienceMinYears === 0
                    ? t.fresherWelcome
                    : `${job.experienceMinYears} ${t.yearsExp}`}
                </span>
              </p>
            </div>
          </div>

          {/* Hindi Audio Description Player */}
          <HindiAudioPlayer job={job} />

          {/* Description & Responsibilities */}
          <div className="space-y-3">
            <p className="text-base text-slate-800 leading-relaxed">{description}</p>

            <div>
              <h3 className="text-base font-bold text-[#0F2942] mb-2">{t.responsibilitiesHeading}</h3>
              <ul className="space-y-2 list-disc list-inside text-sm sm:text-base text-slate-700">
                {responsibilities.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>

            <div className="pt-2">
              <h3 className="text-base font-bold text-[#0F2942] mb-1.5">{t.requiredSkillsHeading}</h3>
              <p className="text-sm font-medium text-slate-800">
                {job.requiredSkills.map((sk) => skillLabel(sk)).join(' · ')}
              </p>
            </div>
          </div>
        </div>

        {/* Sticky Action Bar */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[48px] px-5 py-3 rounded-xl border border-emerald-700 bg-white hover:bg-emerald-50 text-emerald-900 font-bold text-sm sm:text-base inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-5 h-5 text-emerald-700" aria-hidden="true" />
            {t.whatsappEmployer}
          </a>

          <button
            type="button"
            disabled={isApplied}
            onClick={() => setQuickApplyJob(job)}
            className={`min-h-[48px] flex-1 px-6 py-3 rounded-xl font-bold text-sm sm:text-base transition-colors whitespace-nowrap ${
              isApplied
                ? 'bg-slate-200 text-slate-600 cursor-default'
                : 'bg-[#15803D] hover:bg-[#166534] text-white'
            }`}
          >
            {isApplied ? t.alreadyApplied : t.quickApply}
          </button>
        </div>
      </div>
    </div>
  );
}
