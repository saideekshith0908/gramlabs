import { useCallback, useEffect, useState } from 'react';
import { Check, ShieldCheck, X } from 'lucide-react';
import type {
  ApplicationStatus,
  CandidateProfile,
  EmployerProfile,
  JobPosting,
} from '../../shared/vocational';
import { useApp } from '../context/AppContext';

interface AdminOverviewData {
  stats: {
    totalCandidates: number;
    totalEmployers: number;
    totalJobs: number;
    totalApplications: number;
    pendingApprovals: number;
    pendingCertificates: number;
  };
  candidates: CandidateProfile[];
  employers: EmployerProfile[];
  jobs: JobPosting[];
  pendingJobs: JobPosting[];
  pendingCerts: CandidateProfile[];
  applications: Array<{
    id: number;
    jobId: number;
    jobTitleEn: string;
    jobTitleHi: string;
    companyName: string;
    candidateName: string;
    candidateDistrict: string;
    availabilityDate: string;
    status: ApplicationStatus;
    appliedAt: string;
  }>;
}

export function AdminDashboardView() {
  const { lang, t, user, setAuthModalOpen, apiFetch } = useApp();
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [loading, setLoading] = useState(false);

  const loadAdminOverview = useCallback(async () => {
    if (!user || user.role !== 'admin') return;
    setLoading(true);
    try {
      const res = await apiFetch('/api/admin/overview');
      if (res.ok) {
        setData(await res.json());
      }
    } finally {
      setLoading(false);
    }
  }, [user, apiFetch]);

  useEffect(() => {
    void loadAdminOverview();
  }, [loadAdminOverview]);

  async function handleJobApproval(jobId: number, approvalStatus: 'approved' | 'rejected') {
    const res = await apiFetch(`/api/admin/jobs/${jobId}/approval`, {
      method: 'PATCH',
      body: JSON.stringify({ approvalStatus }),
    });
    if (res.ok) await loadAdminOverview();
  }

  async function handleCertDecision(
    userId: number,
    type: 'iti' | 'pmkvy',
    status: 'verified' | 'rejected'
  ) {
    const res = await apiFetch(`/api/admin/certificates/${userId}`, {
      method: 'PATCH',
      body: JSON.stringify({ type, status }),
    });
    if (res.ok) await loadAdminOverview();
  }

  async function handleEmployerVerify(employerId: number, verified: boolean) {
    const res = await apiFetch(`/api/admin/employers/${employerId}/verify`, {
      method: 'PATCH',
      body: JSON.stringify({ verified }),
    });
    if (res.ok) await loadAdminOverview();
  }

  if (!user || user.role !== 'admin') {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 pb-24">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
          <ShieldCheck className="w-10 h-10 text-[#0F2942] mx-auto" aria-hidden="true" />
          <h1 className="text-2xl font-bold text-[#0F2942]">{t.adminTitle}</h1>
          <p className="text-sm sm:text-base text-slate-600">{t.adminSubtitle}</p>
          <button
            type="button"
            onClick={() => setAuthModalOpen(true)}
            className="min-h-[48px] px-6 py-3 rounded-xl bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-base"
          >
            {t.signIn} (Admin)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 pb-24 md:pb-12 space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2942]">{t.adminTitle}</h1>
        <p className="text-sm sm:text-base text-slate-700 mt-1">{t.adminSubtitle}</p>
      </div>

      {loading && !data && <p className="text-sm text-slate-600">Loading admin metrics...</p>}

      {data && (
        <>
          {/* KPI Grid */}
          <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { label: t.statCandidates, value: data.stats.totalCandidates },
              { label: t.statEmployers, value: data.stats.totalEmployers },
              { label: t.statJobs, value: data.stats.totalJobs },
              { label: t.statApplications, value: data.stats.totalApplications },
              { label: t.statPendingJobs, value: data.stats.pendingApprovals, highlight: data.stats.pendingApprovals > 0 },
              { label: t.statPendingCerts, value: data.stats.pendingCertificates, highlight: data.stats.pendingCertificates > 0 },
            ].map((kpi) => (
              <div
                key={kpi.label}
                className={`p-4 rounded-2xl border ${
                  kpi.highlight ? 'bg-amber-50 border-amber-300' : 'bg-white border-slate-200'
                }`}
              >
                <p className="text-xs font-semibold text-slate-600">{kpi.label}</p>
                <p className="font-mono-tabular text-2xl font-extrabold text-[#0F2942] mt-1">
                  {kpi.value}
                </p>
              </div>
            ))}
          </section>

          {/* Pending Job Approvals */}
          <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-4">
            <h2 className="text-lg sm:text-xl font-bold text-[#0F2942]">
              {t.pendingJobsHeading} ({data.pendingJobs.length})
            </h2>

            {data.pendingJobs.length === 0 ? (
              <p className="text-sm text-slate-600">
                {lang === 'hi' ? 'कोई लंबित नौकरी नहीं है।' : 'No pending job submissions right now.'}
              </p>
            ) : (
              <div className="space-y-3">
                {data.pendingJobs.map((job) => (
                  <div
                    key={job.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <h3 className="text-base font-bold text-[#0F2942]">
                        {lang === 'hi' ? job.titleHi : job.titleEn}
                      </h3>
                      <p className="text-sm text-slate-700">
                        {job.companyName} · {job.locationDistrict}, {job.locationState} ·{' '}
                        <span className="font-mono-tabular font-bold">
                          ₹{job.salaryMonthly.toLocaleString('en-IN')}/mo
                        </span>
                      </p>
                      <p className="text-xs text-slate-600">{job.requiredSkills.join(' · ')}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => void handleJobApproval(job.id, 'approved')}
                        className="min-h-[44px] px-4 py-2 rounded-xl bg-[#15803D] hover:bg-[#166534] text-white text-sm font-bold inline-flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4" aria-hidden="true" />
                        {t.approveBtn}
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleJobApproval(job.id, 'rejected')}
                        className="min-h-[44px] px-4 py-2 rounded-xl bg-red-50 border border-red-200 hover:bg-red-100 text-red-800 text-sm font-bold inline-flex items-center gap-1.5"
                      >
                        <X className="w-4 h-4" aria-hidden="true" />
                        {t.rejectBtn}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* ITI & PMKVY Certificate Verification Queue */}
          <section className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-4">
            <h2 className="text-lg sm:text-xl font-bold text-[#0F2942]">
              {t.certVerificationHeading} ({data.pendingCerts.length})
            </h2>

            {data.pendingCerts.length === 0 ? (
              <p className="text-sm text-slate-600">
                {lang === 'hi'
                  ? 'समीक्षा के लिए कोई लंबित प्रमाणपत्र नहीं है।'
                  : 'All submitted ITI and PMKVY certificates have been reviewed.'}
              </p>
            ) : (
              <div className="space-y-3">
                {data.pendingCerts.map((cand) => (
                  <div
                    key={cand.userId}
                    className="p-4 rounded-xl border border-slate-200 space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="font-bold text-[#0F2942]">{cand.fullName}</p>
                        <p className="text-xs text-slate-600">
                          {cand.homeDistrict}, {cand.state}
                        </p>
                      </div>
                    </div>

                    {cand.itiStatus === 'pending' && (
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="text-sm">
                          <span className="font-bold text-[#0F2942]">ITI:</span> {cand.itiTrade} ·{' '}
                          <span className="font-mono-tabular">{cand.itiCertificateCode}</span>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => void handleCertDecision(cand.userId, 'iti', 'verified')}
                            className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-[#15803D] text-white text-xs font-bold"
                          >
                            {t.verifyCertBtn}
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleCertDecision(cand.userId, 'iti', 'rejected')}
                            className="min-h-[40px] px-3.5 py-1.5 rounded-lg border border-red-200 text-red-800 text-xs font-bold"
                          >
                            {t.rejectBtn}
                          </button>
                        </div>
                      </div>
                    )}

                    {cand.pmkvyStatus === 'pending' && (
                      <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="text-sm">
                          <span className="font-bold text-emerald-900">PMKVY:</span> {cand.pmkvyTrade} ·{' '}
                          <span className="font-mono-tabular">{cand.pmkvyCertificateCode}</span>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => void handleCertDecision(cand.userId, 'pmkvy', 'verified')}
                            className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-[#15803D] text-white text-xs font-bold"
                          >
                            {t.verifyCertBtn}
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleCertDecision(cand.userId, 'pmkvy', 'rejected')}
                            className="min-h-[40px] px-3.5 py-1.5 rounded-lg border border-red-200 text-red-800 text-xs font-bold"
                          >
                            {t.rejectBtn}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Registered Employers & Recent Applications */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
              <h2 className="text-lg font-bold text-[#0F2942]">{t.employersHeading}</h2>
              <div className="space-y-3">
                {data.employers.map((emp) => (
                  <div
                    key={emp.id}
                    className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <div>
                      <p className="font-bold text-slate-900">{emp.companyName}</p>
                      <p className="text-xs text-slate-600">
                        {emp.sector} · {emp.district}, {emp.state}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => void handleEmployerVerify(emp.id, !emp.verified)}
                      className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-bold border whitespace-nowrap ${
                        emp.verified
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                          : 'bg-slate-100 border-slate-300 text-slate-700'
                      }`}
                    >
                      {emp.verified ? t.verifiedListingLabel : 'Verify Employer'}
                    </button>
                  </div>
                ))}
              </div>
            </section>

            <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
              <h2 className="text-lg font-bold text-[#0F2942]">{t.applicationsMonitorHeading}</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500">
                      <th className="py-2 pr-3">Candidate</th>
                      <th className="py-2 pr-3">Job</th>
                      <th className="py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {data.applications.map((a) => (
                      <tr key={a.id} className="h-11">
                        <td className="py-2 pr-3 font-medium text-slate-900">
                          {a.candidateName}
                          <span className="block text-xs text-slate-500">{a.candidateDistrict}</span>
                        </td>
                        <td className="py-2 pr-3 text-slate-700">
                          {lang === 'hi' ? a.jobTitleHi : a.jobTitleEn}
                        </td>
                        <td className="py-2 font-semibold text-[#0F2942]">{a.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>

          {/* All Job Listings Table */}
          <section className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
            <h2 className="text-lg font-bold text-[#0F2942]">
              {t.allJobsHeading} ({data.jobs.length})
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs text-slate-500">
                    <th className="py-2 pr-3">Title</th>
                    <th className="py-2 pr-3">Location</th>
                    <th className="py-2 pr-3 text-right">Salary</th>
                    <th className="py-2 pr-3">Type</th>
                    <th className="py-2">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {data.jobs.map((j) => (
                    <tr key={j.id} className="h-11">
                      <td className="py-2 pr-3 font-semibold text-slate-900">
                        {lang === 'hi' ? j.titleHi : j.titleEn}
                      </td>
                      <td className="py-2 pr-3 text-slate-600">
                        {j.locationDistrict}, {j.locationState}
                      </td>
                      <td className="py-2 pr-3 text-right font-mono-tabular font-semibold">
                        ₹{j.salaryMonthly.toLocaleString('en-IN')}
                      </td>
                      <td className="py-2 pr-3 text-xs text-slate-600">
                        {j.isSample ? t.sampleListingLabel : 'Live Employer'}
                      </td>
                      <td className="py-2 text-xs font-bold capitalize text-[#0F2942]">
                        {j.approvalStatus}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </div>
  );
}
